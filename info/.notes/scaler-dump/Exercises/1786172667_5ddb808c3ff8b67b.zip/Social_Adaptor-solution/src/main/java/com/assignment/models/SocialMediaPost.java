package com.assignment.models;

import lombok.AllArgsConstructor;

@AllArgsConstructor
public class SocialMediaPost {
    private String id;
    private String text;
    private Long userId;
    private Long timestamp;
}