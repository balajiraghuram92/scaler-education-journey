package contest;

import contest.utils.StorageUtils;

/**
 * TODO: Task 2 - Implement the contest.FileStorage interface to simply store and get the raw file content.
 * Methods you can use (Add link to StorageUtils#store and StorageUtils#read):
 * 1. {@link contest.utils.StorageUtils#read(String)}
 * 2. {@link contest.utils.StorageUtils#store(String, byte[])}
 */
public class RawFileStorage implements FileStorage {
    @Override
    public void storeFile(String fileName, byte[] content) {
        StorageUtils.store(fileName, content);
    }

    @Override
    public byte[] getFile(String fileName) {
        return StorageUtils.read(fileName);
    }

}
