package contest;

import static contest.utils.StorageUtils.compress;
import static contest.utils.StorageUtils.decompress;

/**
 * TODO Task 4a - Implement the {@link BaseFileDecorator} interface to compress and decompress the file content.
 * Remember
 * 1. When you inherit from the {@link BaseFileDecorator}, you will have to implement the store and read methods.
 * 2. You will also need to call the next layer in the chain while reading and writing the file content.
 * 3. Each decorator would also need a constructor that takes the next layer of type {@link FileStorage}.
 */
public class CompressionDecorator extends BaseFileDecorator {

    private FileStorage fileStorage;
    public CompressionDecorator(FileStorage fileStorage) {
        super(fileStorage);
        this.fileStorage = fileStorage;
    }

    @Override
    public void storeFile(String fileName, byte[] content) {
        byte[] compressedContent = compress(content);
        fileStorage.storeFile(fileName, compressedContent);
    }

    @Override
    public byte[] getFile(String fileName) {
        byte[] compressedContent = fileStorage.getFile(fileName);
        return decompress(compressedContent);
    }
}
