package contest;

public interface FileStorage {
    // Task 1a - Add a method storeFile that takes a String fileName and a byte[] content as arguments with no return value

    void storeFile(String fileName, byte[] content);
    // Task 1b - Add a method getFile that takes a String fileName as argument and returns a byte[]
    byte[] getFile(String fileName);
}