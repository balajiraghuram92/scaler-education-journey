from typing import TypeVar, Callable

T = TypeVar('T')

def compare(x: T, y: T, key: Callable[[T], any] = None) -> int:
    if key is not None:
        #todo
        x_key = key(x)
        y_key = key(y)
        if x_key < y_key:
            return -1
        elif x_key == y_key:
            return 0
        else:
            return 1
    else:
        #todo
        if x < y:
            return -1
        elif x == y:
            return 0
        else:
            return 1

# Example usage:

# Direct comparison
print(compare(5, 10))  # Output: -1
print(compare("abc", "abc"))  # Output: 0
print(compare(20, 10))  # Output: 1


# Comparison with key function
students = [
    {"name": "Alice", "age": 25},
    {"name": "Bob", "age": 30},
    {"name": "Charlie", "age": 20}
]

# Sort students by age
sorted_students = sorted(students, key=lambda x: x['age'])
print(sorted_students)  # Output: [{'name': 'Charlie', 'age': 20}, {'name': 'Alice', 'age': 25}, {'name': 'Bob', 'age': 30}]