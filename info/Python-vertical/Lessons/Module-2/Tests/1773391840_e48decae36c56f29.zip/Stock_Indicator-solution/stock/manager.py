from .model import *


class StockTradingManager:
    def __init__(self, strategy_type):
        self.strategy_type = strategy_type

    def calculate_indicator(self, stock: Stock) -> float:
        if self.strategy_type == TradingStrategyType.MOVING_AVERAGES:
            return (stock.price + stock.previous_close) / 2
        elif self.strategy_type == TradingStrategyType.MOMENTUM:
            return stock.price - stock.previous_close
        elif self.strategy_type == TradingStrategyType.VOLATILITY:
            return abs(stock.price - stock.previous_close)
        else:
            raise ValueError(f"Invalid strategy type {self.strategy_type}")
