from abc import ABC
from .storage import FileStorage
from .utils import StorageUtils


# Task 1 - Implement the BaseFileDecorator class that inherits from the FileStorage class.
class BaseFileDecorator(FileStorage, ABC):
    # Task 2 - Modify the __init__ method to store the file storage instance.
    def __init__(self, file_storage: FileStorage):
        self._file_storage = file_storage

    # Task 3 - Add the store_file and retrieve_file methods that call the respective methods of the file storage instance.
    def store_file(self, file_data: bytes, file_name: str):
        self._file_storage.store_file(file_data, file_name)

    def retrieve_file(self, file_name: str) -> bytes:
        return self._file_storage.retrieve_file(file_name)


class CompressionDecorator(FileStorage):
    def __init__(self, file_storage: FileStorage):
        self._file_storage = file_storage

    def store_file(self, file_data: bytes, file_name: str):
        compressed_data = StorageUtils.compress(file_data)
        self._file_storage.store_file(compressed_data, file_name)

    def retrieve_file(self, file_name: str) -> bytes:
        compressed_data = self._file_storage.retrieve_file(file_name)
        return StorageUtils.decompress(compressed_data)


class VirusScanDecorator(FileStorage):
    def __init__(self, file_storage: FileStorage):
        self._file_storage = file_storage

    def store_file(self, file_data: bytes, file_name: str):
        if StorageUtils.scan_for_virus(file_data):
            self._file_storage.store_file(file_data, file_name)
        else:
            raise ValueError("File contains virus and cannot be stored")

    def retrieve_file(self, file_name: str) -> bytes:
        return self._file_storage.retrieve_file(file_name)
