from .model import *


class PricingManager:
    BASE_FARE = 5.0  # Base fare amount
    PER_KILOMETER_RATE = 2.0  # Rate per kilometer
    PER_MINUTE_RATE = 0.5  # Rate per minute
    SURGE_MULTIPLIER = 2.0  # Surge pricing multiplier

    def __init__(self, pricing_type):
        self.pricing_type = pricing_type

    def calculate_price(self, ride_details: RideDetails) -> float:
        if self.pricing_type == PricingType.DISTANCE_BASED:
            return self.BASE_FARE + self.PER_KILOMETER_RATE * ride_details.distance
        elif self.pricing_type == PricingType.TIME_BASED:
            return self.BASE_FARE + self.PER_MINUTE_RATE * ride_details.duration
        elif self.pricing_type == PricingType.SURGE:
            return self.BASE_FARE * self.SURGE_MULTIPLIER
        else:
            raise ValueError(f"Invalid pricing type: {self.pricing_type}")
