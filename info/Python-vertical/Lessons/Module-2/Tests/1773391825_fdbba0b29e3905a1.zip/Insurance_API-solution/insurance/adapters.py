from abc import ABC, abstractmethod

from .model import *
from .services import *

class TravelInsuranceAdapter(ABC):
    @abstractmethod
    def add_claim(self, reference: str, amount: float) -> None:
        pass

    @abstractmethod
    def get_status(self, reference: str) -> ClaimStatus:
        pass


class AutoProtectAdapter(TravelInsuranceAdapter):
    def __init__(self):
        self.auto_protect_api = AutoProtectApi()

    def add_claim(self, reference: str, amount: float):
        self.auto_protect_api.add_claim(amount)

    def get_status(self, reference: str) -> ClaimStatus:
        status = self.auto_protect_api.get_status(reference)
        if status == "APPROVED":
            return ClaimStatus.APPROVED
        return ClaimStatus.PENDING


class TravelGuardAdapter(TravelInsuranceAdapter):
    def __init__(self):
        self.travel_guard_api = TravelGuardApi()

    def add_claim(self, reference: str, amount: float):
        self.travel_guard_api.submit_claim(reference, amount)

    def get_status(self, reference: str) -> ClaimStatus:
        status = self.travel_guard_api.get_claim_status(reference)
        if status == "APPROVED":
            return ClaimStatus.APPROVED
        return ClaimStatus.PENDING
