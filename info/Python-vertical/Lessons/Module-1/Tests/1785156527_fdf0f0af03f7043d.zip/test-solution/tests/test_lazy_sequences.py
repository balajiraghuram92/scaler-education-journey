import unittest
import types

from main.base import LazySequence
from main.generators import even_numbers
from main.iterators import NumberRange


class NumberRangeTests(unittest.TestCase):
    def test_number_range_inherits_from_lazy_sequence(self):
        number_range = NumberRange(1, 3)

        self.assertIsInstance(number_range, LazySequence)

    def test_number_range_produces_values_from_start_to_before_end(self):
        number_range = NumberRange(2, 6)

        self.assertEqual(list(number_range), [2, 3, 4, 5])

    def test_number_range_works_with_negative_numbers(self):
        number_range = NumberRange(-3, 2)

        self.assertEqual(list(number_range), [-3, -2, -1, 0, 1])

    def test_iter_returns_self(self):
        number_range = NumberRange(4, 7)

        self.assertIs(iter(number_range), number_range)

    def test_next_returns_one_value_at_a_time(self):
        number_range = NumberRange(5, 8)

        self.assertEqual(next(number_range), 5)
        self.assertEqual(next(number_range), 6)
        self.assertEqual(next(number_range), 7)

    def test_next_raises_stop_iteration_when_finished(self):
        number_range = NumberRange(1, 2)

        self.assertEqual(next(number_range), 1)

        with self.assertRaises(StopIteration):
            next(number_range)

    def test_number_range_is_exhausted_after_looping_once(self):
        number_range = NumberRange(1, 4)

        self.assertEqual(list(number_range), [1, 2, 3])
        self.assertEqual(list(number_range), [])

    def test_start_and_end_must_be_integers(self):
        invalid_pairs = [
            (1.0, 3),
            (1, 3.0),
            ("1", 3),
            (1, "3"),
            (None, 3),
            (1, None),
            (True, 3),
            (1, False),
        ]

        for start, end in invalid_pairs:
            with self.subTest(start=start, end=end):
                with self.assertRaises(TypeError) as context:
                    NumberRange(start, end)

                self.assertEqual(
                    str(context.exception),
                    "start and end must both be integers",
                )

    def test_start_must_be_less_than_end(self):
        invalid_pairs = [(3, 3), (5, 2), (0, -1)]

        for start, end in invalid_pairs:
            with self.subTest(start=start, end=end):
                with self.assertRaises(ValueError) as context:
                    NumberRange(start, end)

                self.assertEqual(str(context.exception), "start must be less than end")


class EvenNumbersTests(unittest.TestCase):
    def test_even_numbers_returns_generator(self):
        result = even_numbers(6)

        self.assertIsInstance(result, types.GeneratorType)

    def test_even_numbers_produces_values_under_limit(self):
        self.assertEqual(list(even_numbers(10)), [0, 2, 4, 6, 8])

    def test_even_numbers_with_odd_limit_stops_before_limit(self):
        self.assertEqual(list(even_numbers(7)), [0, 2, 4, 6])

    def test_even_numbers_with_zero_limit_is_empty(self):
        self.assertEqual(list(even_numbers(0)), [])

    def test_even_numbers_with_one_limit_only_yields_zero(self):
        self.assertEqual(list(even_numbers(1)), [0])

    def test_even_numbers_is_lazy(self):
        generator = even_numbers(100)

        self.assertEqual(next(generator), 0)
        self.assertEqual(next(generator), 2)
        self.assertEqual(next(generator), 4)

    def test_even_numbers_limit_must_be_integer(self):
        invalid_values = [1.5, "6", None, True, False]

        for value in invalid_values:
            with self.subTest(value=value):
                with self.assertRaises(TypeError) as context:
                    list(even_numbers(value))

                self.assertEqual(str(context.exception), "limit must be an integer")

    def test_even_numbers_limit_must_not_be_negative(self):
        with self.assertRaises(ValueError) as context:
            list(even_numbers(-1))

        self.assertEqual(str(context.exception), "limit must not be negative")


if __name__ == "__main__":
    unittest.main()