# Unique Persons Finder Challenge

## Problem Statement

In this challenge, you will work with a `Person` class, which represents individuals with `name` and `age` attributes. Your task is to implement the `find_unique_persons` function. This function should take a list of `Person` objects as input and return a new list that contains only unique persons based on their names. It's important that this function maintains the order of appearance and includes only the first occurrence of each unique name, disregarding subsequent duplicates.

## Task Description

### The Person Class

The `Person` class is predefined with the following attributes:

- `name`: A string representing the person's name.
- `age`: An integer representing the person's age.

You should use this class as provided without modification.

### The find_unique_persons Function

Implement the `find_unique_persons` function to meet the following requirements:

- Accept a list of `Person` objects as its input.
- Return a new list of `Person` objects, ensuring each name appears only once. If there are multiple persons with the same name, only include the first person encountered with that name in the output list.
- Maintain the order of persons as they appear in the input list.
