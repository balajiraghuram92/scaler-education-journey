import unittest

from electric_cab import ElectricCab
from electric import ElectricVehicle
from commercial import CommercialVehicle
from vehicle import Vehicle


class ElectricCabTests(unittest.TestCase):

    def test_attributes_initialized(self):
        cab = ElectricCab("EC101", 75, "Commercial")

        self.assertEqual(cab.reg_number, "EC101")
        self.assertEqual(cab.battery_capacity, 75)
        self.assertEqual(cab.license_type, "Commercial")

    def test_priority_score(self):
        cab = ElectricCab("EC101", 75, "Commercial")

        self.assertEqual(cab.get_priority_score(), 20)

    def test_mro_order(self):
        expected = [
            ElectricCab,
            ElectricVehicle,
            CommercialVehicle,
            Vehicle,
            object
        ]

        self.assertEqual(ElectricCab.mro()[:5], expected)

    def test_isinstance_relationships(self):
        cab = ElectricCab("EC101", 75, "Commercial")

        self.assertIsInstance(cab, ElectricCab)
        self.assertIsInstance(cab, ElectricVehicle)
        self.assertIsInstance(cab, CommercialVehicle)
        self.assertIsInstance(cab, Vehicle)

    def test_super_initializes_all_attributes(self):
        cab = ElectricCab("EC999", 90, "Premium")

        self.assertEqual(cab.reg_number, "EC999")
        self.assertEqual(cab.battery_capacity, 90)
        self.assertEqual(cab.license_type, "Premium")


if __name__ == "__main__":
    unittest.main()