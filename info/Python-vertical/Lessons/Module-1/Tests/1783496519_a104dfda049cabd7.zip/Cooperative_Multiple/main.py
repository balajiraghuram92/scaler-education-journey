from electric_cab import ElectricCab


def main():
    cab = ElectricCab("EC101", 75, "Commercial")

    print(cab.reg_number)
    print(cab.battery_capacity)
    print(cab.license_type)
    print(cab.get_priority_score())


if __name__ == "__main__":
    main()