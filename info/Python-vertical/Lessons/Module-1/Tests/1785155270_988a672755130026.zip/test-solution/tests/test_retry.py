import unittest
from unittest.mock import patch

from main.retry import retry


class RetryDecoratorTests(unittest.TestCase):
    def test_returns_result_on_first_success(self):
        calls = []

        @retry(times=3)
        def greet(name):
            calls.append(name)
            return f"Hello, {name}"

        result = greet("Maya")

        self.assertEqual(result, "Hello, Maya")
        self.assertEqual(calls, ["Maya"])

    def test_retries_until_function_succeeds(self):
        calls = []

        @retry(times=3)
        def sometimes_fails():
            calls.append("called")
            if len(calls) < 3:
                raise ValueError("not yet")
            return "done"

        with patch("main.retry.time.sleep") as fake_sleep:
            result = sometimes_fails()

        self.assertEqual(result, "done")
        self.assertEqual(len(calls), 3)
        self.assertEqual(fake_sleep.call_count, 2)

    def test_passes_args_and_kwargs_to_decorated_function(self):
        @retry(times=2)
        def add_numbers(first, second=0):
            return first + second

        result = add_numbers(5, second=7)

        self.assertEqual(result, 12)

    def test_does_not_retry_after_success(self):
        calls = []

        @retry(times=5)
        def works_now():
            calls.append("called")
            return "success"

        with patch("main.retry.time.sleep") as fake_sleep:
            result = works_now()

        self.assertEqual(result, "success")
        self.assertEqual(len(calls), 1)
        fake_sleep.assert_not_called()

    def test_waits_delay_between_failed_attempts(self):
        @retry(times=3, delay=0.25)
        def always_fails():
            raise OSError("temporary problem")

        with patch("main.retry.time.sleep") as fake_sleep:
            with self.assertRaises(RuntimeError):
                always_fails()

        self.assertEqual(fake_sleep.call_count, 2)
        fake_sleep.assert_called_with(0.25)

    def test_raises_runtime_error_after_all_attempts_fail(self):
        calls = []

        @retry(times=4)
        def always_fails():
            calls.append("called")
            raise KeyError("missing")

        with self.assertRaises(RuntimeError) as context:
            always_fails()

        self.assertEqual(str(context.exception), "Function failed after 4 attempts")
        self.assertEqual(len(calls), 4)

    def test_runtime_error_keeps_original_exception_as_cause(self):
        @retry(times=2)
        def always_fails():
            raise ValueError("original problem")

        with self.assertRaises(RuntimeError) as context:
            always_fails()

        self.assertIsInstance(context.exception.__cause__, ValueError)
        self.assertEqual(str(context.exception.__cause__), "original problem")

    def test_preserves_function_name_and_docstring(self):
        @retry(times=2)
        def sample_function():
            """This is the original docstring."""
            return "ok"

        self.assertEqual(sample_function.__name__, "sample_function")
        self.assertEqual(sample_function.__doc__, "This is the original docstring.")

    def test_times_must_be_positive_integer(self):
        invalid_values = [0, -1, 1.5, "3", None, True, False]

        for value in invalid_values:
            with self.subTest(value=value):
                with self.assertRaises(ValueError) as context:
                    retry(value)

                self.assertEqual(
                    str(context.exception),
                    "times must be a positive integer",
                )

    def test_delay_must_not_be_negative(self):
        invalid_values = [-1, -0.1, "1", None, True, False]

        for value in invalid_values:
            with self.subTest(value=value):
                with self.assertRaises(ValueError) as context:
                    retry(3, delay=value)

                self.assertEqual(str(context.exception), "delay must be non-negative")

    def test_valid_delay_values_are_allowed(self):
        for value in [0, 0.0, 1, 0.5]:
            with self.subTest(value=value):
                decorator = retry(1, delay=value)
                self.assertTrue(callable(decorator))


if __name__ == "__main__":
    unittest.main()
    