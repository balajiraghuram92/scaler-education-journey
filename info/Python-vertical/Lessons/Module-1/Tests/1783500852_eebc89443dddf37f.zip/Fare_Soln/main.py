from fare import estimate_fare
from trip import Trip


def main():
    print(estimate_fare(10.0))
    print(estimate_fare("HSR-AIRPORT"))
    print(estimate_fare(Trip(12)))


if __name__ == "__main__":
    main()