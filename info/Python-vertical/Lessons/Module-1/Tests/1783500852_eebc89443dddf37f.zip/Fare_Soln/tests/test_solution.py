import unittest

from fare import estimate_fare
from trip import Trip


class FareEstimatorTests(unittest.TestCase):

    def test_float_distance(self):
        self.assertEqual(estimate_fare(10.0), 150.0)

    def test_float_zero_distance(self):
        self.assertEqual(estimate_fare(0.0), 0.0)

    def test_known_route_hsr(self):
        self.assertEqual(estimate_fare("HSR-AIRPORT"), 600)

    def test_known_route_mg(self):
        self.assertEqual(estimate_fare("MG-AIRPORT"), 550)

    def test_unknown_route(self):
        self.assertEqual(estimate_fare("UNKNOWN"), 0)

    def test_trip_object(self):
        trip = Trip(20)

        self.assertEqual(estimate_fare(trip), 300)

    def test_trip_zero_distance(self):
        trip = Trip(0)

        self.assertEqual(estimate_fare(trip), 0)

    def test_unsupported_type(self):
        with self.assertRaises(NotImplementedError):
            estimate_fare(10)


if __name__ == "__main__":
    unittest.main()