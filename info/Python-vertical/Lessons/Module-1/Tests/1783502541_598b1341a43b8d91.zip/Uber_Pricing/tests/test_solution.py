import unittest

from pricing import (
    BaseFare,
    SurgeMixin,
    DiscountMixin,
    TaxMixin,
    FinalFare
)


class PricingTests(unittest.TestCase):

    def test_base_fare(self):
        base = BaseFare()
        self.assertEqual(base.calculate_fare(10), 100)

    def test_final_fare_example(self):
        pricing = FinalFare(
            multiplier=2,
            percent=10,
            rate=5
        )

        self.assertEqual(pricing.calculate_fare(10), 189)

    def test_zero_distance(self):
        pricing = FinalFare(
            multiplier=2,
            percent=10,
            rate=5
        )

        self.assertEqual(pricing.calculate_fare(0), 0)

    def test_no_surge(self):
        pricing = FinalFare(
            multiplier=1,
            percent=10,
            rate=5
        )

        self.assertEqual(pricing.calculate_fare(10), 94.5)

    def test_no_discount(self):
        pricing = FinalFare(
            multiplier=2,
            percent=0,
            rate=5
        )

        self.assertEqual(pricing.calculate_fare(10), 210)

    def test_no_tax(self):
        pricing = FinalFare(
            multiplier=2,
            percent=10,
            rate=0
        )

        self.assertEqual(pricing.calculate_fare(10), 180)

    def test_mro_order(self):
        expected = [
            FinalFare,
            TaxMixin,
            DiscountMixin,
            SurgeMixin,
            BaseFare,
            object
        ]

        self.assertEqual(FinalFare.mro()[:6], expected)

    def test_attributes_initialized(self):
        pricing = FinalFare(
            multiplier=3,
            percent=15,
            rate=18
        )

        self.assertEqual(pricing.multiplier, 3)
        self.assertEqual(pricing.percent, 15)
        self.assertEqual(pricing.rate, 18)


if __name__ == "__main__":
    unittest.main()