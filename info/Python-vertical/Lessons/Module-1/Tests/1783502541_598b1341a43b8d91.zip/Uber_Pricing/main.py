from pricing import FinalFare


def main():
    pricing = FinalFare(
        multiplier=2,
        percent=10,
        rate=5
    )

    print(pricing.calculate_fare(10))


if __name__ == "__main__":
    main()