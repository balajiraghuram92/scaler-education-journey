import math
import unittest

from zones import Zone, CircularZone, RectangularZone, TriangularZone


class ZoneTests(unittest.TestCase):

    def test_base_area_not_implemented(self):
        zone = Zone("Base")

        with self.assertRaises(NotImplementedError):
            zone.area()

    def test_circular_zone_area(self):
        zone = CircularZone("Circle", 2)

        self.assertAlmostEqual(zone.area(), math.pi * 4)

    def test_rectangular_zone_area(self):
        zone = RectangularZone("Rectangle", 4, 5)

        self.assertEqual(zone.area(), 20)

    def test_triangular_zone_area(self):
        zone = TriangularZone("Triangle", 6, 4)

        self.assertEqual(zone.area(), 12)

    def test_zone_equality(self):
        zone1 = RectangularZone("R1", 4, 5)
        zone2 = RectangularZone("R2", 2, 10)

        self.assertEqual(zone1, zone2)

    def test_zone_less_than(self):
        small = RectangularZone("Small", 2, 3)
        large = RectangularZone("Large", 5, 5)

        self.assertTrue(small < large)

    def test_sorted_zones(self):
        zones = [
            RectangularZone("A", 5, 5),
            TriangularZone("B", 4, 2),
            CircularZone("C", 1)
        ]

        zones = sorted(zones)

        self.assertEqual(zones[0].name, "C")
        self.assertEqual(zones[1].name, "B")
        self.assertEqual(zones[2].name, "A")

    def test_zone_addition(self):
        zone1 = RectangularZone("A", 4, 5)
        zone2 = TriangularZone("B", 6, 4)

        combined = zone1 + zone2

        self.assertEqual(combined.area(), 32)

    def test_combined_zone_is_zone(self):
        zone1 = CircularZone("A", 2)
        zone2 = RectangularZone("B", 3, 4)

        combined = zone1 + zone2

        self.assertIsInstance(combined, Zone)

        expected = zone1.area() + zone2.area()
        self.assertAlmostEqual(combined.area(), expected)


if __name__ == "__main__":
    unittest.main()