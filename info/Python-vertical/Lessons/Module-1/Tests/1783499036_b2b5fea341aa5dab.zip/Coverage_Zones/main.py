from zones import CircularZone, RectangularZone, TriangularZone


def main():
    circle = CircularZone("Circle", 2)
    rectangle = RectangularZone("Rectangle", 4, 5)
    triangle = TriangularZone("Triangle", 6, 4)

    print(circle.area())
    print(rectangle.area())
    print(triangle.area())

    combined = circle + rectangle
    print(combined.area())


if __name__ == "__main__":
    main()