import unittest

from library import Library, Book, Member, Borrowable
from magazine import Magazine
from protocols import Searchable


class SearchableProtocolTests(unittest.TestCase):

    def setUp(self):
        self.library = Library()

        self.book = Book("Python Programming", "Guido")
        self.magazine = Magazine("Python Monthly", "July 2026")

        self.library.add_item(self.book)
        self.library.add_item(self.magazine)

    def test_book_is_borrowable(self):
        self.assertIsInstance(self.book, Borrowable)

    def test_book_satisfies_protocol(self):
        self.assertIsInstance(self.book, Searchable)

    def test_magazine_is_not_borrowable(self):
        self.assertNotIsInstance(self.magazine, Borrowable)

    def test_magazine_satisfies_protocol(self):
        self.assertIsInstance(self.magazine, Searchable)

    def test_search_returns_book(self):
        results = self.library.search("Programming")
        self.assertIn(self.book, results)

    def test_search_returns_magazine(self):
        results = self.library.search("Monthly")
        self.assertIn(self.magazine, results)

    def test_search_returns_both(self):
        results = self.library.search("Python")

        self.assertEqual(len(results), 2)
        self.assertIn(self.book, results)
        self.assertIn(self.magazine, results)

    def test_lend_book(self):
        member = Member("Alice")

        self.library.lend(member, self.book)

        self.assertFalse(self.book.is_available)

    def test_lend_magazine_raises(self):
        member = Member("Alice")

        with self.assertRaises(TypeError):
            self.library.lend(member, self.magazine)


if __name__ == "__main__":
    unittest.main()
