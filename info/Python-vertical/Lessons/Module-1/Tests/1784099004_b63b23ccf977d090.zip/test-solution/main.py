from library import Library, Book, Member
from magazine import Magazine


def main():
    library = Library()

    book = Book("Python Programming", "Guido")
    magazine = Magazine("Python Monthly", "July 2026")

    library.add_item(book)
    library.add_item(magazine)

    print(library.search("Python"))

    member = Member("Alice")

    library.lend(member, book)

    try:
        library.lend(member, magazine)
    except TypeError as e:
        print(e)


if __name__ == "__main__":
    main()
