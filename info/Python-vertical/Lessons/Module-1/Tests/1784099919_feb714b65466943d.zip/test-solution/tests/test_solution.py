import unittest
from datetime import datetime

from library import Library
from models import Book


class LibraryIntegrationTests(unittest.TestCase):

    def test_timestamp_created(self):
        book = Book("ISBN-101", "Python")
        self.assertIsInstance(book.created_at, datetime)

    def test_isbn_property(self):
        book = Book("ISBN-101", "Python")
        self.assertEqual(book.isbn, "ISBN-101")

    def test_isbn_is_read_only(self):
        book = Book("ISBN-101", "Python")

        with self.assertRaises(AttributeError):
            book.isbn = "ISBN-999"

    def test_book_equality(self):
        b1 = Book("ISBN-101", "Python")
        b2 = Book("ISBN-101", "Advanced Python")

        self.assertEqual(b1, b2)

    def test_book_hash(self):
        b1 = Book("ISBN-101", "Python")
        b2 = Book("ISBN-101", "Advanced Python")

        self.assertEqual(hash(b1), hash(b2))

    def test_book_repr(self):
        book = Book("ISBN-101", "Python")

        self.assertEqual(
            repr(book),
            "Book('ISBN-101', 'Python')"
        )

    def test_library_add_book(self):
        library = Library()

        book = Book("ISBN-101", "Python")
        library.add_book(book)

        self.assertEqual(len(library), 1)

    def test_library_contains(self):
        library = Library()

        book = Book("ISBN-101", "Python")
        library.add_book(book)

        self.assertTrue("ISBN-101" in library)
        self.assertFalse("ISBN-999" in library)

    def test_library_iteration(self):
        library = Library()

        b1 = Book("1", "A")
        b2 = Book("2", "B")

        library.add_book(b1)
        library.add_book(b2)

        self.assertEqual(list(library), [b1, b2])

    def test_library_indexing(self):
        library = Library()

        b1 = Book("1", "A")
        b2 = Book("2", "B")

        library.add_book(b1)
        library.add_book(b2)

        self.assertEqual(library[0], b1)
        self.assertEqual(library[:], [b1, b2])

    def test_set_deduplication(self):
        b1 = Book("ISBN-101", "Python")
        b2 = Book("ISBN-101", "Duplicate")

        self.assertEqual(len({b1, b2}), 1)


if __name__ == "__main__":
    unittest.main()
