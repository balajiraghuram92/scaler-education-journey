from library import Library
from models import Book


def main():
    library = Library()

    book1 = Book("ISBN-101", "Python Basics")
    book2 = Book("ISBN-102", "Advanced Python")

    library.add_book(book1)
    library.add_book(book2)

    print(len(library))
    print("ISBN-101" in library)
    print(library[0])

    for book in library:
        print(book)

    print({book1, Book("ISBN-101", "Duplicate")})


if __name__ == "__main__":
    main()