from car import Car
from bike import Bike
from auto import Auto


def main():
    vehicles = [
        Car("CAR101", 4),
        Bike("BIKE101"),
        Auto("AUTO101")
    ]

    distance = 5

    for vehicle in vehicles:
        print(vehicle.calculate_fare(distance))


if __name__ == "__main__":
    main()