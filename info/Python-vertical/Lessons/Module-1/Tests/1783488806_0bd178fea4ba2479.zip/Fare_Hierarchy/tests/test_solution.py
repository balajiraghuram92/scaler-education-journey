import unittest

from vehicle import Vehicle
from car import Car
from bike import Bike
from auto import Auto


class VehicleTests(unittest.TestCase):

    def test_vehicle_initialization(self):
        vehicle = Vehicle("V101")

        self.assertEqual(vehicle.reg_number, "V101")
        self.assertTrue(vehicle.is_available)

    def test_vehicle_fare(self):
        vehicle = Vehicle("V101")
        self.assertEqual(vehicle.calculate_fare(10), 100)

    def test_car_initialization(self):
        car = Car("C101", 4)

        self.assertEqual(car.reg_number, "C101")
        self.assertEqual(car.seats, 4)
        self.assertTrue(car.is_available)

    def test_car_fare(self):
        car = Car("C101", 4)
        self.assertEqual(car.calculate_fare(10), 150)

    def test_bike_fare(self):
        bike = Bike("B101")
        self.assertEqual(bike.calculate_fare(10), 70)

    def test_auto_fare_above_minimum(self):
        auto = Auto("A101")
        self.assertEqual(auto.calculate_fare(5), 55)

    def test_auto_fare_minimum(self):
        auto = Auto("A101")
        self.assertEqual(auto.calculate_fare(2), 30)

    def test_polymorphism(self):
        vehicles = [
            Car("C101", 4),
            Bike("B101"),
            Auto("A101"),
            Vehicle("V101")
        ]

        fares = [vehicle.calculate_fare(10) for vehicle in vehicles]

        self.assertEqual(fares, [150, 70, 110, 100])


if __name__ == "__main__":
    unittest.main()