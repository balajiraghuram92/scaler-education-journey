import unittest

from audit_protocol import Auditable
from gateway import (
    PaymentGateway,
    PhonePeGateway,
    RazorpayGateway,
    PaytmGateway,
    run_audit_check,
)


class VendorGateway:
    def record_audit(self, event):
        pass


class InvalidGateway:
    pass


class PaymentGatewayTests(unittest.TestCase):

    def test_registry(self):
        self.assertIs(PaymentGateway.registry["phonepe"], PhonePeGateway)
        self.assertIs(PaymentGateway.registry["razorpay"], RazorpayGateway)
        self.assertIs(PaymentGateway.registry["paytm"], PaytmGateway)

    def test_process_payment_records_audit(self):
        gateway = PhonePeGateway()

        gateway.process_payment(100)

        self.assertEqual(
            gateway.audit_trail,
            ["Processed payment of 100"]
        )

    def test_refund_records_audit(self):
        gateway = RazorpayGateway()

        gateway.refund(50)

        self.assertEqual(
            gateway.audit_trail,
            ["Refunded 50"]
        )

    def test_multiple_audit_events(self):
        gateway = PaytmGateway()

        gateway.process_payment(500)
        gateway.refund(200)

        self.assertEqual(
            gateway.audit_trail,
            [
                "Processed payment of 500",
                "Refunded 200"
            ]
        )

    def test_protocol_on_gateway(self):
        gateway = PhonePeGateway()

        self.assertIsInstance(gateway, Auditable)
        self.assertTrue(run_audit_check(gateway))

    def test_protocol_on_vendor(self):
        vendor = VendorGateway()

        self.assertIsInstance(vendor, Auditable)
        self.assertTrue(run_audit_check(vendor))

    def test_invalid_object(self):
        obj = InvalidGateway()

        self.assertFalse(run_audit_check(obj))
        self.assertNotIsInstance(obj, Auditable)

    def test_gateway_is_abstract(self):
        with self.assertRaises(TypeError):
            PaymentGateway()


if __name__ == "__main__":
    unittest.main()
