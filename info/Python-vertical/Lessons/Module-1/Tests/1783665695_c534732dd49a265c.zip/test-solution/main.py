from gateway import (
    PaymentGateway,
    PhonePeGateway,
    RazorpayGateway,
    PaytmGateway,
    run_audit_check
)


def main():
    gateway = PaymentGateway.registry["phonepe"]()

    gateway.process_payment(500)
    gateway.refund(200)

    print(gateway.audit_trail)
    print(run_audit_check(gateway))


if __name__ == "__main__":
    main()
