import unittest

from library import Library
from models import Member, Novel, Loan


class NonBorrowable:
    pass


class LibraryTests(unittest.TestCase):

    def setUp(self):
        self.library = Library()
        self.member = Member("Alice")
        self.book = Novel("The Hobbit")

    def test_successful_lending(self):
        loan = self.library.lend_book(self.member, self.book)

        self.assertIsInstance(loan, Loan)
        self.assertFalse(self.book.is_available)
        self.assertEqual(self.member.borrowed, 1)

    def test_return_book(self):
        self.library.lend_book(self.member, self.book)
        self.library.return_book(self.member, self.book)

        self.assertTrue(self.book.is_available)
        self.assertEqual(self.member.borrowed, 0)

    def test_non_borrowable_item(self):
        with self.assertRaises(TypeError):
            self.library.lend_book(self.member, NonBorrowable())

    def test_book_not_available(self):
        self.book.is_available = False

        with self.assertRaises(ValueError) as context:
            self.library.lend_book(self.member, self.book)

        self.assertEqual(str(context.exception), "Book not available")

    def test_borrow_limit_reached(self):
        member = Member("Bob", borrow_limit=1)

        first_book = Novel("Book 1")
        second_book = Novel("Book 2")

        self.library.lend_book(member, first_book)

        with self.assertRaises(ValueError) as context:
            self.library.lend_book(member, second_book)

        self.assertEqual(str(context.exception), "Borrow limit reached")

    def test_multiple_borrow_and_return(self):
        member = Member("Charlie", borrow_limit=2)

        first_book = Novel("Book 1")
        second_book = Novel("Book 2")

        self.library.lend_book(member, first_book)
        self.library.lend_book(member, second_book)

        self.assertEqual(member.borrowed, 2)

        self.library.return_book(member, first_book)

        self.assertEqual(member.borrowed, 1)
        self.assertTrue(first_book.is_available)


if __name__ == "__main__":
    unittest.main()
