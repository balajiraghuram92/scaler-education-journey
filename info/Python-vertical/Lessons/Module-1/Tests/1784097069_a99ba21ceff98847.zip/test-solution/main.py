from library import Library
from models import Member, Novel


def main():
    library = Library()

    member = Member("Alice")
    book = Novel("The Hobbit")

    loan = library.lend_book(member, book)

    print(loan.member.name)
    print(loan.book.title)

    library.return_book(member, book)

    print(book.is_available)


if __name__ == "__main__":
    main()

