# Frequency Count(Assignment)
## Problem Statement

You are given an array of integers, and you need to count the frequency of each integer present in the array using a 
`Dicitonary` and return the map as the answer.

- Use `Dicitonary` to solve the question.
- The keys of the dicitonary are the elements of the array.
- The values of the dicitonary are the frequencies of those elements.


## Instructions
1. Implement the `count_frequency` method.
2. You don't need to print anything, just implement the function and return the dicitonary that stores the elements 
and their frequencies.
3. The order of the keys inside the dicitonary does not matter.