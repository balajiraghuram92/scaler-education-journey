import unittest

from eta_protocol import ETAProvider
from eta_service import InternalETAProvider, get_eta
from vendor_map import VendorMapETA


class InvalidProvider:
    pass


class CustomProvider:
    def estimate_minutes(self, origin, destination) -> float:
        return 25.5


class ETAProviderTests(unittest.TestCase):

    def test_internal_provider_satisfies_protocol(self):
        provider = InternalETAProvider()
        self.assertIsInstance(provider, ETAProvider)

    def test_vendor_provider_satisfies_protocol(self):
        provider = VendorMapETA()
        self.assertIsInstance(provider, ETAProvider)

    def test_custom_provider_satisfies_protocol(self):
        provider = CustomProvider()
        self.assertIsInstance(provider, ETAProvider)

    def test_invalid_provider(self):
        provider = InvalidProvider()

        self.assertNotIsInstance(provider, ETAProvider)

        with self.assertRaises(TypeError):
            get_eta(provider, "A", "B")

    def test_internal_provider_eta(self):
        provider = InternalETAProvider()

        eta = get_eta(provider, "Airport", "HSR")

        self.assertIsInstance(eta, (int, float))
        self.assertGreaterEqual(eta, 0)
        self.assertLess(eta, 60)

    def test_vendor_provider_eta(self):
        provider = VendorMapETA()

        self.assertEqual(
            get_eta(provider, "Airport", "HSR"),
            42.0
        )

    def test_custom_provider_eta(self):
        provider = CustomProvider()

        self.assertEqual(
            get_eta(provider, "A", "B"),
            25.5
        )


if __name__ == "__main__":
    unittest.main()