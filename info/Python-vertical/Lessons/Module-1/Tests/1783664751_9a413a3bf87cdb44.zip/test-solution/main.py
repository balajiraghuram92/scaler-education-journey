from eta_service import InternalETAProvider, get_eta
from vendor_map import VendorMapETA


def main():
    internal = InternalETAProvider()
    vendor = VendorMapETA()

    print(get_eta(internal, "Airport", "HSR"))
    print(get_eta(vendor, "Airport", "HSR"))


if __name__ == "__main__":
    main()
