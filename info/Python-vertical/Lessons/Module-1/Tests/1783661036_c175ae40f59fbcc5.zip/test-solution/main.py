from notification import NotificationChannel

def main():
    sms = NotificationChannel.registry["sms"]()
    sms.send("Alice", "Your cab has arrived.")

    email = NotificationChannel.registry["email"]()
    email.send("Bob", "Trip receipt")

    push = NotificationChannel.registry["push"]()
    push.send("Charlie", "Driver is nearby")


if __name__ == "__main__":
    main()
