import unittest
from abc import ABC

from notification import (
    NotificationChannel,
    SMSChannel,
    EmailChannel,
    PushChannel
)

class NotificationTests(unittest.TestCase):

    def test_registry_contains_all_channels(self):
        self.assertIs(NotificationChannel.registry["sms"], SMSChannel)
        self.assertIs(NotificationChannel.registry["email"], EmailChannel)
        self.assertIs(NotificationChannel.registry["push"], PushChannel)

    def test_sms_send_and_status(self):
        sms = SMSChannel()

        self.assertIsNone(sms.send("Alice", "Hello"))
        self.assertEqual(sms.get_status("1"), "DELIVERED")

    def test_email_send_and_status(self):
        email = EmailChannel()

        self.assertIsNone(email.send("Bob", "Invoice"))
        self.assertEqual(email.get_status("2"), "DELIVERED")

    def test_push_send_and_status(self):
        push = PushChannel()

        self.assertIsNone(push.send("Charlie", "Driver arriving"))
        self.assertEqual(push.get_status("3"), "DELIVERED")

    def test_registry_can_create_objects(self):
        sms = NotificationChannel.registry["sms"]()
        email = NotificationChannel.registry["email"]()
        push = NotificationChannel.registry["push"]()

        self.assertIsInstance(sms, SMSChannel)
        self.assertIsInstance(email, EmailChannel)
        self.assertIsInstance(push, PushChannel)

    def test_abstract_class_cannot_be_instantiated(self):
        with self.assertRaises(TypeError):
            NotificationChannel()

    def test_missing_abstract_method_prevents_instantiation(self):
        class DummyChannel(NotificationChannel):
            def send(self, user, message):
                pass

        with self.assertRaises(TypeError):
            DummyChannel()

    def test_init_subclass_auto_registration(self):
        class TestChannel(NotificationChannel, channel_name="test"):
            def send(self, user, message):
                pass

            def get_status(self, message_id):
                return "OK"

        self.assertIs(NotificationChannel.registry["test"], TestChannel)


if __name__ == "__main__":
    unittest.main()
