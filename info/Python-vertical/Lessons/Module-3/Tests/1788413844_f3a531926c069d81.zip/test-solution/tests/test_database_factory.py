import unittest
from database import Database
from database_factory import DatabaseFactory
from database_type import DatabaseType
from databases.mysql_database import MySQLDatabase
from databases.postgresql_database import PostgreSQLDatabase
from databases.mongodb_database import MongoDBDatabase

class TestDatabaseFactory(unittest.TestCase):
    def test_create_mysql_database(self):
        db = DatabaseFactory.create_database(DatabaseType.MYSQL, "My MySQL")
        self.assertIsInstance(db, MySQLDatabase, "Factory should return a MySQLDatabase instance.")
        self.assertEqual(db.get_database_name(), "My MySQL")
        self.assertEqual(db.supports_type(), DatabaseType.MYSQL)

    def test_create_postgresql_database(self):
        db = DatabaseFactory.create_database(DatabaseType.POSTGRE_SQL, "My PostgreSQL")
        self.assertIsInstance(db, PostgreSQLDatabase, "Factory should return a PostgreSQLDatabase instance.")
        self.assertEqual(db.get_database_name(), "My PostgreSQL")
        self.assertEqual(db.supports_type(), DatabaseType.POSTGRE_SQL)

    def test_create_mongodb_database(self):
        db = DatabaseFactory.create_database(DatabaseType.MONGO_DB, "My MongoDB")
        self.assertIsInstance(db, MongoDBDatabase, "Factory should return a MongoDBDatabase instance.")
        self.assertEqual(db.get_database_name(), "My MongoDB")
        self.assertEqual(db.supports_type(), DatabaseType.MONGO_DB)

    def test_anti_bypass_inheritance(self):
        """
        Anti-bypass check: Ensure the student actually made the concrete classes 
        inherit from the Database abstract base class, and that Database 
        itself is an Abstract Base Class (ABC).
        """
        import inspect
        from abc import ABC
        
        self.assertTrue(issubclass(Database, ABC), "Database must inherit from ABC (Abstract Base Class).")
        self.assertTrue(issubclass(MySQLDatabase, Database), "MySQLDatabase MUST inherit from Database.")
        self.assertTrue(issubclass(PostgreSQLDatabase, Database), "PostgreSQLDatabase MUST inherit from Database.")
        self.assertTrue(issubclass(MongoDBDatabase, Database), "MongoDBDatabase MUST inherit from Database.")

    def test_anti_bypass_super_init(self):
        """
        Anti-bypass check: Ensure the student called super().__init__ 
        and isn't just duplicating the self.database_name attribute locally.
        """
        db = MySQLDatabase("TestName")
        
        self.assertTrue(hasattr(db, 'get_database_name'), "Must have get_database_name method.")
        
        # Check if the method is actually inherited from Database rather than locally defined
        self.assertNotIn('get_database_name', MySQLDatabase.__dict__, 
                         "You should remove get_database_name from MySQLDatabase and inherit it from Database.")
        self.assertIn('get_database_name', Database.__dict__, 
                      "get_database_name should be implemented in the Database parent class.")

if __name__ == '__main__':
    unittest.main()
