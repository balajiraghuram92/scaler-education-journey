# Factory Design Pattern - Database Connection

## Problem Statement
You are building an application with which you need to connect to a Database. Depending on the `DatabaseType` (e.g., `MYSQL`, `POSTGRE_SQL`, `MONGO_DB`), a different type of database object must be instantiated. You need a way to create these database objects without explicitly specifying their classes or exposing the instantiation logic to the client, ensuring the application is open for future database types.

Your task is to implement the **Factory Design Pattern** to create these Database objects.

## Your Task

1. **Refactor the `Database` Parent Class** (in `database.py`):
   - We have provided the `Database` Abstract Base Class. It currently only requires `supports_type()`.
   - You must update this base class to include the common initialization logic (specifically setting the `database_name` attribute) and a common abstract method for `database_connection()`.

2. **Refactor the Concrete Database Classes** (in the `databases/` directory):
   - Review `mysql_database.py`, `postgresql_database.py`, and `mongodb_database.py`.
   - They currently duplicate the initialization of `database_name` and lack proper structural inheritance.
   - Refactor them to correctly inherit from your `Database` parent class, calling `super().__init__(database_name)`. Remove redundant duplicate fields.

3. **Implement the Factory** (in `database_factory.py`):
   - Implement the `create_database` method in `DatabaseFactory`. 
   - This method should use the Simple Factory pattern to instantiate and return the correct concrete database class based on the passed `DatabaseType`.
