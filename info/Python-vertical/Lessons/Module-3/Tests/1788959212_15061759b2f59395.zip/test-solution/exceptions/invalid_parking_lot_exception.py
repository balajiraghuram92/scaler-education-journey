class InvalidParkingLotException(Exception):
    """
    Raised when no parking lot is found for the specified gate or ID.
    """

    def __init__(self, message: str = ""):
        super().__init__(message)
