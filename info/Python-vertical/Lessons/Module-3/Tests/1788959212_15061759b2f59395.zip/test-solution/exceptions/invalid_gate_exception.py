class InvalidGateException(Exception):
    """
    Raised when a gate ID does not exist or the gate type is invalid for the requested operation.
    """

    def __init__(self, message: str = ""):
        super().__init__(message)
