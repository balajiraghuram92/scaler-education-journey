class AdditionalServiceNotSupportedByVehicle(Exception):
    """
    Raised when an opted additional service is not supported by the customer's vehicle type.
    """

    def __init__(self, message: str = ""):
        super().__init__(message)
