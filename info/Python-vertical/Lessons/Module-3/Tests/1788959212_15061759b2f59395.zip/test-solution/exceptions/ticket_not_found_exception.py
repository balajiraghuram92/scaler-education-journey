class TicketNotFoundException(Exception):
    """
    Raised when a ticket with the specified ID is not found.
    """

    def __init__(self, message: str = ""):
        super().__init__(message)
