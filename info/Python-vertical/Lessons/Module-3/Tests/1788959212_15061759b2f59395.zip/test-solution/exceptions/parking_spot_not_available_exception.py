class ParkingSpotNotAvailableException(Exception):
    """
    Raised when no parking spot matching the vehicle type is available in the parking lot.
    """

    def __init__(self, message: str = ""):
        super().__init__(message)
