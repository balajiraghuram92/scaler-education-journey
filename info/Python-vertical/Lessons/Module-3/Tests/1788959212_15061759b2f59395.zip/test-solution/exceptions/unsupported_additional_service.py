class UnsupportedAdditionalService(Exception):
    """
    Raised when an unrecognized or unsupported additional service string is provided.
    """

    def __init__(self, message: str = ""):
        super().__init__(message)
