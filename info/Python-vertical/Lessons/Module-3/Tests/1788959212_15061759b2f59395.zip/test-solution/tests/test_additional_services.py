import os
import sys
import unittest
from datetime import datetime, timedelta

# Ensure workspace root and parent directories are in sys.path
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..", "..")))
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))

from controllers.invoice_controller import InvoiceController
from controllers.ticket_controller import TicketController
from dtos.generate_invoice_request_dto import GenerateInvoiceRequestDto
from dtos.generate_ticket_request_dto import GenerateTicketRequestDto
from dtos.response_status import ResponseStatus
from exceptions.additional_service_not_supported_by_vehicle import AdditionalServiceNotSupportedByVehicle
from exceptions.invalid_gate_exception import InvalidGateException
from exceptions.invalid_parking_lot_exception import InvalidParkingLotException
from exceptions.parking_spot_not_available_exception import ParkingSpotNotAvailableException
from exceptions.ticket_not_found_exception import TicketNotFoundException
from exceptions.unsupported_additional_service import UnsupportedAdditionalService
from models.additional_service import AdditionalService
from models.floor_status import FloorStatus
from models.gate import Gate
from models.gate_type import GateType
from models.parking_attendant import ParkingAttendant
from models.parking_floor import ParkingFloor
from models.parking_lot import ParkingLot
from models.parking_spot import ParkingSpot
from models.parking_spot_status import ParkingSpotStatus
from models.slab import Slab
from models.vehicle_type import VehicleType
from repositories.gate_repository_impl import GateRepositoryImpl
from repositories.invoice_repository_impl import InvoiceRepositoryImpl
from repositories.parking_lot_repository_impl import ParkingLotRepositoryImpl
from repositories.slab_repository_impl import SlabRepositoryImpl
from repositories.ticket_repository_impl import TicketRepositoryImpl
from repositories.vehicle_repository_impl import VehicleRepositoryImpl
from services.invoice_service_impl import InvoiceServiceImpl
from services.ticket_service_impl import TicketServiceImpl
from strategies.assign_nearest_available_spot_strategy import AssignNearestAvailableSpotStrategy
from strategies.pricing_strategy_factory import PricingStrategyFactory
from strategies.weekday_pricing_strategy import WeekdayPricingStrategy
from strategies.weekend_pricing_strategy import WeekendPricingStrategy
from utils.date_time_utils import DateTimeUtils


def _setup_test_environment():
    """
    Sets up a full in-memory parking lot environment with gates, floors, spots, slabs,
    repositories, services, and controllers.
    """
    gate_repo = GateRepositoryImpl()
    lot_repo = ParkingLotRepositoryImpl()
    vehicle_repo = VehicleRepositoryImpl()
    ticket_repo = TicketRepositoryImpl()
    invoice_repo = InvoiceRepositoryImpl()
    slab_repo = SlabRepositoryImpl()
    assignment_strategy = AssignNearestAvailableSpotStrategy()
    pricing_factory = PricingStrategyFactory(slab_repository=slab_repo)

    attendant = ParkingAttendant(id=1, name="John Doe", email="john@example.com")
    entry_gate = Gate(id=1, name="North Entry Gate", gate_type=GateType.ENTRY, parking_attendant=attendant)
    exit_gate = Gate(id=2, name="South Exit Gate", gate_type=GateType.EXIT, parking_attendant=attendant)
    gate_repo.save(entry_gate)
    gate_repo.save(exit_gate)

    spots_f1 = [
        ParkingSpot(id=1, number=101, supported_vehicle_type=VehicleType.CAR, status=ParkingSpotStatus.AVAILABLE),
        ParkingSpot(id=2, number=102, supported_vehicle_type=VehicleType.SUV, status=ParkingSpotStatus.AVAILABLE),
        ParkingSpot(id=3, number=103, supported_vehicle_type=VehicleType.BIKE, status=ParkingSpotStatus.AVAILABLE),
        ParkingSpot(id=4, number=104, supported_vehicle_type=VehicleType.EV_CAR, status=ParkingSpotStatus.AVAILABLE),
        ParkingSpot(id=5, number=105, supported_vehicle_type=VehicleType.EV_BIKE, status=ParkingSpotStatus.AVAILABLE),
    ]
    floor1 = ParkingFloor(id=1, spots=spots_f1, floor_number=1, status=FloorStatus.OPERATIONAL)

    lot = ParkingLot(
        id=1,
        name="Tech City Parking",
        address="100 Silicon Way",
        parking_floors=[floor1],
        gates=[entry_gate, exit_gate]
    )
    lot_repo.save(lot)

    # Populate car slabs for weekend pricing
    # 0-2: 20/hr, 2-4: 30/hr, 4-6: 40/hr, 6-(-1): 50/hr
    slab_repo.save(Slab(id=1, vehicle_type=VehicleType.CAR, start_hour=0, end_hour=2, price=20.0))
    slab_repo.save(Slab(id=2, vehicle_type=VehicleType.CAR, start_hour=2, end_hour=4, price=30.0))
    slab_repo.save(Slab(id=3, vehicle_type=VehicleType.CAR, start_hour=4, end_hour=6, price=40.0))
    slab_repo.save(Slab(id=4, vehicle_type=VehicleType.CAR, start_hour=6, end_hour=-1, price=50.0))

    ticket_service = TicketServiceImpl(
        gate_repository=gate_repo,
        vehicle_repository=vehicle_repo,
        spot_assignment_strategy=assignment_strategy,
        parking_lot_repository=lot_repo,
        ticket_repository=ticket_repo
    )
    invoice_service = InvoiceServiceImpl(
        ticket_repository=ticket_repo,
        pricing_strategy_factory=pricing_factory,
        gate_repository=gate_repo,
        invoice_repository=invoice_repo
    )

    ticket_controller = TicketController(ticket_service=ticket_service)
    invoice_controller = InvoiceController(invoice_service=invoice_service)

    return {
        "gate_repo": gate_repo,
        "lot_repo": lot_repo,
        "vehicle_repo": vehicle_repo,
        "ticket_repo": ticket_repo,
        "invoice_repo": invoice_repo,
        "slab_repo": slab_repo,
        "ticket_service": ticket_service,
        "invoice_service": invoice_service,
        "ticket_controller": ticket_controller,
        "invoice_controller": invoice_controller,
        "entry_gate": entry_gate,
        "exit_gate": exit_gate,
        "parking_lot": lot,
    }


class TestAdditionalServicesRepositories(unittest.TestCase):
    """
    Tests all concrete repository implementations.
    """

    def setUp(self):
        self.env = _setup_test_environment()

    def test_gate_repository(self):
        repo = self.env["gate_repo"]
        self.assertIsNotNone(repo.find_by_id(1))
        self.assertIsNotNone(repo.find_by_id(2))
        self.assertIsNone(repo.find_by_id(999))

    def test_parking_lot_repository(self):
        repo = self.env["lot_repo"]
        self.assertIsNotNone(repo.get_parking_lot_by_gate_id(1))
        self.assertIsNotNone(repo.get_parking_lot_by_gate_id(2))
        self.assertIsNone(repo.get_parking_lot_by_gate_id(999))
        self.assertIsNotNone(repo.get_parking_lot_by_id(1))

    def test_slab_repository_sorting(self):
        repo = self.env["slab_repo"]
        slabs = repo.get_sorted_slabs_by_vehicle_type(VehicleType.CAR)
        self.assertEqual(len(slabs), 4)
        hours = [s.start_hour for s in slabs]
        self.assertEqual(hours, [0, 2, 4, 6])


class TestPricingStrategies(unittest.TestCase):
    """
    Tests Weekday and Weekend pricing strategies and DateTimeUtils.
    """

    def setUp(self):
        self.env = _setup_test_environment()
        self.slab_repo = self.env["slab_repo"]

    def test_datetime_utils_rounding(self):
        base = datetime(2026, 9, 8, 10, 0, 0)
        # Exact 1 hour
        self.assertEqual(DateTimeUtils.calculate_hours(base, base + timedelta(hours=1)), 1)
        # 1 hour 1 minute -> rounded to 2 hours
        self.assertEqual(DateTimeUtils.calculate_hours(base, base + timedelta(hours=1, minutes=1)), 2)
        # 1 hour 30 minutes -> rounded to 2 hours
        self.assertEqual(DateTimeUtils.calculate_hours(base, base + timedelta(hours=1, minutes=30)), 2)

    def test_weekday_pricing(self):
        strategy = WeekdayPricingStrategy()
        base = datetime(2026, 9, 8, 10, 0, 0)  # Tuesday
        # 1 hour
        self.assertEqual(strategy.calculate_amount(base, base + timedelta(hours=1), VehicleType.CAR), 10.0)
        # 1.5 hours (rounds to 2)
        self.assertEqual(strategy.calculate_amount(base, base + timedelta(hours=1, minutes=30), VehicleType.CAR), 20.0)
        # 5 hours
        self.assertEqual(strategy.calculate_amount(base, base + timedelta(hours=5), VehicleType.BIKE), 50.0)

    def test_weekend_pricing_slabs(self):
        strategy = WeekendPricingStrategy(self.slab_repo)
        base = datetime(2026, 9, 12, 10, 0, 0)  # Saturday
        # 1 hour: 1 * 20 = 20
        self.assertEqual(strategy.calculate_amount(base, base + timedelta(hours=1), VehicleType.CAR), 20.0)
        # 3 hours: (2 * 20) + (1 * 30) = 70
        self.assertEqual(strategy.calculate_amount(base, base + timedelta(hours=3), VehicleType.CAR), 70.0)
        # 5 hours: (2 * 20) + (2 * 30) + (1 * 40) = 140
        self.assertEqual(strategy.calculate_amount(base, base + timedelta(hours=5), VehicleType.CAR), 140.0)
        # 7 hours: (2 * 20) + (2 * 30) + (2 * 40) + (1 * 50) = 230
        self.assertEqual(strategy.calculate_amount(base, base + timedelta(hours=7), VehicleType.CAR), 230.0)

    def test_pricing_strategy_factory(self):
        factory = PricingStrategyFactory(self.slab_repo)
        # Friday (weekday 4) -> Weekday
        friday = datetime(2026, 9, 11, 14, 0, 0)
        self.assertIsInstance(factory.get_pricing_strategy(friday), WeekdayPricingStrategy)
        # Saturday (weekday 5) -> Weekend
        saturday = datetime(2026, 9, 12, 14, 0, 0)
        self.assertIsInstance(factory.get_pricing_strategy(saturday), WeekendPricingStrategy)
        # Sunday (weekday 6) -> Weekend
        sunday = datetime(2026, 9, 13, 14, 0, 0)
        self.assertIsInstance(factory.get_pricing_strategy(sunday), WeekendPricingStrategy)
        # Monday (weekday 0) -> Weekday
        monday = datetime(2026, 9, 14, 14, 0, 0)
        self.assertIsInstance(factory.get_pricing_strategy(monday), WeekdayPricingStrategy)


class TestTicketService(unittest.TestCase):
    """
    Tests TicketServiceImpl ticket generation, additional services compatibility, and validation.
    """

    def setUp(self):
        self.env = _setup_test_environment()
        self.service = self.env["ticket_service"]

    def test_generate_ticket_success_with_additional_service(self):
        ticket = self.service.generate_ticket(
            gate_id=1,
            registration_number="KA-01-HH-1234",
            vehicle_type="CAR",
            additional_services=["CAR_WASH"]
        )
        self.assertIsNotNone(ticket)
        self.assertEqual(ticket.vehicle.registration_number, "KA-01-HH-1234")
        self.assertEqual(ticket.parking_spot.status, ParkingSpotStatus.OCCUPIED)
        self.assertEqual(len(ticket.additional_services), 1)
        self.assertEqual(ticket.additional_services[0], AdditionalService.CAR_WASH)

    def test_generate_ticket_multiple_services(self):
        ticket = self.service.generate_ticket(
            gate_id=1,
            registration_number="KA-01-HH-9999",
            vehicle_type="CAR",
            additional_services=["CAR_WASH", "CAR_DETAILING"]
        )
        self.assertIsNotNone(ticket)
        self.assertEqual(len(ticket.additional_services), 2)
        self.assertIn(AdditionalService.CAR_WASH, ticket.additional_services)
        self.assertIn(AdditionalService.CAR_DETAILING, ticket.additional_services)

    def test_generate_ticket_no_services(self):
        ticket = self.service.generate_ticket(
            gate_id=1,
            registration_number="KA-01-HH-0001",
            vehicle_type="CAR",
            additional_services=[]
        )
        self.assertIsNotNone(ticket)
        self.assertEqual(len(ticket.additional_services), 0)

    def test_invalid_gate_id(self):
        with self.assertRaises(InvalidGateException):
            self.service.generate_ticket(gate_id=999, registration_number="KA-01-HH-0002", vehicle_type="CAR")

    def test_exit_gate_cannot_generate_ticket(self):
        with self.assertRaises(InvalidGateException):
            self.service.generate_ticket(gate_id=2, registration_number="KA-01-HH-0003", vehicle_type="CAR")

    def test_unsupported_additional_service(self):
        with self.assertRaises(UnsupportedAdditionalService):
            self.service.generate_ticket(
                gate_id=1,
                registration_number="KA-01-HH-0004",
                vehicle_type="CAR",
                additional_services=["FLYING_CAR_CLEANING"]
            )

    def test_incompatible_additional_service_bike_with_car_wash(self):
        with self.assertRaises(AdditionalServiceNotSupportedByVehicle):
            self.service.generate_ticket(
                gate_id=1,
                registration_number="KA-01-BK-1111",
                vehicle_type="BIKE",
                additional_services=["CAR_WASH"]
            )

    def test_incompatible_additional_service_car_with_ev_bike_charging(self):
        with self.assertRaises(AdditionalServiceNotSupportedByVehicle):
            self.service.generate_ticket(
                gate_id=1,
                registration_number="KA-01-CR-2222",
                vehicle_type="CAR",
                additional_services=["EV_BIKE_CHARGING"]
            )

    def test_spot_occupied_exhaustion(self):
        # CAR spot is at ID 1 (only 1 car spot in floor1)
        t1 = self.service.generate_ticket(gate_id=1, registration_number="CAR-1", vehicle_type="CAR")
        self.assertIsNotNone(t1)
        # Second CAR should raise ParkingSpotNotAvailableException
        with self.assertRaises(ParkingSpotNotAvailableException):
            self.service.generate_ticket(gate_id=1, registration_number="CAR-2", vehicle_type="CAR")


class TestInvoiceService(unittest.TestCase):
    """
    Tests InvoiceServiceImpl invoice creation, weekday/weekend fee calculations, and freeing spot.
    """

    def setUp(self):
        self.env = _setup_test_environment()
        self.ticket_service = self.env["ticket_service"]
        self.invoice_service = self.env["invoice_service"]

    def test_create_invoice_weekday_parking_only(self):
        ticket = self.ticket_service.generate_ticket(
            gate_id=1, registration_number="KA-01-AA-1111", vehicle_type="CAR"
        )
        # Simulate 2 hours stay on a weekday (Tuesday)
        ticket.entry_time = datetime(2026, 9, 8, 10, 0, 0)
        exit_time = datetime(2026, 9, 8, 12, 0, 0)

        invoice = self.invoice_service.create_invoice(ticket_id=ticket.id, gate_id=2, exit_time=exit_time)
        self.assertIsNotNone(invoice)
        # 2 hours * 10 = 20.0
        self.assertEqual(invoice.amount, 20.0)
        # Spot must be freed
        self.assertEqual(ticket.parking_spot.status, ParkingSpotStatus.AVAILABLE)

    def test_create_invoice_weekday_with_car_wash(self):
        ticket = self.ticket_service.generate_ticket(
            gate_id=1,
            registration_number="KA-01-AA-2222",
            vehicle_type="CAR",
            additional_services=["CAR_WASH"]
        )
        # 1.5 hours on Tuesday (rounds to 2 hours -> 20.0 parking + 200.0 car wash = 220.0)
        ticket.entry_time = datetime(2026, 9, 8, 10, 0, 0)
        exit_time = datetime(2026, 9, 8, 11, 30, 0)

        invoice = self.invoice_service.create_invoice(ticket_id=ticket.id, gate_id=2, exit_time=exit_time)
        self.assertEqual(invoice.amount, 220.0)

    def test_create_invoice_weekend_with_slabs_and_services(self):
        ticket = self.ticket_service.generate_ticket(
            gate_id=1,
            registration_number="KA-01-AA-3333",
            vehicle_type="CAR",
            additional_services=["CAR_WASH", "CAR_DETAILING"]
        )
        # 5 hours on Saturday (weekend):
        # Slabs: (2 * 20) + (2 * 30) + (1 * 40) = 140.0
        # Additional services: 200 (CAR_WASH) + 500 (CAR_DETAILING) = 700.0
        # Total = 140 + 700 = 840.0
        ticket.entry_time = datetime(2026, 9, 12, 9, 0, 0)
        exit_time = datetime(2026, 9, 12, 14, 0, 0)

        invoice = self.invoice_service.create_invoice(ticket_id=ticket.id, gate_id=2, exit_time=exit_time)
        self.assertEqual(invoice.amount, 840.0)

    def test_ticket_not_found_raises_exception(self):
        with self.assertRaises(TicketNotFoundException):
            self.invoice_service.create_invoice(ticket_id=9999, gate_id=2)

    def test_invalid_exit_gate_raises_exception(self):
        ticket = self.ticket_service.generate_ticket(
            gate_id=1, registration_number="KA-01-AA-4444", vehicle_type="CAR"
        )
        # Gate 999 does not exist
        with self.assertRaises(InvalidGateException):
            self.invoice_service.create_invoice(ticket_id=ticket.id, gate_id=999)
        # Gate 1 is an ENTRY gate, not an exit gate
        with self.assertRaises(InvalidGateException):
            self.invoice_service.create_invoice(ticket_id=ticket.id, gate_id=1)


class TestControllers(unittest.TestCase):
    """
    Tests TicketController and InvoiceController responses and graceful failure handling.
    """

    def setUp(self):
        self.env = _setup_test_environment()
        self.ticket_controller = self.env["ticket_controller"]
        self.invoice_controller = self.env["invoice_controller"]

    def test_ticket_controller_success(self):
        req = GenerateTicketRequestDto(
            gate_id=1,
            registration_number="KA-05-MM-1234",
            vehicle_type="CAR",
            additional_services=["CAR_WASH"]
        )
        res = self.ticket_controller.generate_ticket(req)
        self.assertEqual(res.response_status, ResponseStatus.SUCCESS)
        self.assertIsNotNone(res.ticket)
        self.assertEqual(res.ticket.vehicle.registration_number, "KA-05-MM-1234")

    def test_ticket_controller_failure_invalid_gate(self):
        req = GenerateTicketRequestDto(
            gate_id=-1,
            registration_number="KA-05-MM-1234",
            vehicle_type="CAR"
        )
        res = self.ticket_controller.generate_ticket(req)
        self.assertEqual(res.response_status, ResponseStatus.FAILURE)
        self.assertIsNone(res.ticket)

    def test_ticket_controller_failure_incompatible_service(self):
        req = GenerateTicketRequestDto(
            gate_id=1,
            registration_number="KA-05-BK-5678",
            vehicle_type="BIKE",
            additional_services=["CAR_WASH"]
        )
        res = self.ticket_controller.generate_ticket(req)
        self.assertEqual(res.response_status, ResponseStatus.FAILURE)
        self.assertIsNone(res.ticket)

    def test_invoice_controller_success(self):
        # Generate ticket first
        t_req = GenerateTicketRequestDto(
            gate_id=1,
            registration_number="KA-05-MM-9000",
            vehicle_type="CAR"
        )
        t_res = self.ticket_controller.generate_ticket(t_req)
        self.assertEqual(t_res.response_status, ResponseStatus.SUCCESS)

        inv_req = GenerateInvoiceRequestDto(ticket_id=t_res.ticket.id, gate_id=2)
        inv_res = self.invoice_controller.create_invoice(inv_req)
        self.assertEqual(inv_res.status, ResponseStatus.SUCCESS)
        self.assertEqual(inv_res.response_status, ResponseStatus.SUCCESS)
        self.assertIsNotNone(inv_res.invoice)
        self.assertGreaterEqual(inv_res.invoice.amount, 0.0)

    def test_invoice_controller_failure_invalid_ticket_id(self):
        inv_req = GenerateInvoiceRequestDto(ticket_id=0, gate_id=2)
        inv_res = self.invoice_controller.create_invoice(inv_req)
        self.assertEqual(inv_res.status, ResponseStatus.FAILURE)
        self.assertEqual(inv_res.response_status, ResponseStatus.FAILURE)
        self.assertIsNone(inv_res.invoice)

    def test_invoice_controller_failure_negative_gate_id(self):
        inv_req = GenerateInvoiceRequestDto(ticket_id=1, gate_id=-5)
        inv_res = self.invoice_controller.create_invoice(inv_req)
        self.assertEqual(inv_res.status, ResponseStatus.FAILURE)
        self.assertIsNone(inv_res.invoice)


if __name__ == "__main__":
    unittest.main()
