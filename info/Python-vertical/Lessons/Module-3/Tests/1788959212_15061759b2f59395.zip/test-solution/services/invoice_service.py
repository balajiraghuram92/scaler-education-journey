from abc import ABC, abstractmethod
from models.invoice import Invoice


class InvoiceService(ABC):
    """
    Defines the contract for the invoice generation service.

    TODO (for student):
    -------------------
    Create a concrete class called InvoiceServiceImpl that implements this ABC.
    Constructor dependencies:
      - ticket_repository: TicketRepository
      - pricing_strategy_factory: PricingStrategyFactory
      - gate_repository: GateRepository
      - invoice_repository: InvoiceRepository

    Implement:
      create_invoice(ticket_id: int, gate_id: int) -> Invoice:
        1. Look up ticket via ticket_repository.get_ticket_by_id(ticket_id).
           - If not found, raise TicketNotFoundException.
        2. Look up gate via gate_repository.find_by_id(gate_id).
           - If not found or gate is not an EXIT gate, raise InvalidGateException.
        3. Record current datetime as exit_time.
        4. Obtain the appropriate pricing strategy via pricing_strategy_factory.get_pricing_strategy(exit_time).
        5. Calculate parking fee = pricing_strategy.calculate_amount(ticket.entry_time, exit_time, ticket.vehicle.vehicle_type).
        6. Calculate additional services fee = sum(service.cost for service in ticket.additional_services).
        7. Total amount = parking_fee + additional_services_fee.
        8. Create and save Invoice(ticket=ticket, gate=gate, parking_attendant=gate.parking_attendant, exit_time=exit_time, amount=total_amount).
        9. Free the parking spot (spot.status = ParkingSpotStatus.AVAILABLE).
        10. Return the saved invoice.
    """

    @abstractmethod
    def create_invoice(self, ticket_id: int, gate_id: int) -> Invoice:
        pass
