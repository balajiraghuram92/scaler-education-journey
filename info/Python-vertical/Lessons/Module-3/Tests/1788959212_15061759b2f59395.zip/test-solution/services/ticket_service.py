from abc import ABC, abstractmethod
from typing import List, Optional
from models.ticket import Ticket


class TicketService(ABC):
    """
    Defines the contract for the ticket service with support for additional services.

    TODO (for student):
    -------------------
    Create a concrete class called TicketServiceImpl that implements this ABC.
    Constructor dependencies:
      - gate_repository: GateRepository
      - vehicle_repository: VehicleRepository
      - spot_assignment_strategy: SpotAssignmentStrategy
      - parking_lot_repository: ParkingLotRepository
      - ticket_repository: TicketRepository

    Implement:
      generate_ticket(gate_id, registration_number, vehicle_type, additional_services) -> Ticket:
        1. Look up gate via gate_repository.find_by_id(gate_id).
           - If gate is None or gate.gate_type == GateType.EXIT, raise InvalidGateException.
        2. Look up parking lot via parking_lot_repository.get_parking_lot_by_gate_id(gate_id).
           - If None, raise InvalidParkingLotException.
        3. Parse vehicle_type to VehicleType enum.
        4. Look up or create vehicle via vehicle_repository.
        5. Validate additional_services:
           - For each service string, convert to AdditionalService enum.
             If not valid, raise UnsupportedAdditionalService.
           - Check if the vehicle's vehicle_type is in service.supported_vehicle_types.
             If not, raise AdditionalServiceNotSupportedByVehicle.
        6. Assign spot using spot_assignment_strategy.assign_spot(parking_lot, vehicle_type_enum).
           - If None, raise ParkingSpotNotAvailableException.
           - Mark spot as OCCUPIED.
        7. Create Ticket with vehicle, entry_time=now, spot, gate, gate.parking_attendant, and additional_services.
        8. Save and return the ticket via ticket_repository.save(ticket).
    """

    @abstractmethod
    def generate_ticket(
        self,
        gate_id: int,
        registration_number: str,
        vehicle_type: str,
        additional_services: Optional[List[str]] = None
    ) -> Ticket:
        pass
