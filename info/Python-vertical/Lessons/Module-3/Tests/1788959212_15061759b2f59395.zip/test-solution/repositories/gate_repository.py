from abc import ABC, abstractmethod
from typing import Optional
from models.gate import Gate


class GateRepository(ABC):
    """
    Defines the contract for storing and retrieving gates.

    TODO (for student):
    -------------------
    Create a concrete class called InMemoryGateRepositoryImpl that implements this ABC.
    - Use a Python dictionary as your in-memory database: self._gates = {}
    - Use an auto-incrementing ID counter: self._current_id = 1

    Implement:
      1. find_by_id(gate_id: int) -> Optional[Gate]
         - Retrieve the gate with the given gate_id from self._gates.
         - Return None if not found.
      2. save(gate: Gate) -> Gate
         - If gate.id is None or <= 0, assign self._current_id and increment it.
         - Store the gate in self._gates using gate.id as the key.
         - Return the saved gate.
    """

    @abstractmethod
    def find_by_id(self, gate_id: int) -> Optional[Gate]:
        pass

    @abstractmethod
    def save(self, gate: Gate) -> Gate:
        pass
