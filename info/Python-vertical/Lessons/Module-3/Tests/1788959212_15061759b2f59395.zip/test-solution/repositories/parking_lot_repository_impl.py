from typing import Optional, Dict
from models.parking_lot import ParkingLot
from repositories.parking_lot_repository import ParkingLotRepository


class ParkingLotRepositoryImpl(ParkingLotRepository):
    """
    In-memory implementation of the ParkingLotRepository.
    """

    def __init__(self):
        self._parking_lots: Dict[int, ParkingLot] = {}
        self._current_id = 1

    def get_parking_lot_by_gate_id(self, gate_id: int) -> Optional[ParkingLot]:
        for parking_lot in self._parking_lots.values():
            if any(gate.id == gate_id for gate in parking_lot.gates):
                return parking_lot
        return None

    def get_parking_lot_by_id(self, parking_lot_id: int) -> Optional[ParkingLot]:
        return self._parking_lots.get(parking_lot_id)

    def save(self, parking_lot: ParkingLot) -> ParkingLot:
        if parking_lot.id is None or parking_lot.id == 0:
            parking_lot.id = self._current_id
            self._current_id += 1
        self._parking_lots[parking_lot.id] = parking_lot
        return parking_lot


InMemoryParkingLotRepositoryImpl = ParkingLotRepositoryImpl
