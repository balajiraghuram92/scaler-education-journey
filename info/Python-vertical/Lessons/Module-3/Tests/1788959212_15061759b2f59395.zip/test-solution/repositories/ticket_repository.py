from abc import ABC, abstractmethod
from typing import Optional
from models.ticket import Ticket


class TicketRepository(ABC):
    """
    Defines the contract for storing and retrieving tickets.

    TODO (for student):
    -------------------
    Create a concrete class called InMemoryTicketRepositoryImpl that implements this ABC.
    - Use a Python dictionary as your in-memory database: self._tickets = {}
    - Use an auto-incrementing ID counter: self._current_id = 1

    Implement:
      1. save(ticket: Ticket) -> Ticket
         - If ticket.id is None or <= 0, assign self._current_id and increment it.
         - Store and return the saved ticket.
      2. get_ticket_by_id(ticket_id: int) -> Optional[Ticket]
         - Retrieve the ticket with the given ticket_id from self._tickets.
         - Return None if not found.
    """

    @abstractmethod
    def save(self, ticket: Ticket) -> Ticket:
        pass

    @abstractmethod
    def get_ticket_by_id(self, ticket_id: int) -> Optional[Ticket]:
        pass
