from typing import Optional, Dict
from models.ticket import Ticket
from repositories.ticket_repository import TicketRepository


class TicketRepositoryImpl(TicketRepository):
    """
    In-memory implementation of the TicketRepository.
    """

    def __init__(self):
        self._tickets: Dict[int, Ticket] = {}
        self._current_id = 1

    def get_ticket_by_id(self, ticket_id: int) -> Optional[Ticket]:
        return self._tickets.get(ticket_id)

    def save(self, ticket: Ticket) -> Ticket:
        if ticket.id is None or ticket.id == 0:
            ticket.id = self._current_id
            self._current_id += 1
        self._tickets[ticket.id] = ticket
        return ticket


InMemoryTicketRepositoryImpl = TicketRepositoryImpl
