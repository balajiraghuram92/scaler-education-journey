from typing import Optional, Dict
from models.gate import Gate
from repositories.gate_repository import GateRepository


class GateRepositoryImpl(GateRepository):
    """
    In-memory implementation of the GateRepository.
    """

    def __init__(self):
        self._gates: Dict[int, Gate] = {}
        self._current_id = 1

    def find_by_id(self, gate_id: int) -> Optional[Gate]:
        return self._gates.get(gate_id)

    def save(self, gate: Gate) -> Gate:
        if gate.id is None or gate.id == 0:
            gate.id = self._current_id
            self._current_id += 1
        self._gates[gate.id] = gate
        return gate


InMemoryGateRepositoryImpl = GateRepositoryImpl
