from abc import ABC, abstractmethod
from typing import List
from models.slab import Slab
from models.vehicle_type import VehicleType


class SlabRepository(ABC):
    """
    Defines the contract for storing and querying pricing slabs.

    TODO (for student):
    -------------------
    Create a concrete class called SlabRepositoryImpl that implements this ABC.
    - Use a Python dictionary as your in-memory database: self._slabs = {}
    - Use an auto-incrementing ID counter: self._current_id = 1

    Implement:
      1. get_sorted_slabs_by_vehicle_type(vehicle_type: VehicleType) -> List[Slab]
         - Return all slabs for the specified vehicle_type, sorted in ascending order of start_hour.
      2. save(slab: Slab) -> Slab
         - If slab.id is None or <= 0, assign self._current_id and increment it.
         - Store and return the saved slab.
    """

    @abstractmethod
    def get_sorted_slabs_by_vehicle_type(self, vehicle_type: VehicleType) -> List[Slab]:
        pass

    @abstractmethod
    def save(self, slab: Slab) -> Slab:
        pass
