from typing import Optional, Dict
from models.invoice import Invoice
from repositories.invoice_repository import InvoiceRepository


class InvoiceRepositoryImpl(InvoiceRepository):
    """
    In-memory implementation of the InvoiceRepository.
    """

    def __init__(self):
        self._invoices: Dict[int, Invoice] = {}
        self._current_id = 1

    def get_invoice_by_id(self, invoice_id: int) -> Optional[Invoice]:
        return self._invoices.get(invoice_id)

    def save(self, invoice: Invoice) -> Invoice:
        if invoice.id is None or invoice.id == 0:
            invoice.id = self._current_id
            self._current_id += 1
        self._invoices[invoice.id] = invoice
        return invoice


InMemoryInvoiceRepositoryImpl = InvoiceRepositoryImpl
