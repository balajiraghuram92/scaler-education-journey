from typing import Optional, Dict
from models.vehicle import Vehicle
from repositories.vehicle_repository import VehicleRepository


class VehicleRepositoryImpl(VehicleRepository):
    """
    In-memory implementation of the VehicleRepository.
    """

    def __init__(self):
        self._vehicles: Dict[int, Vehicle] = {}
        self._current_id = 1

    def get_vehicle_by_registration_number(self, registration_number: str) -> Optional[Vehicle]:
        for vehicle in self._vehicles.values():
            if vehicle.registration_number == registration_number:
                return vehicle
        return None

    def save(self, vehicle: Vehicle) -> Vehicle:
        if vehicle.id is None or vehicle.id == 0:
            vehicle.id = self._current_id
            self._current_id += 1
        self._vehicles[vehicle.id] = vehicle
        return vehicle


InMemoryVehicleRepositoryImpl = VehicleRepositoryImpl
