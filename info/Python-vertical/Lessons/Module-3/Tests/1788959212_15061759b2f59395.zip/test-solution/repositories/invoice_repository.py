from abc import ABC, abstractmethod
from models.invoice import Invoice


class InvoiceRepository(ABC):
    """
    Defines the contract for storing and retrieving invoices.

    TODO (for student):
    -------------------
    Create a concrete class called InMemoryInvoiceRepositoryImpl that implements this ABC.
    - Use a Python dictionary as your in-memory database: self._invoices = {}
    - Use an auto-incrementing ID counter: self._current_id = 1

    Implement:
      save(invoice: Invoice) -> Invoice
        - If invoice.id is None or <= 0, assign self._current_id and increment it.
        - Store and return the saved invoice.
    """

    @abstractmethod
    def save(self, invoice: Invoice) -> Invoice:
        pass
