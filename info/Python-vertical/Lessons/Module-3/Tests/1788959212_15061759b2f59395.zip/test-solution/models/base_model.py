from datetime import datetime
from typing import Optional


class BaseModel:
    """
    Parent class for domain models providing an id and audit timestamps.
    """

    def __init__(self, id: Optional[int] = None):
        self.id = id
        self.created_at = datetime.now()
        self.updated_at = datetime.now()
