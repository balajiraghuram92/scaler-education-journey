from typing import List, Optional
from models.base_model import BaseModel
from models.floor_status import FloorStatus
from models.parking_spot import ParkingSpot


class ParkingFloor(BaseModel):
    """
    Represents a floor in a parking lot containing multiple parking spots.
    """

    def __init__(
        self,
        id: Optional[int] = None,
        spots: Optional[List[ParkingSpot]] = None,
        floor_number: int = 0,
        status: FloorStatus = FloorStatus.OPERATIONAL
    ):
        super().__init__(id)
        self.spots = spots if spots is not None else []
        self.floor_number = floor_number
        self.status = status
