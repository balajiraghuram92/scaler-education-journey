from typing import Optional
from models.base_model import BaseModel
from models.vehicle_type import VehicleType


class Vehicle(BaseModel):
    """
    Represents a vehicle registered or parked in the parking lot.
    """

    def __init__(
        self,
        id: Optional[int] = None,
        registration_number: str = "",
        vehicle_type: Optional[VehicleType] = None
    ):
        super().__init__(id)
        self.registration_number = registration_number
        self.vehicle_type = vehicle_type
