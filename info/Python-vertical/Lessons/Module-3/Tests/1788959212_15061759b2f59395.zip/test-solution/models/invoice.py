from datetime import datetime
from typing import Optional
from models.base_model import BaseModel
from models.gate import Gate
from models.parking_attendant import ParkingAttendant
from models.ticket import Ticket


class Invoice(BaseModel):
    """
    Represents an invoice generated at exit containing the parking fee
    and any additional services fee.
    """

    def __init__(
        self,
        id: Optional[int] = None,
        ticket: Optional[Ticket] = None,
        gate: Optional[Gate] = None,
        parking_attendant: Optional[ParkingAttendant] = None,
        exit_time: Optional[datetime] = None,
        amount: float = 0.0
    ):
        super().__init__(id)
        self.ticket = ticket
        self.gate = gate
        self.parking_attendant = parking_attendant
        self.exit_time = exit_time if exit_time is not None else datetime.now()
        self.amount = amount
