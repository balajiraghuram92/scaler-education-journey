from typing import Optional
from models.base_model import BaseModel
from models.parking_spot_status import ParkingSpotStatus
from models.vehicle_type import VehicleType


class ParkingSpot(BaseModel):
    """
    Represents an individual parking spot on a parking floor.
    """

    def __init__(
        self,
        id: Optional[int] = None,
        number: int = 0,
        supported_vehicle_type: Optional[VehicleType] = None,
        status: ParkingSpotStatus = ParkingSpotStatus.AVAILABLE
    ):
        super().__init__(id)
        self.number = number
        self.supported_vehicle_type = supported_vehicle_type
        self.status = status
