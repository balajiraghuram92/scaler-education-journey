from enum import Enum


class VehicleType(Enum):
    CAR = "CAR"
    BIKE = "BIKE"
    TRUCK = "TRUCK"
    SUV = "SUV"
    EV_CAR = "EV_CAR"
    EV_BIKE = "EV_BIKE"
