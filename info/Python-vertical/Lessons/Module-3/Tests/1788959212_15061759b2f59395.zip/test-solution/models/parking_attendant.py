from typing import Optional
from models.base_model import BaseModel


class ParkingAttendant(BaseModel):
    """
    Represents an attendant stationed at a parking lot gate.
    """

    def __init__(self, id: Optional[int] = None, name: str = "", email: str = ""):
        super().__init__(id)
        self.name = name
        self.email = email
