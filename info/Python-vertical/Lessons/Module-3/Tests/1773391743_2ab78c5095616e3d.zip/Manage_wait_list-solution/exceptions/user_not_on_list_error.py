class UserNotOnListError(Exception):
    pass
