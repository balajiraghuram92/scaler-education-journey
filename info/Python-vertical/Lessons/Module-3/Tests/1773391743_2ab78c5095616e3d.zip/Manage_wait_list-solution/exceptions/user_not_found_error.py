class UserNotFoundError(Exception):
    pass
