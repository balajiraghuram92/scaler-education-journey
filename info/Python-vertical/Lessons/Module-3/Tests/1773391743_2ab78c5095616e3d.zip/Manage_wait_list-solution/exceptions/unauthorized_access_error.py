class UnauthorizedAccessError(Exception):
    pass
