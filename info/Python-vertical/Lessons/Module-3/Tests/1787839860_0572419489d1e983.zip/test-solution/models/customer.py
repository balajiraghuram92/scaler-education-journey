from typing import List
from models.base_model import BaseModel
from models.invoice import Invoice

class Customer(BaseModel):
    def __init__(self):
        super().__init__()
        self.name: str = ""
        self.invoices: List[Invoice] = []