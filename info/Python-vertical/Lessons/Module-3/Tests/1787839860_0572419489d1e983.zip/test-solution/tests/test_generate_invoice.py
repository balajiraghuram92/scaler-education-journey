import unittest
from models.user import User
from models.room import Room
from models.customer_session import CustomerSession
from models.customer_session_status import CustomerSessionStatus
from models.booking import Booking
from dtos.generate_invoice_request_dto import GenerateInvoiceRequestDto
from dtos.response_status import ResponseStatus
from repositories.customer_session_repository_impl import CustomerSessionRepositoryImpl
from repositories.booking_repository_impl import BookingRepositoryImpl
from services.booking_service_impl import BookingServiceImpl
from controllers.booking_controller import BookingController

class TestGenerateInvoice(unittest.TestCase):
    def setUp(self):
        self.session_repo = CustomerSessionRepositoryImpl()
        self.booking_repo = BookingRepositoryImpl()
        self.service = BookingServiceImpl(self.session_repo, self.booking_repo)
        self.controller = BookingController(self.service)

    def test_generate_invoice_success_multiple_bookings(self):
        # Setup User
        user = User()
        user.name = "Test User"
        user.id = 1
        
        # Setup Session
        session = CustomerSession()
        session.user = user
        session.customer_session_status = CustomerSessionStatus.ACTIVE
        self.session_repo.save(session)
        
        # Setup Rooms
        room1 = Room()
        room1.id = 1
        room1.price = 1000.0
        
        room2 = Room()
        room2.id = 2
        room2.price = 2000.0
        
        # Setup Booking 1
        booking1 = Booking()
        booking1.customer_session = session
        booking1.booked_rooms = {room1: 2} # Room 1 for 2 days
        self.booking_repo.save(booking1)
        
        # Setup Booking 2
        booking2 = Booking()
        booking2.customer_session = session
        booking2.booked_rooms = {room1: 1, room2: 3} # Room 1 for 1 day, Room 2 for 3 days
        self.booking_repo.save(booking2)

        # Total cost: 
        # Room 1: 3 days * 1000 = 3000
        # Room 2: 3 days * 2000 = 6000
        # Total = 9000
        # GST = 9000 * 0.18 = 1620
        # Service Charge = 9000 * 0.10 = 900
        
        req = GenerateInvoiceRequestDto()
        req.user_id = 1
        
        res = self.controller.generate_invoice(req)
        
        self.assertEqual(res.response_status, ResponseStatus.SUCCESS)
        self.assertIsNotNone(res.invoice)
        self.assertEqual(res.invoice.total_amount, 9000.0)
        self.assertEqual(res.invoice.gst, 1620.0)
        self.assertEqual(res.invoice.service_charge, 900.0)
        
        # Verify that overlapping bookings were properly aggregated
        self.assertEqual(len(res.invoice.booked_rooms), 2)
        self.assertEqual(res.invoice.booked_rooms[room1], 3) # 2 days + 1 day
        self.assertEqual(res.invoice.booked_rooms[room2], 3) # 3 days
        
        self.assertEqual(session.customer_session_status, CustomerSessionStatus.ENDED)

    def test_generate_invoice_success_no_bookings(self):
        user = User()
        user.id = 2
        
        session = CustomerSession()
        session.user = user
        session.customer_session_status = CustomerSessionStatus.ACTIVE
        self.session_repo.save(session)
        
        req = GenerateInvoiceRequestDto()
        req.user_id = 2
        
        res = self.controller.generate_invoice(req)
        
        self.assertEqual(res.response_status, ResponseStatus.SUCCESS)
        self.assertIsNotNone(res.invoice)
        self.assertEqual(res.invoice.total_amount, 0.0)
        self.assertEqual(res.invoice.gst, 0.0)
        self.assertEqual(res.invoice.service_charge, 0.0)
        self.assertEqual(len(res.invoice.booked_rooms), 0)
        self.assertEqual(session.customer_session_status, CustomerSessionStatus.ENDED)

    def test_generate_invoice_failure_no_active_session(self):
        user = User()
        user.id = 3
        
        # Session exists but is ended
        session = CustomerSession()
        session.user = user
        session.customer_session_status = CustomerSessionStatus.ENDED
        self.session_repo.save(session)
        
        req = GenerateInvoiceRequestDto()
        req.user_id = 3
        
        res = self.controller.generate_invoice(req)
        
        self.assertEqual(res.response_status, ResponseStatus.FAILURE)
        self.assertIsNone(res.invoice)

    def test_generate_invoice_failure_no_session_at_all(self):
        req = GenerateInvoiceRequestDto()
        req.user_id = 99
        
        res = self.controller.generate_invoice(req)
        
        self.assertEqual(res.response_status, ResponseStatus.FAILURE)
        self.assertIsNone(res.invoice)

if __name__ == '__main__':
    unittest.main()