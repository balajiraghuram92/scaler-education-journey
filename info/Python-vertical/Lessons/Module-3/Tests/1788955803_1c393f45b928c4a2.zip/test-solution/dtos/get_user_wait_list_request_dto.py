class GetUserWaitListRequestDto:
    """
    The input object sent to the getWaitListStatus functionality.

    Attributes:
        user_id : the ID of the registered customer whose position we want to check
    """

    def __init__(self, user_id: int):
        self.user_id = user_id
