from dtos.response_status import ResponseStatus


class GetUserWaitListResponseDto:
    """
    The output object returned from the getWaitListStatus functionality.

    Attributes:
        position        : the customer's current position in the wait list,
                          or -1 if they are not in the wait list
        response_status : SUCCESS if the user was found, FAILURE if not
    """

    def __init__(self, response_status: ResponseStatus, position: int = 0):
        self.response_status = response_status
        self.position = position
