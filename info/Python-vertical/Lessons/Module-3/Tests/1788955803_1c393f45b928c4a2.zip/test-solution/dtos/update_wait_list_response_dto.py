from dtos.response_status import ResponseStatus


class UpdateWaitListResponseDto:
    """
    The output object returned from the updateWaitList functionality.

    Attributes:
        response_status : SUCCESS if the removal was done, FAILURE if admin not found
                          or if a non-admin tried to call this functionality
    """

    def __init__(self, response_status: ResponseStatus):
        self.response_status = response_status
