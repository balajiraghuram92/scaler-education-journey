from dtos.response_status import ResponseStatus


class AddUserToWaitListResponseDto:
    """
    The output object returned from the addUserToWaitList functionality.

    Attributes:
        position        : the customer's position in the wait list (1-based index)
        response_status : SUCCESS if added successfully, FAILURE if user was not found
    """

    def __init__(self, response_status: ResponseStatus, position: int = 0):
        self.response_status = response_status
        self.position = position
