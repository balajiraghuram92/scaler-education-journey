from enum import Enum


class ResponseStatus(Enum):
    """
    Used by the controller to communicate the overall result of an operation
    back to the caller.

    SUCCESS -> the operation completed without any errors
    FAILURE -> something went wrong (e.g. user not found, access denied)
    """
    SUCCESS = "SUCCESS"
    FAILURE = "FAILURE"
