class UpdateWaitListRequestDto:
    """
    The input object sent to the updateWaitList functionality (admin only).

    Attributes:
        user_id        : the ID of the admin making the request
        number_of_seats: how many customers to remove from the front of the wait list
    """

    def __init__(self, user_id: int, number_of_seats: int):
        self.user_id = user_id
        self.number_of_seats = number_of_seats
