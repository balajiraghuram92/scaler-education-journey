class AddUserToWaitListRequestDto:
    """
    The input object sent to the addUserToWaitList functionality.

    Attributes:
        user_id : the ID of the registered customer to add to the wait list
    """

    def __init__(self, user_id: int):
        self.user_id = user_id
