from abc import ABC, abstractmethod
from typing import List
from models.wait_list_position import WaitListPosition


class WaitListPositionRepository(ABC):
    """
    Defines the contract for how wait list entries are stored and managed.

    The wait list is an ordered list of WaitListPosition entries.
    The order is preserved by insertion order — the first person added is at position 1.

    TODO (for student):
    -------------------
    Create a concrete class called WaitListPositionRepositoryImpl that implements this ABC.
    - Use a Python list as your in-memory store: self._wait_list = []
      (A list preserves insertion order, which is exactly what we need for a wait list.)

    Implement:
      1. save(wait_list_position)   -> assign an ID, append to self._wait_list, return it.
      2. find_all()                 -> return a copy of self._wait_list
                                       (returns all entries in insertion order).
      3. delete(wait_list_position) -> remove the entry from self._wait_list and return it.
    """

    @abstractmethod
    def save(self, wait_list_position: WaitListPosition) -> WaitListPosition:
        """
        Adds a new WaitListPosition entry to the wait list.

        Args:
            wait_list_position : the entry to add

        Returns:
            The same entry, now with its id field populated.
        """
        pass

    @abstractmethod
    def find_all(self) -> List[WaitListPosition]:
        """
        Returns all entries currently in the wait list, in insertion order.

        Returns:
            A list of WaitListPosition objects (empty list if no one is waiting).
        """
        pass

    @abstractmethod
    def delete(self, wait_list_position: WaitListPosition) -> WaitListPosition:
        """
        Removes a specific WaitListPosition entry from the wait list.

        Args:
            wait_list_position : the entry to remove

        Returns:
            The removed WaitListPosition entry.
        """
        pass
