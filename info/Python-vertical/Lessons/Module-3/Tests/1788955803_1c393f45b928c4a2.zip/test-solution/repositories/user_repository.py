from abc import ABC, abstractmethod
from typing import Optional
from models.user import User


class UserRepository(ABC):
    """
    Defines the contract for how users are stored and retrieved.

    TODO (for student):
    -------------------
    Create a concrete class called UserRepositoryImpl that implements this ABC.
    - Use a Python dictionary as your in-memory database: self._users = {}
    - Use an integer counter for auto-incrementing IDs: self._current_id = 1

    Implement:
      1. save(user)       -> assign the current _current_id to user.id, store in
                             the dictionary, increment the counter, return the user.
      2. find_by_id(id)   -> return self._users.get(user_id)
                             This returns the User if found, or None if not found.
    """

    @abstractmethod
    def save(self, user: User) -> User:
        """
        Saves a User to the repository and returns it with its assigned ID.

        Args:
            user : the User object to save

        Returns:
            The same User object, now with its id field populated.
        """
        pass

    @abstractmethod
    def find_by_id(self, user_id: int) -> Optional[User]:
        """
        Looks up a user by their unique ID.

        Args:
            user_id : the ID of the user to find

        Returns:
            The User object if found, or None if no user with that ID exists.
        """
        pass
