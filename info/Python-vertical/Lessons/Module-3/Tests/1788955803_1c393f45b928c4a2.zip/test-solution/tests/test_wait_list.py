import unittest

from controllers.wait_list_controller import WaitListController
from dtos.add_user_to_wait_list_request_dto import AddUserToWaitListRequestDto
from dtos.get_user_wait_list_request_dto import GetUserWaitListRequestDto
from dtos.response_status import ResponseStatus
from dtos.update_wait_list_request_dto import UpdateWaitListRequestDto
from models.user import User
from models.user_type import UserType
from repositories.user_repository_impl import UserRepositoryImpl
from repositories.wait_list_position_repository_impl import WaitListPositionRepositoryImpl
from services.wait_list_service_impl import WaitListServiceImpl


# ---------------------------------------------------------------------------
# Helper — builds a fresh controller with clean in-memory repos each time
# ---------------------------------------------------------------------------

def _make_controller():
    """Creates a WaitListController wired to fresh in-memory repositories."""
    user_repo = UserRepositoryImpl()
    wait_list_repo = WaitListPositionRepositoryImpl()
    service = WaitListServiceImpl(user_repo, wait_list_repo)
    controller = WaitListController(service)
    return controller, user_repo, wait_list_repo


# ===========================================================================
# Test Suite 1 — UserRepositoryImpl
# ===========================================================================

class TestUserRepository(unittest.TestCase):
    """Tests that the user repository stores and retrieves users correctly."""

    def setUp(self):
        self.repo = UserRepositoryImpl()

    def test_save_assigns_id_starting_at_1(self):
        """The first saved user must receive ID = 1."""
        user = self.repo.save(User("Alice", UserType.USER))
        self.assertEqual(user.id, 1)

    def test_save_increments_id_for_each_user(self):
        """Each subsequent user must get the next integer ID."""
        u1 = self.repo.save(User("Alice", UserType.USER))
        u2 = self.repo.save(User("Bob", UserType.ADMIN))
        u3 = self.repo.save(User("Charlie", UserType.USER))
        self.assertEqual(u1.id, 1)
        self.assertEqual(u2.id, 2)
        self.assertEqual(u3.id, 3)

    def test_find_by_id_returns_correct_user(self):
        """find_by_id() must return the exact user that was saved with that ID."""
        user = self.repo.save(User("Alice", UserType.USER))
        found = self.repo.find_by_id(user.id)
        self.assertIs(found, user)

    def test_find_by_id_returns_none_for_missing_id(self):
        """Searching for an ID that was never saved must return None."""
        self.assertIsNone(self.repo.find_by_id(999))

    def test_find_by_id_returns_none_on_empty_repo(self):
        """Even before any user is saved, find_by_id() must safely return None."""
        self.assertIsNone(self.repo.find_by_id(1))

    def test_save_returns_the_same_user_object(self):
        """save() must return the same user object it was given (not a copy)."""
        user = User("Alice", UserType.USER)
        saved = self.repo.save(user)
        self.assertIs(saved, user)


# ===========================================================================
# Test Suite 2 — WaitListPositionRepositoryImpl
# ===========================================================================

class TestWaitListPositionRepository(unittest.TestCase):
    """Tests that the wait list repository manages entries correctly."""

    def setUp(self):
        self.user_repo = UserRepositoryImpl()
        self.wait_list_repo = WaitListPositionRepositoryImpl()
        self.user = self.user_repo.save(User("Alice", UserType.USER))

    def _make_entry(self):
        from models.wait_list_position import WaitListPosition
        from datetime import datetime
        return WaitListPosition(user=self.user, inserted_at=datetime.now())

    def test_find_all_returns_empty_list_initially(self):
        """Before any entry is saved, find_all() must return an empty list."""
        self.assertEqual(self.wait_list_repo.find_all(), [])

    def test_save_adds_entry_to_list(self):
        """After saving one entry, find_all() must return a list of length 1."""
        self.wait_list_repo.save(self._make_entry())
        self.assertEqual(len(self.wait_list_repo.find_all()), 1)

    def test_save_assigns_id(self):
        """Saved entries must receive auto-incremented IDs."""
        e1 = self.wait_list_repo.save(self._make_entry())
        e2 = self.wait_list_repo.save(self._make_entry())
        self.assertEqual(e1.id, 1)
        self.assertEqual(e2.id, 2)

    def test_find_all_preserves_insertion_order(self):
        """Entries must be returned in insertion order (first added = first in list)."""
        user2 = self.user_repo.save(User("Bob", UserType.USER))
        from models.wait_list_position import WaitListPosition
        from datetime import datetime
        e1 = self.wait_list_repo.save(WaitListPosition(self.user, datetime.now()))
        e2 = self.wait_list_repo.save(WaitListPosition(user2, datetime.now()))
        result = self.wait_list_repo.find_all()
        self.assertIs(result[0], e1)
        self.assertIs(result[1], e2)

    def test_delete_removes_entry(self):
        """After deleting an entry, find_all() must not contain it."""
        entry = self.wait_list_repo.save(self._make_entry())
        self.wait_list_repo.delete(entry)
        self.assertEqual(len(self.wait_list_repo.find_all()), 0)

    def test_delete_returns_the_removed_entry(self):
        """delete() must return the entry it removed."""
        entry = self.wait_list_repo.save(self._make_entry())
        removed = self.wait_list_repo.delete(entry)
        self.assertIs(removed, entry)

    def test_find_all_returns_copy_not_internal_list(self):
        """Modifying the returned list must not affect the repository's internal state."""
        self.wait_list_repo.save(self._make_entry())
        result = self.wait_list_repo.find_all()
        result.clear()
        self.assertEqual(len(self.wait_list_repo.find_all()), 1)


# ===========================================================================
# Test Suite 3 — Task 1: addUserToWaitList
# ===========================================================================

class TestAddUserToWaitList(unittest.TestCase):
    """End-to-end tests for the add_user_to_wait_list controller method."""

    def setUp(self):
        self.controller, self.user_repo, self.wait_list_repo = _make_controller()

    # --- Happy path ---

    def test_registered_user_gets_success_response(self):
        """A registered user must get ResponseStatus.SUCCESS."""
        user = self.user_repo.save(User("Alice", UserType.USER))
        response = self.controller.add_user_to_wait_list(AddUserToWaitListRequestDto(user.id))
        self.assertEqual(response.response_status, ResponseStatus.SUCCESS)

    def test_first_user_added_gets_position_1(self):
        """The first user added must be at position 1."""
        user = self.user_repo.save(User("Alice", UserType.USER))
        response = self.controller.add_user_to_wait_list(AddUserToWaitListRequestDto(user.id))
        self.assertEqual(response.position, 1)

    def test_second_user_gets_position_2(self):
        """The second user added must be at position 2."""
        u1 = self.user_repo.save(User("Alice", UserType.USER))
        u2 = self.user_repo.save(User("Bob", UserType.USER))
        self.controller.add_user_to_wait_list(AddUserToWaitListRequestDto(u1.id))
        response = self.controller.add_user_to_wait_list(AddUserToWaitListRequestDto(u2.id))
        self.assertEqual(response.position, 2)

    def test_adding_same_user_twice_returns_existing_position(self):
        """
        Adding the same user a second time must NOT create a duplicate entry.
        Instead, it must return their existing position.
        """
        user = self.user_repo.save(User("Alice", UserType.USER))
        r1 = self.controller.add_user_to_wait_list(AddUserToWaitListRequestDto(user.id))
        r2 = self.controller.add_user_to_wait_list(AddUserToWaitListRequestDto(user.id))
        self.assertEqual(r1.position, r2.position)
        # Anti-bypass: the wait list must still only have 1 entry
        self.assertEqual(len(self.wait_list_repo.find_all()), 1)

    def test_adding_same_user_twice_does_not_create_duplicate(self):
        """The wait list size must remain 1 after adding the same user twice."""
        user = self.user_repo.save(User("Alice", UserType.USER))
        self.controller.add_user_to_wait_list(AddUserToWaitListRequestDto(user.id))
        self.controller.add_user_to_wait_list(AddUserToWaitListRequestDto(user.id))
        self.assertEqual(len(self.wait_list_repo.find_all()), 1)

    # --- Failure path ---

    def test_unregistered_user_gets_failure_response(self):
        """A user_id not in the database must return ResponseStatus.FAILURE."""
        response = self.controller.add_user_to_wait_list(AddUserToWaitListRequestDto(999))
        self.assertEqual(response.response_status, ResponseStatus.FAILURE)

    def test_invalid_user_id_zero_returns_failure(self):
        """User ID 0 is not valid — must return FAILURE without crashing."""
        response = self.controller.add_user_to_wait_list(AddUserToWaitListRequestDto(0))
        self.assertEqual(response.response_status, ResponseStatus.FAILURE)

    def test_negative_user_id_returns_failure(self):
        """A negative user ID is not valid — must return FAILURE."""
        response = self.controller.add_user_to_wait_list(AddUserToWaitListRequestDto(-5))
        self.assertEqual(response.response_status, ResponseStatus.FAILURE)

    def test_wait_list_grows_correctly_with_multiple_users(self):
        """After adding 3 different users, the wait list must contain exactly 3 entries."""
        for name in ["Alice", "Bob", "Charlie"]:
            user = self.user_repo.save(User(name, UserType.USER))
            self.controller.add_user_to_wait_list(AddUserToWaitListRequestDto(user.id))
        self.assertEqual(len(self.wait_list_repo.find_all()), 3)


# ===========================================================================
# Test Suite 4 — Task 2: getWaitListStatus
# ===========================================================================

class TestGetWaitListStatus(unittest.TestCase):
    """End-to-end tests for the get_wait_list_status controller method."""

    def setUp(self):
        self.controller, self.user_repo, self.wait_list_repo = _make_controller()

    # --- Happy path ---

    def test_user_in_wait_list_gets_correct_position(self):
        """A user who is in the wait list must get their correct 1-based position."""
        user = self.user_repo.save(User("Alice", UserType.USER))
        self.controller.add_user_to_wait_list(AddUserToWaitListRequestDto(user.id))
        response = self.controller.get_wait_list_status(GetUserWaitListRequestDto(user.id))
        self.assertEqual(response.response_status, ResponseStatus.SUCCESS)
        self.assertEqual(response.position, 1)

    def test_user_not_in_wait_list_gets_minus_one(self):
        """A registered user who never joined the wait list must get position = -1."""
        user = self.user_repo.save(User("Alice", UserType.USER))
        response = self.controller.get_wait_list_status(GetUserWaitListRequestDto(user.id))
        self.assertEqual(response.response_status, ResponseStatus.SUCCESS)
        self.assertEqual(response.position, -1)

    def test_second_user_gets_position_2_in_status(self):
        """The second user added must get position 2 when their status is checked."""
        u1 = self.user_repo.save(User("Alice", UserType.USER))
        u2 = self.user_repo.save(User("Bob", UserType.USER))
        self.controller.add_user_to_wait_list(AddUserToWaitListRequestDto(u1.id))
        self.controller.add_user_to_wait_list(AddUserToWaitListRequestDto(u2.id))
        response = self.controller.get_wait_list_status(GetUserWaitListRequestDto(u2.id))
        self.assertEqual(response.position, 2)

    # --- Failure path ---

    def test_unregistered_user_gets_failure(self):
        """A user_id not in the database must return FAILURE."""
        response = self.controller.get_wait_list_status(GetUserWaitListRequestDto(999))
        self.assertEqual(response.response_status, ResponseStatus.FAILURE)

    def test_invalid_user_id_zero_returns_failure(self):
        """User ID 0 must return FAILURE without crashing."""
        response = self.controller.get_wait_list_status(GetUserWaitListRequestDto(0))
        self.assertEqual(response.response_status, ResponseStatus.FAILURE)


# ===========================================================================
# Test Suite 5 — Task 3: updateWaitList
# ===========================================================================

class TestUpdateWaitList(unittest.TestCase):
    """End-to-end tests for the update_wait_list (admin remove) controller method."""

    def setUp(self):
        self.controller, self.user_repo, self.wait_list_repo = _make_controller()
        # Create an admin and 3 customers, add all 3 customers to the wait list
        self.admin = self.user_repo.save(User("AdminUser", UserType.ADMIN))
        self.users = []
        for name in ["Alice", "Bob", "Charlie"]:
            u = self.user_repo.save(User(name, UserType.USER))
            self.users.append(u)
            self.controller.add_user_to_wait_list(AddUserToWaitListRequestDto(u.id))

    # --- Happy path ---

    def test_admin_can_remove_one_customer(self):
        """An admin removing 1 customer must get SUCCESS and the list shrinks by 1."""
        response = self.controller.update_wait_list(
            UpdateWaitListRequestDto(self.admin.id, 1)
        )
        self.assertEqual(response.response_status, ResponseStatus.SUCCESS)
        self.assertEqual(len(self.wait_list_repo.find_all()), 2)

    def test_admin_can_remove_all_customers(self):
        """Removing exactly the number of customers in the list must empty the wait list."""
        self.controller.update_wait_list(UpdateWaitListRequestDto(self.admin.id, 3))
        self.assertEqual(len(self.wait_list_repo.find_all()), 0)

    def test_remove_more_than_list_size_empties_list(self):
        """
        If number_of_seats > wait list size, all entries must be removed
        (no error, no partial remove, no crash).
        """
        self.controller.update_wait_list(UpdateWaitListRequestDto(self.admin.id, 100))
        self.assertEqual(len(self.wait_list_repo.find_all()), 0)

    def test_remove_zero_customers_does_not_change_list(self):
        """Removing 0 customers must leave the wait list completely unchanged."""
        self.controller.update_wait_list(UpdateWaitListRequestDto(self.admin.id, 0))
        self.assertEqual(len(self.wait_list_repo.find_all()), 3)

    def test_remove_removes_from_front_not_back(self):
        """
        Removal must be from the FRONT of the wait list (the longest waiting customers
        are served first — FIFO order).
        After removing 1, the remaining entries must be Bob and Charlie, not Alice.
        """
        self.controller.update_wait_list(UpdateWaitListRequestDto(self.admin.id, 1))
        remaining = self.wait_list_repo.find_all()
        remaining_user_ids = [entry.user.id for entry in remaining]
        # Alice (first added) must be gone; Bob and Charlie must still be there
        self.assertNotIn(self.users[0].id, remaining_user_ids)
        self.assertIn(self.users[1].id, remaining_user_ids)
        self.assertIn(self.users[2].id, remaining_user_ids)

    # --- Unauthorized access ---

    def test_regular_user_cannot_remove_customers(self):
        """A USER (non-admin) trying to update the wait list must get FAILURE."""
        response = self.controller.update_wait_list(
            UpdateWaitListRequestDto(self.users[0].id, 1)
        )
        self.assertEqual(response.response_status, ResponseStatus.FAILURE)

    def test_regular_user_attempt_does_not_modify_wait_list(self):
        """
        After a non-admin user's failed update attempt, the wait list must be unchanged.
        Catches students who remove entries before checking the user type.
        """
        self.controller.update_wait_list(UpdateWaitListRequestDto(self.users[0].id, 1))
        self.assertEqual(len(self.wait_list_repo.find_all()), 3)

    # --- Failure path ---

    def test_unregistered_admin_id_returns_failure(self):
        """An admin_user_id that does not exist must return FAILURE."""
        response = self.controller.update_wait_list(UpdateWaitListRequestDto(999, 1))
        self.assertEqual(response.response_status, ResponseStatus.FAILURE)

    def test_invalid_admin_id_zero_returns_failure(self):
        """Admin ID 0 is invalid — must return FAILURE without crashing."""
        response = self.controller.update_wait_list(UpdateWaitListRequestDto(0, 1))
        self.assertEqual(response.response_status, ResponseStatus.FAILURE)

    def test_after_failed_update_subsequent_valid_update_succeeds(self):
        """
        After a failed update (e.g. wrong user), a subsequent valid admin update must succeed.
        Catches students whose service becomes stateful in a broken way after exceptions.
        """
        # Failed attempt by a non-admin
        self.controller.update_wait_list(UpdateWaitListRequestDto(self.users[0].id, 1))
        # Valid admin attempt must still work
        response = self.controller.update_wait_list(UpdateWaitListRequestDto(self.admin.id, 1))
        self.assertEqual(response.response_status, ResponseStatus.SUCCESS)
        self.assertEqual(len(self.wait_list_repo.find_all()), 2)


# ===========================================================================
# Test Suite 6 — Position consistency across operations
# ===========================================================================

class TestWaitListPositionConsistency(unittest.TestCase):
    """
    Tests that positions update correctly after wait list entries are removed.
    These are the trickiest anti-bypass tests — they verify that position
    numbers are always computed dynamically from the live list, not cached.
    """

    def setUp(self):
        self.controller, self.user_repo, self.wait_list_repo = _make_controller()
        self.admin = self.user_repo.save(User("Admin", UserType.ADMIN))
        self.u1 = self.user_repo.save(User("Alice", UserType.USER))
        self.u2 = self.user_repo.save(User("Bob", UserType.USER))
        self.u3 = self.user_repo.save(User("Charlie", UserType.USER))

    def test_position_updates_after_front_entry_removed(self):
        """
        After the admin removes 1 customer from the front, the second customer
        must now be at position 1, not position 2.
        Catches students who store position as a fixed integer instead of
        computing it dynamically from the list.
        """
        self.controller.add_user_to_wait_list(AddUserToWaitListRequestDto(self.u1.id))
        self.controller.add_user_to_wait_list(AddUserToWaitListRequestDto(self.u2.id))
        self.controller.add_user_to_wait_list(AddUserToWaitListRequestDto(self.u3.id))

        # Remove Alice (position 1)
        self.controller.update_wait_list(UpdateWaitListRequestDto(self.admin.id, 1))

        # Bob must now be at position 1, Charlie at position 2
        r_bob = self.controller.get_wait_list_status(GetUserWaitListRequestDto(self.u2.id))
        r_charlie = self.controller.get_wait_list_status(GetUserWaitListRequestDto(self.u3.id))
        self.assertEqual(r_bob.position, 1)
        self.assertEqual(r_charlie.position, 2)

    def test_removed_user_shows_minus_one_after_removal(self):
        """
        After the admin removes a customer, that customer's status check
        must return -1 (they are no longer in the wait list).
        """
        self.controller.add_user_to_wait_list(AddUserToWaitListRequestDto(self.u1.id))
        self.controller.update_wait_list(UpdateWaitListRequestDto(self.admin.id, 1))
        response = self.controller.get_wait_list_status(GetUserWaitListRequestDto(self.u1.id))
        self.assertEqual(response.response_status, ResponseStatus.SUCCESS)
        self.assertEqual(response.position, -1)

    def test_user_can_rejoin_wait_list_after_being_removed(self):
        """
        A customer who was removed from the wait list must be able to add
        themselves again and get a valid position.
        """
        self.controller.add_user_to_wait_list(AddUserToWaitListRequestDto(self.u1.id))
        self.controller.update_wait_list(UpdateWaitListRequestDto(self.admin.id, 1))
        # Alice rejoins
        response = self.controller.add_user_to_wait_list(AddUserToWaitListRequestDto(self.u1.id))
        self.assertEqual(response.response_status, ResponseStatus.SUCCESS)
        self.assertGreater(response.position, 0)


# ===========================================================================
# Run all tests
# ===========================================================================

if __name__ == "__main__":
    unittest.main(verbosity=2)
