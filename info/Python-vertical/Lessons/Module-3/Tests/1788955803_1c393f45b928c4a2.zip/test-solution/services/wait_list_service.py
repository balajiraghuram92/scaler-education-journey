from abc import ABC, abstractmethod
from exceptions.user_not_found_exception import UserNotFoundException
from exceptions.unauthorized_access_exception import UnauthorizedAccessException


class WaitListService(ABC):
    """
    Defines the contract for all wait list business logic.

    TODO (for student):
    -------------------
    Create a concrete class called WaitListServiceImpl that implements this ABC.
    The constructor should accept TWO dependencies:
      - A UserRepository        (to look up users)
      - A WaitListPositionRepository (to manage the wait list)

    Implement the three methods below:

    1. add_user_to_wait_list(user_id):
         Step 1 -> Use the UserRepository to find the user by user_id.
         Step 2 -> If not found, raise UserNotFoundException("User not found").
         Step 3 -> Check if the user is already in the wait list by searching
                   find_all() for an entry whose entry.user.id == user_id.
         Step 4 -> If already in the list, return their current 1-based position.
         Step 5 -> If not in the list, create a new WaitListPosition with the user
                   and the current datetime, save it, and return their position
                   (which is the length of the full list after saving).

    2. get_wait_list_position(user_id):
         Step 1 -> Use the UserRepository to find the user by user_id.
         Step 2 -> If not found, raise UserNotFoundException("User not found").
         Step 3 -> Search find_all() for an entry whose entry.user.id == user_id.
         Step 4 -> If found, return their 1-based position (index + 1).
         Step 5 -> If not found in the wait list, return -1.

    3. update_wait_list(admin_user_id, number_of_spots):
         Step 1 -> Use the UserRepository to find the user by admin_user_id.
         Step 2 -> If not found, raise UserNotFoundException("User not found").
         Step 3 -> If the user's user_type is NOT UserType.ADMIN,
                   raise UnauthorizedAccessException("Access Denied").
         Step 4 -> Determine how many to remove:
                   spots_to_remove = min(number_of_spots, len(find_all()))
         Step 5 -> Remove the first `spots_to_remove` entries from the wait list
                   by calling delete() on each one.
    """

    @abstractmethod
    def add_user_to_wait_list(self, user_id: int) -> int:
        """
        Adds a user to the wait list and returns their position.

        Args:
            user_id : the ID of the registered customer

        Returns:
            The customer's 1-based position in the wait list.

        Raises:
            UserNotFoundException: if user_id does not exist in the database.
        """
        pass

    @abstractmethod
    def get_wait_list_position(self, user_id: int) -> int:
        """
        Returns the current wait list position for a user.

        Args:
            user_id : the ID of the registered customer

        Returns:
            The customer's 1-based position in the wait list,
            or -1 if they are not currently in the wait list.

        Raises:
            UserNotFoundException: if user_id does not exist in the database.
        """
        pass

    @abstractmethod
    def update_wait_list(self, admin_user_id: int, number_of_spots: int) -> None:
        """
        Removes a given number of customers from the front of the wait list.
        Only an ADMIN user can call this method.

        Args:
            admin_user_id  : the ID of the user making the request (must be ADMIN)
            number_of_spots: how many customers to remove from the wait list

        Raises:
            UserNotFoundException:        if admin_user_id does not exist in the database.
            UnauthorizedAccessException:  if the user exists but is not an ADMIN.
        """
        pass
