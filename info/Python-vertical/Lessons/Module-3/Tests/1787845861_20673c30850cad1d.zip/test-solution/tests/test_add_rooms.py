import unittest
from models.user import User
from models.user_type import UserType
from models.room_type import RoomType
from dtos.add_room_request_dto import AddRoomRequestDto
from dtos.response_status import ResponseStatus
from repositories.user_repository_impl import UserRepositoryImpl
from repositories.room_repository_impl import RoomRepositoryImpl
from services.room_service_impl import RoomServiceImpl
from controllers.room_controller import RoomController

class TestAddRooms(unittest.TestCase):
    def setUp(self):
        self.user_repo = UserRepositoryImpl()
        self.room_repo = RoomRepositoryImpl()
        self.service = RoomServiceImpl(self.user_repo, self.room_repo)
        self.controller = RoomController(self.service)

    def test_add_room_success_admin(self):
        # Create an ADMIN user
        admin = User()
        admin.name = "Admin User"
        admin.user_type = UserType.ADMIN
        self.user_repo.save(admin)
        
        # Prepare Request
        req = AddRoomRequestDto()
        req.user_id = admin.id
        req.name = "Ocean View Suite"
        req.price = 5000.0
        req.room_type = "suite"
        req.description = "A lovely suite with an ocean view."
        
        res = self.controller.add_room(req)
        
        # Assertions
        self.assertEqual(res.response_status, ResponseStatus.SUCCESS)
        self.assertIsNotNone(res.room)
        self.assertEqual(res.room.name, "Ocean View Suite")
        self.assertEqual(res.room.price, 5000.0)
        self.assertEqual(res.room.room_type, RoomType.SUITE)
        self.assertEqual(res.room.description, "A lovely suite with an ocean view.")
        
        # Verify persistence
        saved_rooms = self.room_repo.get_rooms()
        self.assertEqual(len(saved_rooms), 1)
        self.assertEqual(saved_rooms[0].name, "Ocean View Suite")

    def test_add_room_failure_customer_unauthorized(self):
        # Create a CUSTOMER user
        customer = User()
        customer.name = "Customer User"
        customer.user_type = UserType.CUSTOMER
        self.user_repo.save(customer)
        
        # Prepare Request
        req = AddRoomRequestDto()
        req.user_id = customer.id
        req.name = "Standard Room"
        req.price = 1000.0
        req.room_type = "deluxe"
        req.description = "A standard room."
        
        res = self.controller.add_room(req)
        
        # Assertions
        self.assertEqual(res.response_status, ResponseStatus.FAILURE)
        self.assertIsNone(res.room)
        
        # Verify persistence is empty
        saved_rooms = self.room_repo.get_rooms()
        self.assertEqual(len(saved_rooms), 0)

    def test_add_room_failure_invalid_user(self):
        # Prepare Request with non-existent user_id
        req = AddRoomRequestDto()
        req.user_id = 999
        req.name = "Standard Room"
        req.price = 1000.0
        req.room_type = "deluxe"
        req.description = "A standard room."
        
        res = self.controller.add_room(req)
        
        # Assertions
        self.assertEqual(res.response_status, ResponseStatus.FAILURE)
        self.assertIsNone(res.room)
        
        # Verify persistence is empty
        saved_rooms = self.room_repo.get_rooms()
        self.assertEqual(len(saved_rooms), 0)

    def test_add_room_failure_invalid_room_type(self):
        # Create an ADMIN user
        admin = User()
        admin.name = "Admin User"
        admin.user_type = UserType.ADMIN
        self.user_repo.save(admin)
        
        # Prepare Request with an invalid room_type
        req = AddRoomRequestDto()
        req.user_id = admin.id
        req.name = "Weird Room"
        req.price = 1000.0
        req.room_type = "invalid_type"
        req.description = "A weird room."
        
        res = self.controller.add_room(req)
        
        # Assertions
        self.assertEqual(res.response_status, ResponseStatus.FAILURE)
        self.assertIsNone(res.room)

if __name__ == '__main__':
    unittest.main()