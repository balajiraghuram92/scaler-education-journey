from models.base_model import BaseModel

class Customer(BaseModel):
    def __init__(self):
        super().__init__()
        self.name: str = ""