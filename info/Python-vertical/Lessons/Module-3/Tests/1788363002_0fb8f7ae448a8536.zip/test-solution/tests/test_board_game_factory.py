import unittest
from board_game import BoardGame
from board_game_factory import BoardGameFactory
from game_type import GameType
from games.chess_board_game import ChessBoardGame
from games.snake_ladder_board_game import SnakeLadderBoardGame
from games.tic_tac_toe_board_game import TicTacToeBoardGame

class TestBoardGameFactory(unittest.TestCase):
    def test_create_chess_game(self):
        game = BoardGameFactory.create_board_game(GameType.CHESS, "My Chess")
        self.assertIsInstance(game, ChessBoardGame, "Factory should return a ChessBoardGame instance.")
        self.assertEqual(game.get_board_game_name(), "My Chess")
        self.assertEqual(game.game_type(), GameType.CHESS)

    def test_create_snake_ladder_game(self):
        game = BoardGameFactory.create_board_game(GameType.SNAKE_LADDER, "My Snake")
        self.assertIsInstance(game, SnakeLadderBoardGame, "Factory should return a SnakeLadderBoardGame instance.")
        self.assertEqual(game.get_board_game_name(), "My Snake")
        self.assertEqual(game.game_type(), GameType.SNAKE_LADDER)

    def test_create_tic_tac_toe_game(self):
        game = BoardGameFactory.create_board_game(GameType.TIC_TAC_TOE, "My TTT")
        self.assertIsInstance(game, TicTacToeBoardGame, "Factory should return a TicTacToeBoardGame instance.")
        self.assertEqual(game.get_board_game_name(), "My TTT")
        self.assertEqual(game.game_type(), GameType.TIC_TAC_TOE)

    def test_anti_bypass_inheritance(self):
        """
        Anti-bypass check: Ensure the student actually made the concrete classes 
        inherit from the BoardGame abstract base class, and that BoardGame 
        itself is an Abstract Base Class (ABC).
        """
        import inspect
        from abc import ABC
        
        self.assertTrue(issubclass(BoardGame, ABC), "BoardGame must inherit from ABC (Abstract Base Class).")
        self.assertTrue(issubclass(ChessBoardGame, BoardGame), "ChessBoardGame MUST inherit from BoardGame.")
        self.assertTrue(issubclass(SnakeLadderBoardGame, BoardGame), "SnakeLadderBoardGame MUST inherit from BoardGame.")
        self.assertTrue(issubclass(TicTacToeBoardGame, BoardGame), "TicTacToeBoardGame MUST inherit from BoardGame.")

    def test_anti_bypass_super_init(self):
        """
        Anti-bypass check: Ensure the student called super().__init__ 
        and isn't just duplicating the self.board_game_name attribute locally.
        """
        game = ChessBoardGame("TestName")
        # In Python, if they didn't call super, but defined it locally, it still exists.
        # But we can check if they removed the duplicate get_board_game_name method from ChessBoardGame 
        # and are relying on the parent class implementation!
        
        self.assertTrue(hasattr(game, 'get_board_game_name'), "Must have get_board_game_name method.")
        
        # Check if the method is actually inherited from BoardGame rather than locally defined
        self.assertNotIn('get_board_game_name', ChessBoardGame.__dict__, 
                         "You should remove get_board_game_name from ChessBoardGame and inherit it from BoardGame.")
        self.assertIn('get_board_game_name', BoardGame.__dict__, 
                      "get_board_game_name should be implemented in the BoardGame parent class.")

if __name__ == '__main__':
    unittest.main()
