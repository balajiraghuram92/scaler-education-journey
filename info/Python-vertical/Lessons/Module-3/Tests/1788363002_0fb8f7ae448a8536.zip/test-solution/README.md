# Factory Design Pattern - Board Game Creation

## Problem Statement
You are building a gaming platform in which you need to instantiate different types of Board Games. Depending on the `GameType` (e.g., `TIC_TAC_TOE`, `CHESS`, `SNAKE_LADDER`), a different specific game object must be created. You need a way to instantiate these game objects without exposing the instantiation logic to the client, ensuring the application remains robust and open for future game types.

Your task is to implement the **Factory Design Pattern** to create these Game objects. 

## Your Task

1. **Refactor the `BoardGame` Parent Class** (in `board_game.py`):
   - We have provided the `BoardGame` Abstract Base Class. It currently only requires `game_type()`.
   - You must update this base class to include the common initialization logic (specifically setting the `board_game_name` attribute) and a common abstract method for `play_game()`.

2. **Refactor the Concrete Game Classes** (in the `games/` directory):
   - Review `chess_board_game.py`, `snake_ladder_board_game.py`, and `tic_tac_toe_board_game.py`.
   - They currently duplicate the initialization of `board_game_name` and lack proper structural inheritance.
   - Refactor them to correctly inherit from your `BoardGame` parent class, calling `super().__init__(board_game_name)`. Remove redundant duplicate fields.

3. **Implement the Factory** (in `board_game_factory.py`):
   - Implement the `create_board_game` method in `BoardGameFactory`. 
   - This method should use the Simple Factory pattern to instantiate and return the correct concrete game class based on the passed `GameType`.
