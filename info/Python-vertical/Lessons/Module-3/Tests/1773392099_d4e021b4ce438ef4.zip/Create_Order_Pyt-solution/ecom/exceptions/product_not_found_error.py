class ProductNotFoundError(Exception):
    pass
