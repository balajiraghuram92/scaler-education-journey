class OutOfStockError(Exception):
    pass
