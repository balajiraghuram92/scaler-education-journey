from typing import List
from models.user import User
from models.invoice import Invoice

class Customer(User):
    def __init__(self):
        super().__init__()
        self.invoices: List[Invoice] = []