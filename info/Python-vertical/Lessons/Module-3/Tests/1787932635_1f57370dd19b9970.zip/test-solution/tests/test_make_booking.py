import unittest
from models.user import User
from models.room import Room
from models.customer_session_status import CustomerSessionStatus
from dtos.make_booking_request_dto import MakeBookingRequestDto
from dtos.response_status import ResponseStatus
from repositories.user_repository_impl import UserRepositoryImpl
from repositories.room_repository_impl import RoomRepositoryImpl
from repositories.customer_session_repository_impl import CustomerSessionRepositoryImpl
from repositories.booking_repository_impl import BookingRepositoryImpl
from services.booking_service_impl import BookingServiceImpl
from controllers.booking_controller import BookingController

class TestMakeBooking(unittest.TestCase):
    def setUp(self):
        self.user_repo = UserRepositoryImpl()
        self.room_repo = RoomRepositoryImpl()
        self.session_repo = CustomerSessionRepositoryImpl()
        self.booking_repo = BookingRepositoryImpl()
        
        self.service = BookingServiceImpl(
            self.user_repo, self.room_repo, self.session_repo, self.booking_repo
        )
        self.controller = BookingController(self.service)
        
        # Seed user
        self.user = User()
        self.user.name = "John Doe"
        self.user_repo.save(self.user)
        
        # Seed rooms
        self.room1 = Room()
        self.room1.room_number = "101"
        self.room_repo.save(self.room1)
        
        self.room2 = Room()
        self.room2.room_number = "102"
        self.room_repo.save(self.room2)

    def test_make_booking_success_new_session(self):
        req = MakeBookingRequestDto()
        req.user_id = self.user.id
        req.booked_rooms = {self.room1.id: 2}
        
        res = self.controller.make_booking(req)
        
        self.assertEqual(res.response_status, ResponseStatus.SUCCESS)
        self.assertIsNotNone(res.booking)
        self.assertEqual(res.booking.customer_session.user.id, self.user.id)
        self.assertEqual(res.booking.customer_session.customer_session_status, CustomerSessionStatus.ACTIVE)
        
        # Verify it mapped the room dict properly
        self.assertIn(self.room1, res.booking.booked_rooms)
        self.assertEqual(res.booking.booked_rooms[self.room1], 2)
        
        # Verify Session was persisted
        active_session = self.session_repo.find_active_customer_session_by_user_id(self.user.id)
        self.assertIsNotNone(active_session)

    def test_make_booking_success_reuses_active_session(self):
        # 1. Make first booking
        req1 = MakeBookingRequestDto()
        req1.user_id = self.user.id
        req1.booked_rooms = {self.room1.id: 1}
        res1 = self.controller.make_booking(req1)
        
        first_session_id = res1.booking.customer_session.id
        
        # 2. Make second booking
        req2 = MakeBookingRequestDto()
        req2.user_id = self.user.id
        req2.booked_rooms = {self.room2.id: 3}
        res2 = self.controller.make_booking(req2)
        
        second_session_id = res2.booking.customer_session.id
        
        # 3. Assert the session ID is exactly the same (reused)
        self.assertEqual(first_session_id, second_session_id)
        
        # Assert total sessions in repo is still 1
        self.assertEqual(len(self.session_repo.sessions), 1)

    def test_make_booking_failure_invalid_user(self):
        req = MakeBookingRequestDto()
        req.user_id = 999
        req.booked_rooms = {self.room1.id: 1}
        
        res = self.controller.make_booking(req)
        
        self.assertEqual(res.response_status, ResponseStatus.FAILURE)
        self.assertIsNone(res.booking)
        
        # Assert no session was accidentally created
        self.assertEqual(len(self.session_repo.sessions), 0)
        self.assertEqual(len(self.booking_repo.bookings), 0)

    def test_make_booking_failure_invalid_room(self):
        req = MakeBookingRequestDto()
        req.user_id = self.user.id
        # Requesting a valid room and an invalid room (id 999)
        req.booked_rooms = {self.room1.id: 1, 999: 2}
        
        res = self.controller.make_booking(req)
        
        self.assertEqual(res.response_status, ResponseStatus.FAILURE)
        self.assertIsNone(res.booking)
        
        # Assert transaction aborted fully (no session or booking saved)
        self.assertEqual(len(self.session_repo.sessions), 0)
        self.assertEqual(len(self.booking_repo.bookings), 0)

if __name__ == '__main__':
    unittest.main()