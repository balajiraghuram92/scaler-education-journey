class UserNotFoundException(Exception):
    pass