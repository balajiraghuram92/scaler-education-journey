class InvalidRoomException(Exception):
    pass