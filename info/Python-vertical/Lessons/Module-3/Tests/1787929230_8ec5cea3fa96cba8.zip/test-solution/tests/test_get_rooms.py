import unittest
from models.room import Room
from models.room_type import RoomType
from dtos.get_rooms_request_dto import GetRoomsRequestDto
from dtos.response_status import ResponseStatus
from repositories.room_repository_impl import RoomRepositoryImpl
from services.room_service_impl import RoomServiceImpl
from controllers.room_controller import RoomController

class TestGetRooms(unittest.TestCase):
    def setUp(self):
        self.room_repo = RoomRepositoryImpl()
        self.service = RoomServiceImpl(self.room_repo)
        self.controller = RoomController(self.service)
        
        # Seed the repository with some rooms
        room1 = Room()
        room1.room_number = "101"
        room1.room_type = RoomType.DELUXE
        self.room_repo.save(room1)
        
        room2 = Room()
        room2.room_number = "102"
        room2.room_type = RoomType.SUPER_DELUXE
        self.room_repo.save(room2)
        
        room3 = Room()
        room3.room_number = "103"
        room3.room_type = RoomType.DELUXE
        self.room_repo.save(room3)

    def test_get_rooms_success_filter_by_type(self):
        req = GetRoomsRequestDto()
        req.room_type = "deluxe"
        
        res = self.controller.get_rooms(req)
        
        self.assertEqual(res.response_status, ResponseStatus.SUCCESS)
        self.assertEqual(len(res.rooms), 2)
        for room in res.rooms:
            self.assertEqual(room.room_type, RoomType.DELUXE)

    def test_get_rooms_success_no_type_returns_all(self):
        req = GetRoomsRequestDto()
        req.room_type = None
        
        res = self.controller.get_rooms(req)
        
        self.assertEqual(res.response_status, ResponseStatus.SUCCESS)
        self.assertEqual(len(res.rooms), 3)

    def test_get_rooms_success_empty_string_returns_all(self):
        req = GetRoomsRequestDto()
        req.room_type = ""
        
        res = self.controller.get_rooms(req)
        
        self.assertEqual(res.response_status, ResponseStatus.SUCCESS)
        self.assertEqual(len(res.rooms), 3)

    def test_get_rooms_failure_invalid_type(self):
        req = GetRoomsRequestDto()
        req.room_type = "invalid_type"
        
        res = self.controller.get_rooms(req)
        
        self.assertEqual(res.response_status, ResponseStatus.FAILURE)
        self.assertEqual(len(res.rooms), 0)

if __name__ == '__main__':
    unittest.main()