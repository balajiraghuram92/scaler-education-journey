import unittest
from exceptions.exceptions import InvalidMoveException
from models.enums import GameState
from models.player import Player
from models.symbol import Symbol
from services.game_service import GameService
from strategies.winning_strategy_impl import WinningStrategyImpl

class TestWinnerCheck(unittest.TestCase):
    def setUp(self):
        self.strategy = WinningStrategyImpl()
        self.service = GameService(self.strategy)
        self.players = [Player("Player1", Symbol('X')), Player("Player2", Symbol('O'))]

    def test_row_win(self):
        game = self.service.start_game(3, self.players)
        self.service.make_move(game, 0, 0) # P1
        self.service.make_move(game, 1, 0) # P2
        self.service.make_move(game, 0, 1) # P1
        self.service.make_move(game, 1, 1) # P2
        
        self.assertEqual(game.game_state, GameState.IN_PROGRESS, "Game should not be ended prematurely.")
        self.service.make_move(game, 0, 2) # P1 wins on Row 0
        
        self.assertEqual(game.game_state, GameState.ENDED, "Player 1 should have won on Row 0")
        self.assertEqual(game.winner.name, "Player1")

    def test_col_win(self):
        game = self.service.start_game(3, self.players)
        self.service.make_move(game, 0, 1) # P1
        self.service.make_move(game, 0, 0) # P2
        self.service.make_move(game, 1, 1) # P1
        self.service.make_move(game, 1, 0) # P2
        
        self.assertEqual(game.game_state, GameState.IN_PROGRESS)
        self.service.make_move(game, 2, 1) # P1 wins on Col 1
        
        self.assertEqual(game.game_state, GameState.ENDED, "Player 1 should have won on Column 1")
        self.assertEqual(game.winner.name, "Player1")

    def test_left_diagonal_win(self):
        game = self.service.start_game(3, self.players)
        self.service.make_move(game, 0, 0) # P1
        self.service.make_move(game, 0, 1) # P2
        self.service.make_move(game, 1, 1) # P1
        self.service.make_move(game, 1, 0) # P2
        
        self.assertEqual(game.game_state, GameState.IN_PROGRESS)
        self.service.make_move(game, 2, 2) # P1 wins on Left Diagonal
        
        self.assertEqual(game.game_state, GameState.ENDED, "Player 1 should have won on the Left Diagonal")
        self.assertEqual(game.winner.name, "Player1")

    def test_right_diagonal_win(self):
        game = self.service.start_game(3, self.players)
        self.service.make_move(game, 0, 2) # P1
        self.service.make_move(game, 0, 1) # P2
        self.service.make_move(game, 1, 1) # P1
        self.service.make_move(game, 1, 0) # P2
        
        self.assertEqual(game.game_state, GameState.IN_PROGRESS)
        self.service.make_move(game, 2, 0) # P1 wins on Right Diagonal
        
        self.assertEqual(game.game_state, GameState.ENDED, "Player 1 should have won on the Right Diagonal")
        self.assertEqual(game.winner.name, "Player1")

    def test_draw_condition(self):
        game = self.service.start_game(3, self.players)
        moves = [
            (0, 0), (0, 1), (0, 2),
            (1, 1), (1, 0), (1, 2),
            (2, 1), (2, 0), (2, 2)
        ]
        # X O X
        # O X O
        # O X X (Wait, this is a draw on a standard board if played correctly, let's verify symbols)
        # X, O, X
        # O, X, O
        # O, X, X
        
        for r, c in moves:
            self.service.make_move(game, r, c)
            
        self.assertEqual(game.game_state, GameState.DRAW, "The board is full and no one won, game should be DRAW")
        self.assertIsNone(game.winner)

    def test_internal_state_structures_anti_bypass(self):
        """
        Anti-bypass check: Ensure the student actually instantiated 
        the dictionaries in __init__ as instructed, rather than 
        writing O(N^2) loops inside check_winner.
        """
        self.assertTrue(hasattr(self.strategy, 'row_maps'), "You must use 'row_maps' dictionary for O(1) tracking.")
        self.assertTrue(hasattr(self.strategy, 'col_maps'), "You must use 'col_maps' dictionary for O(1) tracking.")
        self.assertTrue(hasattr(self.strategy, 'left_diagonal_map'), "You must use 'left_diagonal_map' dictionary.")
        self.assertTrue(hasattr(self.strategy, 'right_diagonal_map'), "You must use 'right_diagonal_map' dictionary.")

if __name__ == '__main__':
    unittest.main()
