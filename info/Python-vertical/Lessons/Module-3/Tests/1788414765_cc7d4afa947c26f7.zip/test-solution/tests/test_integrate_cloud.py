import unittest
from adapters.aws_cloud_adapter import AWSCloudAdapter
from adapters.google_cloud_adapter import GoogleCloudAdapter
from adapters.cloud_adapter import CloudAdapter
from repositories.user_repository_impl import UserRepositoryImpl
from services.cloud_service_impl import CloudServiceImpl
from controllers.cloud_controller import CloudController
from dtos.create_connection_request_dto import CreateConnectionRequestDto
from models.enums import ResponseStatus, ConnectionStatus
from models.user import User
from exceptions.exceptions import UserNotFoundException

class TestIntegrateCloud(unittest.TestCase):
    def setUp(self):
        self.user_repo = UserRepositoryImpl()
        # Seed a user
        self.user = User()
        self.user.name = "TestUser"
        self.user = self.user_repo.save(self.user)

    def test_aws_adapter_success(self):
        adapter = AWSCloudAdapter()
        service = CloudServiceImpl(adapter, self.user_repo)
        controller = CloudController(service)

        req = CreateConnectionRequestDto()
        req.user_id = self.user.id
        
        resp = controller.create_connection(req)
        self.assertEqual(resp.response_status, ResponseStatus.SUCCESS)
        self.assertEqual(resp.connection_status, ConnectionStatus.SUCCESS)
        self.assertIsNotNone(resp.connection_id)

    def test_google_adapter_success(self):
        adapter = GoogleCloudAdapter()
        service = CloudServiceImpl(adapter, self.user_repo)
        controller = CloudController(service)

        req = CreateConnectionRequestDto()
        req.user_id = self.user.id
        
        resp = controller.create_connection(req)
        self.assertEqual(resp.response_status, ResponseStatus.SUCCESS)
        self.assertEqual(resp.connection_status, ConnectionStatus.SUCCESS)
        self.assertIsNotNone(resp.connection_id)

    def test_user_not_found(self):
        adapter = AWSCloudAdapter()
        service = CloudServiceImpl(adapter, self.user_repo)
        controller = CloudController(service)

        req = CreateConnectionRequestDto()
        req.user_id = 9999 # Invalid User
        
        resp = controller.create_connection(req)
        self.assertEqual(resp.response_status, ResponseStatus.FAILURE)

    def test_anti_bypass_adapter_inheritance(self):
        """
        Anti-bypass check: Ensure the student actually made their concrete adapters 
        inherit from the CloudAdapter abstract base class.
        """
        import inspect
        from abc import ABC
        
        self.assertTrue(issubclass(CloudAdapter, ABC), "CloudAdapter must inherit from ABC.")
        self.assertTrue(issubclass(AWSCloudAdapter, CloudAdapter), "AWSCloudAdapter MUST inherit from CloudAdapter.")
        self.assertTrue(issubclass(GoogleCloudAdapter, CloudAdapter), "GoogleCloudAdapter MUST inherit from CloudAdapter.")

    def test_anti_bypass_service_throws(self):
        """
        Anti-bypass check: Ensure CloudServiceImpl actually throws UserNotFoundException 
        instead of quietly catching it (Controller should catch it).
        """
        adapter = AWSCloudAdapter()
        service = CloudServiceImpl(adapter, self.user_repo)
        
        with self.assertRaises(UserNotFoundException):
            service.create_connection(9999)

if __name__ == '__main__':
    unittest.main()
