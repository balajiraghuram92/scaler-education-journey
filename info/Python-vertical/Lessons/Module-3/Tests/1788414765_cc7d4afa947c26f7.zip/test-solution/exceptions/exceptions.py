class UserNotFoundException(Exception):
    pass
