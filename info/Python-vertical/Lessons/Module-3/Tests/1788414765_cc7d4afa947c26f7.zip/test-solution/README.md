# Integrate Cloud Service Provider

## Problem Statement
You are building a Web Project. As a part of this system, you need to integrate AWS and Google as cloud service providers into your system. 
To do this efficiently and compliantly, you must utilize the **Adapter Design Pattern**, ensuring the system can easily swap between different cloud providers without changing the core business logic.

## Your Task

Your task is to integrate both AWS and Google cloud services in a SOLID-compliant manner with the "Create Connection" functionality of our system.

### Requirements

1. The "create connection" request functionality receives a `user_id` as input.
2. If an invalid `user_id` is given, it should raise an error saying "User not found".
3. When a valid `user_id` is provided, you need to get the user details stored in the database and make a call to the Cloud Providers (AWS or Google) to initiate the connection. 
4. The third-party APIs (`AWSApi` and `GoogleApi`) return their own proprietary response objects. You must extract the connection ID and status from these objects, map them to our internal domain `Connection` model, and return it.
5. The integration must be implemented using the **Adapter Pattern** so that migrating from one cloud to another is seamless.

### Instructions

1. **Adapters**: Implement `AWSCloudAdapter` and `GoogleCloudAdapter` inside the `adapters/` directory. They must implement the `CloudAdapter` interface and adapt the 3rd-party APIs to our domain model.
2. **Repository**: Implement `UserRepositoryImpl` in `repositories/` using an in-memory dictionary.
3. **Service**: Implement `CloudServiceImpl` in `services/`. It must validate the user and delegate connection creation to the injected `CloudAdapter`.
4. **Controller**: Implement the `create_connection` method inside `CloudController` in `controllers/`. Handle exceptions gracefully and map the result to the response DTO.
