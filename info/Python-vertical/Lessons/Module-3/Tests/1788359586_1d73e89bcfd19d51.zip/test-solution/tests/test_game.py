import unittest
from exceptions.exceptions import EmptyMovesException, InvalidMoveException
from models.enums import GameState, CellState
from models.player import Player
from models.symbol import Symbol
from services.game_service import GameService
from strategies.winning_strategy_impl import WinningStrategyImpl

class TestGameUndo(unittest.TestCase):
    def setUp(self):
        self.strategy = WinningStrategyImpl()
        self.service = GameService(self.strategy)
        self.players = [Player("Player1", Symbol('X')), Player("Player2", Symbol('O'))]
        self.game = self.service.start_game(3, self.players)

    def test_success_flow_and_win(self):
        self.service.make_move(self.game, 0, 0) # P1
        self.service.make_move(self.game, 1, 0) # P2
        self.service.make_move(self.game, 0, 1) # P1
        self.service.make_move(self.game, 1, 1) # P2
        self.service.make_move(self.game, 0, 2) # P1 wins

        self.assertEqual(self.game.game_state, GameState.ENDED)
        self.assertEqual(self.game.winner.name, "Player1")
        self.assertEqual(len(self.game.moves), 5)

    def test_empty_moves_exception_anti_bypass(self):
        # Student might not have handled the empty condition.
        with self.assertRaises(EmptyMovesException):
            self.service.undo(self.game)

        # Make one move, undo it, then try to undo again.
        self.service.make_move(self.game, 0, 0)
        self.service.undo(self.game)
        with self.assertRaises(EmptyMovesException):
            self.service.undo(self.game)

    def test_undo_state_rollback_anti_bypass(self):
        self.service.make_move(self.game, 0, 0) # P1
        self.service.make_move(self.game, 1, 0) # P2
        self.service.make_move(self.game, 0, 1) # P1
        self.service.make_move(self.game, 1, 1) # P2
        self.service.make_move(self.game, 0, 2) # P1 wins

        self.assertEqual(self.game.game_state, GameState.ENDED)
        
        # Undo P1's winning move
        self.service.undo(self.game)

        # Ensure student fully reset the game state
        self.assertEqual(self.game.game_state, GameState.IN_PROGRESS, "Game state must revert to IN_PROGRESS after undoing a winning move.")
        self.assertIsNone(self.game.winner, "Winner must be cleared after undo.")
        self.assertEqual(len(self.game.moves), 4, "Moves list must shrink by 1.")
        
        # Turn should be back to P1 (index 0)
        self.assertEqual(self.game.next_player_move_index, 0, "Turn index must roll back correctly.")
        
        # Cell should be empty
        self.assertEqual(self.game.board.board[0][2].cell_state, CellState.EMPTY, "Cell state must be reset to EMPTY.")
        self.assertIsNone(self.game.board.board[0][2].player, "Cell player reference must be cleared.")

    def test_undo_multiple_moves_anti_bypass(self):
        self.service.make_move(self.game, 0, 0) # P1
        self.service.make_move(self.game, 1, 0) # P2
        
        self.service.undo(self.game)
        self.assertEqual(self.game.next_player_move_index, 1, "Turn index failed to rollback from 0 to 1 (P2).")
        self.assertEqual(len(self.game.moves), 1)
        
        self.service.undo(self.game)
        self.assertEqual(self.game.next_player_move_index, 0, "Turn index failed to rollback from 1 to 0 (P1).")
        self.assertEqual(len(self.game.moves), 0)

    def test_strategy_decrement_anti_bypass(self):
        """
        If a student lazily uses `pass` in handle_undo, they won't decrement the winning counters.
        This test ensures they actually decrement the strategy dictionaries.
        """
        self.service.make_move(self.game, 0, 0) # P1
        self.service.undo(self.game)            # Student MUST decrement P1 at row 0, col 0.
        
        self.service.make_move(self.game, 0, 0) # P1 (Count should be 1, if bypass it's 2)
        self.service.make_move(self.game, 1, 0) # P2
        self.service.make_move(self.game, 0, 1) # P1 (Count should be 2, if bypass it's 3)
        
        # If the student bypassed handle_undo, P1 would falsely win right now (count = 3).
        # We explicitly assert they have NOT won.
        self.assertEqual(
            self.game.game_state, 
            GameState.IN_PROGRESS, 
            "Student bypassed handle_undo! You must decrement the hash maps, otherwise players can falsely win."
        )

        self.service.make_move(self.game, 1, 1) # P2
        self.service.make_move(self.game, 0, 2) # P1 wins correctly here.
        
        self.assertEqual(self.game.game_state, GameState.ENDED)

if __name__ == '__main__':
    unittest.main()