from abc import ABC, abstractmethod
from typing import Optional
from models.parking_lot import ParkingLot


class ParkingLotRepository(ABC):
    """
    Defines the contract for storing and retrieving parking lots.

    TODO (for student):
    -------------------
    Create a concrete class called ParkingLotRepositoryImpl that implements this ABC.
    - Use a Python dictionary as your in-memory database: self._parking_lots = {}
    - Use an auto-incrementing ID counter: self._current_id = 1

    Implement:
      1. get_parking_lot_by_gate_id(gate_id: int) -> Optional[ParkingLot]
         - Iterate through all parking lots in the repository.
         - Find the parking lot whose gates list contains a gate with id == gate_id.
         - Return the matching ParkingLot, or None if not found.
      2. get_parking_lot_by_id(id: int) -> Optional[ParkingLot]
         - Retrieve the parking lot with the given ID from self._parking_lots.
         - Return None if not found.
      3. save(parking_lot: ParkingLot) -> ParkingLot
         - If parking_lot.id is None or <= 0, assign self._current_id and increment it.
         - Store the parking lot in self._parking_lots using parking_lot.id as the key.
         - Return the saved parking lot.
    """

    @abstractmethod
    def get_parking_lot_by_gate_id(self, gate_id: int) -> Optional[ParkingLot]:
        pass

    @abstractmethod
    def get_parking_lot_by_id(self, id: int) -> Optional[ParkingLot]:
        pass

    @abstractmethod
    def save(self, parking_lot: ParkingLot) -> ParkingLot:
        pass
