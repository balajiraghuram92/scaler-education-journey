from abc import ABC, abstractmethod
from typing import Optional
from models.vehicle import Vehicle


class VehicleRepository(ABC):
    """
    Defines the contract for storing and retrieving vehicles.

    TODO (for student):
    -------------------
    Create a concrete class called VehicleRepositoryImpl that implements this ABC.
    - Use a Python dictionary as your in-memory database: self._vehicles = {}
    - Use an auto-incrementing ID counter: self._current_id = 1

    Implement:
      1. get_vehicle_by_registration_number(registration_number: str) -> Optional[Vehicle]
         - Search self._vehicles for a vehicle with matching registration_number.
         - Return the matching Vehicle, or None if not found.
      2. save(vehicle: Vehicle) -> Vehicle
         - If vehicle.id is None or <= 0, assign self._current_id and increment it.
         - Store the vehicle in self._vehicles using vehicle.id as the key.
         - Return the saved vehicle.
    """

    @abstractmethod
    def get_vehicle_by_registration_number(self, registration_number: str) -> Optional[Vehicle]:
        pass

    @abstractmethod
    def save(self, vehicle: Vehicle) -> Vehicle:
        pass
