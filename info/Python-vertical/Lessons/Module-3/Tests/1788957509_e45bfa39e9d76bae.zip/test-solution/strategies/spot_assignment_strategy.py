from abc import ABC, abstractmethod
from typing import Optional
from models.parking_lot import ParkingLot
from models.parking_spot import ParkingSpot
from models.vehicle_type import VehicleType


class SpotAssignmentStrategy(ABC):
    """
    Defines the strategy contract for assigning an available parking spot to a vehicle.

    TODO (for student):
    -------------------
    Create a concrete class that implements this ABC (e.g., SlotAssignmentStrategyImpl).

    Requirements for spot assignment:
      1. Only OPERATIONAL floors (floor.status == FloorStatus.OPERATIONAL) should be considered.
      2. For each operational floor, count the available spots matching vehicle_type
         (spot.status == ParkingSpotStatus.AVAILABLE and spot.supported_vehicle_type == vehicle_type).
      3. Assign to the floor with the LEAST number of available spots for that vehicle type (> 0).
      4. If there is a tie between multiple floors, pick the floor with the lowest floor_number.
      5. Once the floor is chosen, assign the nearest available spot (i.e. lowest spot number) on that floor.
      6. If no operational floor has an available spot for the vehicle type, return None.
    """

    @abstractmethod
    def assign_spot(self, parking_lot: ParkingLot, vehicle_type: VehicleType) -> Optional[ParkingSpot]:
        pass
