class ParkingSpotNotAvailableException(Exception):
    """
    Raised when no suitable parking spot is available in the parking lot.
    """

    def __init__(self, message: str = ""):
        super().__init__(message)
