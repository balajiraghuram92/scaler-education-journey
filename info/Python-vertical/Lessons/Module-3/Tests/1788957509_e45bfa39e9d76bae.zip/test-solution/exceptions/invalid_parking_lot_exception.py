class InvalidParkingLotException(Exception):
    """
    Raised when a parking lot is not found for a given gate ID or lot ID.
    """

    def __init__(self, message: str = ""):
        super().__init__(message)
