from abc import ABC, abstractmethod
from models.ticket import Ticket


class TicketService(ABC):
    """
    Defines the contract for ticket generation in the parking lot system.

    TODO (for student):
    -------------------
    Create a concrete class called TicketServiceImpl that implements this ABC.
    The constructor should accept:
      - gate_repository: GateRepository
      - parking_lot_repository: ParkingLotRepository
      - vehicle_repository: VehicleRepository
      - ticket_repository: TicketRepository
      - spot_assignment_strategy: SpotAssignmentStrategy

    Implement:
      generate_ticket(gate_id: int, registration_number: str, vehicle_type: str) -> Ticket:
        1. Validate gate:
           - Retrieve the gate using gate_repository.find_by_id(gate_id).
           - If gate is None or gate.gate_type != GateType.ENTRY, raise InvalidGateException.
        2. Validate parking lot:
           - Retrieve the parking lot using parking_lot_repository.get_parking_lot_by_gate_id(gate_id).
           - If parking lot is None, raise InvalidParkingLotException.
        3. Parse vehicle type:
           - Convert vehicle_type string to VehicleType enum (e.g. VehicleType[vehicle_type.upper()]).
        4. Find or create vehicle:
           - Check vehicle_repository.get_vehicle_by_registration_number(registration_number).
           - If not found, instantiate a new Vehicle(registration_number=registration_number, vehicle_type=parsed_type)
             and save it using vehicle_repository.save(new_vehicle).
        5. Assign parking spot:
           - Call spot_assignment_strategy.assign_spot(parking_lot, parsed_type).
           - If None, raise ParkingSpotNotAvailableException.
           - Mark the assigned spot's status as OCCUPIED.
        6. Create and save ticket:
           - Instantiate Ticket with vehicle, current datetime as entry_time, assigned spot, gate, and gate.parking_attendant.
           - Save the ticket using ticket_repository.save(ticket).
           - Return the saved ticket.
    """

    @abstractmethod
    def generate_ticket(self, gate_id: int, registration_number: str, vehicle_type: str) -> Ticket:
        pass
