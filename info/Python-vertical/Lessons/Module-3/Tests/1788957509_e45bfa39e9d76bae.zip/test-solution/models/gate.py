from typing import Optional
from models.base_model import BaseModel
from models.gate_type import GateType
from models.parking_attendant import ParkingAttendant


class Gate(BaseModel):
    """
    Represents an entry or exit gate of a parking lot.
    """

    def __init__(
        self,
        id: Optional[int] = None,
        name: str = "",
        gate_type: GateType = GateType.ENTRY,
        parking_attendant: Optional[ParkingAttendant] = None
    ):
        super().__init__(id)
        self.name = name
        self.gate_type = gate_type
        self.parking_attendant = parking_attendant
