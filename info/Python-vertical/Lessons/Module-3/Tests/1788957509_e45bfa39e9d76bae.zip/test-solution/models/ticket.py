from datetime import datetime
from typing import Optional
from models.base_model import BaseModel
from models.gate import Gate
from models.parking_attendant import ParkingAttendant
from models.parking_spot import ParkingSpot
from models.vehicle import Vehicle


class Ticket(BaseModel):
    """
    Represents a parking ticket issued to a vehicle at an entry gate.
    """

    def __init__(
        self,
        id: Optional[int] = None,
        vehicle: Optional[Vehicle] = None,
        entry_time: Optional[datetime] = None,
        parking_spot: Optional[ParkingSpot] = None,
        gate: Optional[Gate] = None,
        parking_attendant: Optional[ParkingAttendant] = None
    ):
        super().__init__(id)
        self.vehicle = vehicle
        self.entry_time = entry_time if entry_time is not None else datetime.now()
        self.parking_spot = parking_spot
        self.gate = gate
        self.parking_attendant = parking_attendant
