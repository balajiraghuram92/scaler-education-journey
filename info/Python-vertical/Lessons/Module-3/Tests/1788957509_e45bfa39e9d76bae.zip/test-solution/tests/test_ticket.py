import os
import sys
import unittest

# Ensure parent directory is in sys.path so package imports resolve from any CWD
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..", "..")))

from controllers.ticket_controller import TicketController
from dtos.generate_ticket_request_dto import GenerateTicketRequestDto
from dtos.generate_ticket_response_dto import GenerateTicketResponseDto
from dtos.response_status import ResponseStatus
from exceptions.invalid_gate_exception import InvalidGateException
from exceptions.invalid_parking_lot_exception import InvalidParkingLotException
from exceptions.parking_spot_not_available_exception import ParkingSpotNotAvailableException
from models.floor_status import FloorStatus
from models.gate import Gate
from models.gate_type import GateType
from models.parking_attendant import ParkingAttendant
from models.parking_floor import ParkingFloor
from models.parking_lot import ParkingLot
from models.parking_spot import ParkingSpot
from models.parking_spot_status import ParkingSpotStatus
from models.ticket import Ticket
from models.vehicle import Vehicle
from models.vehicle_type import VehicleType
from repositories.gate_repository_impl import GateRepositoryImpl
from repositories.parking_lot_repository_impl import ParkingLotRepositoryImpl
from repositories.ticket_repository_impl import TicketRepositoryImpl
from repositories.vehicle_repository_impl import VehicleRepositoryImpl
from services.ticket_service_impl import TicketServiceImpl
from strategies.spot_assignment_strategy_impl import SpotAssignmentStrategyImpl


def _setup_test_environment():
    """
    Constructs a complete testing environment:
      - Gate 1: ENTRY (with attendant)
      - Gate 2: EXIT (with attendant)
      - Floor 1 (OPERATIONAL):
          - Spot 101: CAR, AVAILABLE
          - Spot 102: CAR, AVAILABLE
          - Spot 103: BIKE, AVAILABLE
      - Floor 2 (OPERATIONAL):
          - Spot 201: CAR, AVAILABLE
          - Spot 202: BIKE, AVAILABLE
      - Floor 3 (UNDER_MAINTENANCE):
          - Spot 301: CAR, AVAILABLE
    """
    gate_repo = GateRepositoryImpl()
    lot_repo = ParkingLotRepositoryImpl()
    vehicle_repo = VehicleRepositoryImpl()
    ticket_repo = TicketRepositoryImpl()
    strategy = SpotAssignmentStrategyImpl()

    attendant = ParkingAttendant(id=1, name="Operator Alice", email="alice@example.com")
    entry_gate = Gate(id=1, name="North Entry Gate", gate_type=GateType.ENTRY, parking_attendant=attendant)
    exit_gate = Gate(id=2, name="South Exit Gate", gate_type=GateType.EXIT, parking_attendant=attendant)
    gate_repo.save(entry_gate)
    gate_repo.save(exit_gate)

    floor1_spots = [
        ParkingSpot(id=1, number=101, supported_vehicle_type=VehicleType.CAR, status=ParkingSpotStatus.AVAILABLE),
        ParkingSpot(id=2, number=102, supported_vehicle_type=VehicleType.CAR, status=ParkingSpotStatus.AVAILABLE),
        ParkingSpot(id=3, number=103, supported_vehicle_type=VehicleType.BIKE, status=ParkingSpotStatus.AVAILABLE),
    ]
    floor2_spots = [
        ParkingSpot(id=4, number=201, supported_vehicle_type=VehicleType.CAR, status=ParkingSpotStatus.AVAILABLE),
        ParkingSpot(id=5, number=202, supported_vehicle_type=VehicleType.BIKE, status=ParkingSpotStatus.AVAILABLE),
    ]
    floor3_spots = [
        ParkingSpot(id=6, number=301, supported_vehicle_type=VehicleType.CAR, status=ParkingSpotStatus.AVAILABLE),
    ]

    floor1 = ParkingFloor(id=1, spots=floor1_spots, floor_number=1, status=FloorStatus.OPERATIONAL)
    floor2 = ParkingFloor(id=2, spots=floor2_spots, floor_number=2, status=FloorStatus.OPERATIONAL)
    floor3 = ParkingFloor(id=3, spots=floor3_spots, floor_number=3, status=FloorStatus.UNDER_MAINTENANCE)

    lot = ParkingLot(
        id=1,
        parking_floors=[floor1, floor2, floor3],
        gates=[entry_gate, exit_gate],
        name="Grand Parking Lot",
        address="100 Tech Park Ave"
    )
    lot_repo.save(lot)

    service = TicketServiceImpl(
        gate_repository=gate_repo,
        parking_lot_repository=lot_repo,
        vehicle_repository=vehicle_repo,
        ticket_repository=ticket_repo,
        spot_assignment_strategy=strategy
    )
    controller = TicketController(ticket_service=service)

    return controller, service, gate_repo, lot_repo, vehicle_repo, ticket_repo, strategy, lot


# ===========================================================================
# Test Suite 1 — Repositories
# ===========================================================================

class TestRepositories(unittest.TestCase):
    """Tests CRUD and query capabilities of all in-memory repositories."""

    def test_gate_repository(self):
        repo = GateRepositoryImpl()
        g1 = repo.save(Gate(id=0, name="G1", gate_type=GateType.ENTRY))
        self.assertEqual(g1.id, 1)
        self.assertIs(repo.find_by_id(1), g1)
        self.assertIsNone(repo.find_by_id(999))

    def test_parking_lot_repository(self):
        repo = ParkingLotRepositoryImpl()
        gate = Gate(id=5, name="G5", gate_type=GateType.ENTRY)
        lot = ParkingLot(id=0, parking_floors=[], gates=[gate], name="Lot 1", address="Road 1")
        saved_lot = repo.save(lot)
        self.assertEqual(saved_lot.id, 1)
        self.assertIs(repo.get_parking_lot_by_id(1), saved_lot)
        self.assertIs(repo.get_parking_lot_by_gate_id(5), saved_lot)
        self.assertIsNone(repo.get_parking_lot_by_gate_id(999))

    def test_vehicle_repository(self):
        repo = VehicleRepositoryImpl()
        v = Vehicle(id=0, registration_number="KA-01-HH-1234", vehicle_type=VehicleType.CAR)
        saved_v = repo.save(v)
        self.assertEqual(saved_v.id, 1)
        self.assertIs(repo.get_vehicle_by_registration_number("KA-01-HH-1234"), saved_v)
        self.assertIsNone(repo.get_vehicle_by_registration_number("UNKNOWN"))

    def test_ticket_repository(self):
        repo = TicketRepositoryImpl()
        t = Ticket(id=0)
        saved_t = repo.save(t)
        self.assertEqual(saved_t.id, 1)
        self.assertIs(repo.get_ticket_by_id(1), saved_t)
        self.assertIsNone(repo.get_ticket_by_id(999))


# ===========================================================================
# Test Suite 2 — Spot Assignment Strategy
# ===========================================================================

class TestSpotAssignmentStrategy(unittest.TestCase):
    """Tests the spot assignment strategy rules."""

    def setUp(self):
        self.strategy = SpotAssignmentStrategyImpl()

    def test_assign_to_floor_with_least_available_spots(self):
        """
        Floor 1 has 2 CAR spots. Floor 2 has 1 CAR spot.
        Rule: Vehicle must be assigned to Floor 2 because it has fewer available spots.
        """
        f1_spots = [
            ParkingSpot(id=1, number=101, supported_vehicle_type=VehicleType.CAR),
            ParkingSpot(id=2, number=102, supported_vehicle_type=VehicleType.CAR),
        ]
        f2_spots = [
            ParkingSpot(id=3, number=201, supported_vehicle_type=VehicleType.CAR),
        ]
        floor1 = ParkingFloor(id=1, spots=f1_spots, floor_number=1, status=FloorStatus.OPERATIONAL)
        floor2 = ParkingFloor(id=2, spots=f2_spots, floor_number=2, status=FloorStatus.OPERATIONAL)
        lot = ParkingLot(id=1, parking_floors=[floor1, floor2], gates=[])

        assigned_spot = self.strategy.assign_spot(lot, VehicleType.CAR)
        self.assertIsNotNone(assigned_spot)
        self.assertEqual(assigned_spot.number, 201)
        self.assertEqual(assigned_spot.status, ParkingSpotStatus.OCCUPIED)

    def test_tie_broken_by_lowest_floor_number(self):
        """
        Floor 1 and Floor 2 both have 1 available CAR spot.
        Rule: Tie-break selects floor with lowest floor_number (Floor 1).
        """
        f1_spots = [ParkingSpot(id=1, number=105, supported_vehicle_type=VehicleType.CAR)]
        f2_spots = [ParkingSpot(id=2, number=205, supported_vehicle_type=VehicleType.CAR)]
        floor1 = ParkingFloor(id=1, spots=f1_spots, floor_number=1, status=FloorStatus.OPERATIONAL)
        floor2 = ParkingFloor(id=2, spots=f2_spots, floor_number=2, status=FloorStatus.OPERATIONAL)
        lot = ParkingLot(id=1, parking_floors=[floor1, floor2], gates=[])

        assigned = self.strategy.assign_spot(lot, VehicleType.CAR)
        self.assertEqual(assigned.number, 105)

    def test_non_operational_floors_ignored(self):
        """
        Floor 1 is UNDER_MAINTENANCE with 1 spot.
        Floor 2 is OPERATIONAL with 3 spots.
        Rule: Non-operational floor must be ignored; spot from Floor 2 must be chosen.
        """
        f1_spots = [ParkingSpot(id=1, number=101, supported_vehicle_type=VehicleType.CAR)]
        f2_spots = [
            ParkingSpot(id=2, number=201, supported_vehicle_type=VehicleType.CAR),
            ParkingSpot(id=3, number=202, supported_vehicle_type=VehicleType.CAR),
            ParkingSpot(id=4, number=203, supported_vehicle_type=VehicleType.CAR),
        ]
        floor1 = ParkingFloor(id=1, spots=f1_spots, floor_number=1, status=FloorStatus.UNDER_MAINTENANCE)
        floor2 = ParkingFloor(id=2, spots=f2_spots, floor_number=2, status=FloorStatus.OPERATIONAL)
        lot = ParkingLot(id=1, parking_floors=[floor1, floor2], gates=[])

        assigned = self.strategy.assign_spot(lot, VehicleType.CAR)
        self.assertEqual(assigned.number, 201)

    def test_nearest_spot_lowest_number_selected(self):
        """
        On the chosen floor, the spot with the lowest spot number must be selected first.
        """
        spots = [
            ParkingSpot(id=1, number=109, supported_vehicle_type=VehicleType.CAR),
            ParkingSpot(id=2, number=102, supported_vehicle_type=VehicleType.CAR),
            ParkingSpot(id=3, number=105, supported_vehicle_type=VehicleType.CAR),
        ]
        floor = ParkingFloor(id=1, spots=spots, floor_number=1, status=FloorStatus.OPERATIONAL)
        lot = ParkingLot(id=1, parking_floors=[floor], gates=[])

        assigned = self.strategy.assign_spot(lot, VehicleType.CAR)
        self.assertEqual(assigned.number, 102)

    def test_returns_none_when_no_spots_available(self):
        """
        If all spots are OCCUPIED or vehicle type does not match, returns None.
        """
        spots = [
            ParkingSpot(id=1, number=101, supported_vehicle_type=VehicleType.BIKE, status=ParkingSpotStatus.AVAILABLE),
            ParkingSpot(id=2, number=102, supported_vehicle_type=VehicleType.CAR, status=ParkingSpotStatus.OCCUPIED),
        ]
        floor = ParkingFloor(id=1, spots=spots, floor_number=1, status=FloorStatus.OPERATIONAL)
        lot = ParkingLot(id=1, parking_floors=[floor], gates=[])

        self.assertIsNone(self.strategy.assign_spot(lot, VehicleType.CAR))


# ===========================================================================
# Test Suite 3 — Ticket Service
# ===========================================================================

class TestTicketService(unittest.TestCase):
    """Tests domain logic within TicketServiceImpl."""

    def setUp(self):
        _, self.service, self.gate_repo, self.lot_repo, self.vehicle_repo, self.ticket_repo, _, _ = _setup_test_environment()

    def test_generate_ticket_creates_vehicle_if_not_present(self):
        """When vehicle registration is new, a new Vehicle record is created and saved."""
        ticket = self.service.generate_ticket(gate_id=1, registration_number="MH-02-AB-9999", vehicle_type="CAR")
        self.assertIsNotNone(ticket)
        self.assertEqual(ticket.vehicle.registration_number, "MH-02-AB-9999")
        self.assertEqual(ticket.vehicle.vehicle_type, VehicleType.CAR)

        # Vehicle must now exist in repository
        saved_vehicle = self.vehicle_repo.get_vehicle_by_registration_number("MH-02-AB-9999")
        self.assertIsNotNone(saved_vehicle)

    def test_generate_ticket_reuses_existing_vehicle(self):
        """When vehicle registration exists, the existing record is reused."""
        existing_v = self.vehicle_repo.save(Vehicle(registration_number="DL-01-AA-1111", vehicle_type=VehicleType.CAR))
        ticket = self.service.generate_ticket(gate_id=1, registration_number="DL-01-AA-1111", vehicle_type="CAR")
        self.assertIs(ticket.vehicle, existing_v)

    def test_generate_ticket_invalid_gate_id_raises_exception(self):
        """Non-existent gate ID raises InvalidGateException."""
        with self.assertRaises(InvalidGateException):
            self.service.generate_ticket(gate_id=999, registration_number="DL-01-AA-1111", vehicle_type="CAR")

    def test_generate_ticket_exit_gate_raises_exception(self):
        """Trying to generate a ticket at an EXIT gate raises InvalidGateException."""
        with self.assertRaises(InvalidGateException):
            self.service.generate_ticket(gate_id=2, registration_number="DL-01-AA-1111", vehicle_type="CAR")

    def test_generate_ticket_no_spot_available_raises_exception(self):
        """Requesting a vehicle type with 0 available spots raises ParkingSpotNotAvailableException."""
        with self.assertRaises(ParkingSpotNotAvailableException):
            self.service.generate_ticket(gate_id=1, registration_number="TRUCK-01", vehicle_type="TRUCK")

    def test_generate_ticket_invalid_vehicle_type_raises_error(self):
        """Supplying an unsupported vehicle type string raises a ValueError."""
        with self.assertRaises(ValueError):
            self.service.generate_ticket(gate_id=1, registration_number="CAR-01", vehicle_type="HOVERCRAFT")


# ===========================================================================
# Test Suite 4 — Ticket Controller
# ===========================================================================

class TestTicketController(unittest.TestCase):
    """Tests TicketController DTO handling and exception wrapping."""

    def setUp(self):
        self.controller, _, _, _, _, _, _, _ = _setup_test_environment()

    def test_generate_ticket_success(self):
        """Valid request returns SUCCESS with ticket populated."""
        req = GenerateTicketRequestDto(gate_id=1, registration_number="KA-05-MM-1234", vehicle_type="CAR")
        res: GenerateTicketResponseDto = self.controller.generate_ticket(req)

        self.assertEqual(res.response_status, ResponseStatus.SUCCESS)
        self.assertIsNotNone(res.ticket)
        self.assertEqual(res.ticket.vehicle.registration_number, "KA-05-MM-1234")
        self.assertIsNotNone(res.ticket.parking_spot)

    def test_generate_ticket_invalid_gate_returns_failure(self):
        """Invalid gate ID returns FAILURE response status and None ticket."""
        req = GenerateTicketRequestDto(gate_id=999, registration_number="KA-05-MM-1234", vehicle_type="CAR")
        res = self.controller.generate_ticket(req)
        self.assertEqual(res.response_status, ResponseStatus.FAILURE)
        self.assertIsNone(res.ticket)

    def test_generate_ticket_exit_gate_returns_failure(self):
        """Exit gate ID returns FAILURE response status and None ticket."""
        req = GenerateTicketRequestDto(gate_id=2, registration_number="KA-05-MM-1234", vehicle_type="CAR")
        res = self.controller.generate_ticket(req)
        self.assertEqual(res.response_status, ResponseStatus.FAILURE)
        self.assertIsNone(res.ticket)

    def test_generate_ticket_zero_or_negative_gate_id_returns_failure(self):
        """Gate ID <= 0 returns FAILURE response status."""
        for bad_id in [0, -1, -100]:
            req = GenerateTicketRequestDto(gate_id=bad_id, registration_number="KA-05", vehicle_type="CAR")
            res = self.controller.generate_ticket(req)
            self.assertEqual(res.response_status, ResponseStatus.FAILURE)
            self.assertIsNone(res.ticket)

    def test_generate_ticket_none_request_returns_failure(self):
        """Passing None request returns FAILURE safely without crashing."""
        res = self.controller.generate_ticket(None)
        self.assertEqual(res.response_status, ResponseStatus.FAILURE)
        self.assertIsNone(res.ticket)

    def test_generate_ticket_invalid_vehicle_type_returns_failure(self):
        """Unknown vehicle type returns FAILURE response status."""
        req = GenerateTicketRequestDto(gate_id=1, registration_number="KA-05", vehicle_type="SUBMARINE")
        res = self.controller.generate_ticket(req)
        self.assertEqual(res.response_status, ResponseStatus.FAILURE)
        self.assertIsNone(res.ticket)


# ===========================================================================
# Test Suite 5 — State Enforcement & Anti-Bypass
# ===========================================================================

class TestStateEnforcementAndAntiBypass(unittest.TestCase):
    """Tests sequential state transitions and anti-bypass guarantees."""

    def setUp(self):
        self.controller, self.service, _, _, self.vehicle_repo, self.ticket_repo, _, self.lot = _setup_test_environment()

    def test_sequential_ticket_generation_exhausts_spots(self):
        """
        In setup, there are 3 total CAR spots:
          - Floor 2: 1 CAR spot (201)
          - Floor 1: 2 CAR spots (101, 102)
        Sequential requests must first take Floor 2 (least spots = 1),
        then Floor 1 (101), then Floor 1 (102), then fail on 4th car.
        """
        # Car 1 -> Floor 2 (least available spots = 1)
        r1 = self.controller.generate_ticket(GenerateTicketRequestDto(1, "CAR-1", "CAR"))
        self.assertEqual(r1.response_status, ResponseStatus.SUCCESS)
        self.assertEqual(r1.ticket.parking_spot.number, 201)

        # Car 2 -> Floor 1 (now Floor 1 has 2, Floor 2 has 0) -> spot 101
        r2 = self.controller.generate_ticket(GenerateTicketRequestDto(1, "CAR-2", "CAR"))
        self.assertEqual(r2.response_status, ResponseStatus.SUCCESS)
        self.assertEqual(r2.ticket.parking_spot.number, 101)

        # Car 3 -> Floor 1 (1 spot left) -> spot 102
        r3 = self.controller.generate_ticket(GenerateTicketRequestDto(1, "CAR-3", "CAR"))
        self.assertEqual(r3.response_status, ResponseStatus.SUCCESS)
        self.assertEqual(r3.ticket.parking_spot.number, 102)

        # Car 4 -> No spots left -> FAILURE
        r4 = self.controller.generate_ticket(GenerateTicketRequestDto(1, "CAR-4", "CAR"))
        self.assertEqual(r4.response_status, ResponseStatus.FAILURE)
        self.assertIsNone(r4.ticket)


if __name__ == "__main__":
    unittest.main()
