from typing import List
from models.base_model import BaseModel
from models.parking_spot import ParkingSpot
from models.floor_status import FloorStatus

class ParkingFloor(BaseModel):
    def __init__(self, id: int, spots: List[ParkingSpot], floor_number: int, status: FloorStatus):
        super().__init__(id)
        self.spots = spots
        self.floor_number = floor_number
        self.status = status
