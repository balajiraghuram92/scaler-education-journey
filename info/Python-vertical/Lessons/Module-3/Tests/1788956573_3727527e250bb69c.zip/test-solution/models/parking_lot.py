from typing import List
from models.base_model import BaseModel
from models.parking_floor import ParkingFloor
from models.gate import Gate

class ParkingLot(BaseModel):
    def __init__(self, id: int, parking_floors: List[ParkingFloor], gates: List[Gate], name: str, address: str):
        super().__init__(id)
        self.parking_floors = parking_floors
        self.gates = gates
        self.name = name
        self.address = address
