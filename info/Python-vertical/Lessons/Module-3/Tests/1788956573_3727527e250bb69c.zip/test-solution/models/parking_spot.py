from models.base_model import BaseModel
from models.vehicle_type import VehicleType
from models.parking_spot_status import ParkingSpotStatus

class ParkingSpot(BaseModel):
    def __init__(self, id: int, number: int, supported_vehicle_type: VehicleType):
        super().__init__(id)
        self.number = number
        self.supported_vehicle_type = supported_vehicle_type
        self.status = ParkingSpotStatus.AVAILABLE
