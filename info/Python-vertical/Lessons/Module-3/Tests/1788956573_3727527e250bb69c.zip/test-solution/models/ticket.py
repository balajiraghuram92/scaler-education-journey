from datetime import datetime
from models.base_model import BaseModel
from models.vehicle import Vehicle
from models.parking_spot import ParkingSpot
from models.gate import Gate
from models.parking_attendant import ParkingAttendant

class Ticket(BaseModel):
    def __init__(self, id: int, vehicle: Vehicle, entry_time: datetime, parking_spot: ParkingSpot, gate: Gate, parking_attendant: ParkingAttendant):
        super().__init__(id)
        self.vehicle = vehicle
        self.entry_time = entry_time
        self.parking_spot = parking_spot
        self.gate = gate
        self.parking_attendant = parking_attendant

    def __str__(self):
        return f"Ticket{{vehicle={self.vehicle}, entry_time={self.entry_time}, parking_spot={self.parking_spot}, gate={self.gate}, parking_attendant={self.parking_attendant}}}"
