from datetime import datetime

class BaseModel:
    """
    The parent class for all models in the system.
    Every model will automatically get an 'id', 'created_at', and 'updated_at' field
    by inheriting from this class.
    """

    def __init__(self, id: int):
        self.id = id
        self.created_at = datetime.now()
        self.updated_at = datetime.now()
