from models.base_model import BaseModel

class ParkingAttendant(BaseModel):
    def __init__(self, id: int, name: str, email: str):
        super().__init__(id)
        self.name = name
        self.email = email
