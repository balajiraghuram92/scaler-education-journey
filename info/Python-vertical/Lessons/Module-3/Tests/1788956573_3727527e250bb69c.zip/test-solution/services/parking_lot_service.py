from abc import ABC, abstractmethod
from typing import List, Dict
from models.parking_floor import ParkingFloor
from models.vehicle_type import VehicleType

class ParkingLotService(ABC):
    """
    Defines the contract for the parking lot service.

    TODO (for student):
    -------------------
    Create a concrete class called ParkingLotServiceImpl that implements this ABC.
    The constructor should accept:
      - A ParkingLotRepository

    Implement:
      1. get_parking_lot_capacity(parking_lot_id, parking_floors, vehicle_types):
         - Find the parking lot using the repository. If not found, raise InvalidParkingLotException.
         - Calculate and return the capacity based on the provided filters.
           - If `parking_floors` is None or empty, consider all floors.
           - If `vehicle_types` is None or empty, consider all vehicle types.
         - The returned dict maps a ParkingFloor object to another dict mapping the string representation
           of a VehicleType to the number of AVAILABLE spots of that type on that floor.
    """

    @abstractmethod
    def get_parking_lot_capacity(self, parking_lot_id: int, parking_floors: List[int], vehicle_types: List[VehicleType]) -> Dict[ParkingFloor, Dict[str, int]]:
        pass
