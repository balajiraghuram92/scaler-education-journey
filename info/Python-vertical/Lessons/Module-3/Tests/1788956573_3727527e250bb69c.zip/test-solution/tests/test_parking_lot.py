import os
import sys
import unittest
from typing import List

# Ensure parent directory is in sys.path so package imports resolve from any CWD
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..", "..")))

from controllers.parking_lot_controller import ParkingLotController
from dtos.get_parking_lot_capacity_request_dto import GetParkingLotCapacityRequestDto
from dtos.get_parking_lot_capacity_response_dto import GetParkingLotCapacityResponseDto
from dtos.response_status import ResponseStatus
from exceptions.invalid_parking_lot_exception import InvalidParkingLotException
from models.floor_status import FloorStatus
from models.gate import Gate
from models.gate_type import GateType
from models.parking_attendant import ParkingAttendant
from models.parking_floor import ParkingFloor
from models.parking_lot import ParkingLot
from models.parking_spot import ParkingSpot
from models.parking_spot_status import ParkingSpotStatus
from models.vehicle_type import VehicleType
from repositories.parking_lot_repository_impl import ParkingLotRepositoryImpl
from services.parking_lot_service_impl import ParkingLotServiceImpl


def _build_sample_parking_lot(lot_id: int = 1) -> ParkingLot:
    """
    Helper function to construct a realistic sample ParkingLot:
      - Floor 1:
          - Spot 1: CAR, AVAILABLE
          - Spot 2: CAR, OCCUPIED
          - Spot 3: BIKE, AVAILABLE
          - Spot 4: TRUCK, UNDER_MAINTENANCE
      - Floor 2:
          - Spot 5: CAR, AVAILABLE
          - Spot 6: BIKE, AVAILABLE
          - Spot 7: BIKE, AVAILABLE
          - Spot 8: TRUCK, AVAILABLE
      - Floor 3:
          - (No spots)
      - Gates:
          - Gate 1: ENTRY
          - Gate 2: EXIT
    """
    floor1_spots = [
        ParkingSpot(id=1, number=101, supported_vehicle_type=VehicleType.CAR),
        ParkingSpot(id=2, number=102, supported_vehicle_type=VehicleType.CAR),
        ParkingSpot(id=3, number=103, supported_vehicle_type=VehicleType.BIKE),
        ParkingSpot(id=4, number=104, supported_vehicle_type=VehicleType.TRUCK),
    ]
    # Set status for floor 1 spots
    floor1_spots[1].status = ParkingSpotStatus.OCCUPIED
    floor1_spots[3].status = ParkingSpotStatus.UNDER_MAINTENANCE

    floor2_spots = [
        ParkingSpot(id=5, number=201, supported_vehicle_type=VehicleType.CAR),
        ParkingSpot(id=6, number=202, supported_vehicle_type=VehicleType.BIKE),
        ParkingSpot(id=7, number=203, supported_vehicle_type=VehicleType.BIKE),
        ParkingSpot(id=8, number=204, supported_vehicle_type=VehicleType.TRUCK),
    ]

    floor1 = ParkingFloor(id=10, spots=floor1_spots, floor_number=1, status=FloorStatus.OPERATIONAL)
    floor2 = ParkingFloor(id=20, spots=floor2_spots, floor_number=2, status=FloorStatus.OPERATIONAL)
    floor3 = ParkingFloor(id=30, spots=[], floor_number=3, status=FloorStatus.OPERATIONAL)

    attendant = ParkingAttendant(id=1, name="John Doe", email="john@example.com")
    gates = [
        Gate(id=100, name="Gate 1", gate_type=GateType.ENTRY, parking_attendant=attendant),
        Gate(id=200, name="Gate 2", gate_type=GateType.EXIT, parking_attendant=attendant),
    ]

    return ParkingLot(
        id=lot_id,
        parking_floors=[floor1, floor2, floor3],
        gates=gates,
        name="Central Mall Parking",
        address="123 Main Street"
    )


def _make_controller():
    """Creates a ParkingLotController wired to a fresh in-memory repository."""
    repo = ParkingLotRepositoryImpl()
    service = ParkingLotServiceImpl(repo)
    controller = ParkingLotController(service)
    return controller, repo, service


# ===========================================================================
# Test Suite 1 — ParkingLotRepositoryImpl
# ===========================================================================

class TestParkingLotRepository(unittest.TestCase):
    """Tests that the parking lot repository stores and retrieves parking lots correctly."""

    def setUp(self):
        self.repo = ParkingLotRepositoryImpl()

    def test_save_assigns_id_starting_at_1(self):
        """The first saved parking lot with id=0 or None must receive ID = 1."""
        lot = ParkingLot(id=0, parking_floors=[], gates=[], name="Lot A", address="Road A")
        saved = self.repo.save(lot)
        self.assertEqual(saved.id, 1)

    def test_save_increments_id_for_each_lot(self):
        """Each subsequent saved lot without ID must get the next integer ID."""
        lot1 = self.repo.save(ParkingLot(id=0, parking_floors=[], gates=[], name="Lot 1", address="Road 1"))
        lot2 = self.repo.save(ParkingLot(id=0, parking_floors=[], gates=[], name="Lot 2", address="Road 2"))
        lot3 = self.repo.save(ParkingLot(id=0, parking_floors=[], gates=[], name="Lot 3", address="Road 3"))
        self.assertEqual(lot1.id, 1)
        self.assertEqual(lot2.id, 2)
        self.assertEqual(lot3.id, 3)

    def test_save_preserves_existing_positive_id(self):
        """If a parking lot already has an ID, save() must keep it."""
        lot = ParkingLot(id=42, parking_floors=[], gates=[], name="Lot 42", address="Road 42")
        saved = self.repo.save(lot)
        self.assertEqual(saved.id, 42)

    def test_get_parking_lot_by_id_returns_correct_lot(self):
        """get_parking_lot_by_id() must return the exact lot that was saved."""
        lot = _build_sample_parking_lot(lot_id=1)
        self.repo.save(lot)
        found = self.repo.get_parking_lot_by_id(1)
        self.assertIs(found, lot)

    def test_get_parking_lot_by_id_returns_none_for_missing_id(self):
        """Searching for an unsaved ID must return None."""
        self.assertIsNone(self.repo.get_parking_lot_by_id(999))

    def test_get_parking_lot_by_gate_id_finds_lot(self):
        """get_parking_lot_by_gate_id() must find the lot containing the specified gate ID."""
        lot = _build_sample_parking_lot(lot_id=1)
        self.repo.save(lot)
        found = self.repo.get_parking_lot_by_gate_id(100)
        self.assertIs(found, lot)
        found_exit = self.repo.get_parking_lot_by_gate_id(200)
        self.assertIs(found_exit, lot)

    def test_get_parking_lot_by_gate_id_returns_none_for_missing_gate(self):
        """Searching for a gate ID that does not exist in any lot must return None."""
        lot = _build_sample_parking_lot(lot_id=1)
        self.repo.save(lot)
        self.assertIsNone(self.repo.get_parking_lot_by_gate_id(9999))


# ===========================================================================
# Test Suite 2 — ParkingLotServiceImpl
# ===========================================================================

class TestParkingLotService(unittest.TestCase):
    """Tests the business logic of calculating available capacity with various filters."""

    def setUp(self):
        self.repo = ParkingLotRepositoryImpl()
        self.service = ParkingLotServiceImpl(self.repo)
        self.sample_lot = _build_sample_parking_lot(lot_id=1)
        self.repo.save(self.sample_lot)
        self.floor1 = self.sample_lot.parking_floors[0]
        self.floor2 = self.sample_lot.parking_floors[1]
        self.floor3 = self.sample_lot.parking_floors[2]

    def test_get_capacity_neither_filter(self):
        """
        Requirement 6: If neither filter is provided, return capacity of all vehicle types in all floors.
        Floor 1: CAR=1, BIKE=1, TRUCK=0
        Floor 2: CAR=1, BIKE=2, TRUCK=1
        Floor 3: CAR=0, BIKE=0, TRUCK=0
        """
        capacity = self.service.get_parking_lot_capacity(1, None, None)

        self.assertEqual(len(capacity), 3)
        self.assertIn(self.floor1, capacity)
        self.assertIn(self.floor2, capacity)
        self.assertIn(self.floor3, capacity)

        self.assertEqual(capacity[self.floor1], {"CAR": 1, "BIKE": 1, "TRUCK": 0})
        self.assertEqual(capacity[self.floor2], {"CAR": 1, "BIKE": 2, "TRUCK": 1})
        self.assertEqual(capacity[self.floor3], {"CAR": 0, "BIKE": 0, "TRUCK": 0})

    def test_get_capacity_filter_floors_only(self):
        """
        Requirement 4: If only parking floor ids, return capacity of all vehicle types in given floors.
        """
        capacity = self.service.get_parking_lot_capacity(1, parking_floors=[10], vehicle_types=None)

        self.assertEqual(len(capacity), 1)
        self.assertIn(self.floor1, capacity)
        self.assertEqual(capacity[self.floor1], {"CAR": 1, "BIKE": 1, "TRUCK": 0})

    def test_get_capacity_filter_vehicle_types_only(self):
        """
        Requirement 5: If only vehicle types, return capacity of given vehicle types in all floors.
        """
        capacity = self.service.get_parking_lot_capacity(1, parking_floors=None, vehicle_types=[VehicleType.CAR, VehicleType.BIKE])

        self.assertEqual(len(capacity), 3)
        self.assertEqual(capacity[self.floor1], {"CAR": 1, "BIKE": 1})
        self.assertEqual(capacity[self.floor2], {"CAR": 1, "BIKE": 2})
        self.assertEqual(capacity[self.floor3], {"CAR": 0, "BIKE": 0})

    def test_get_capacity_filter_both_floors_and_vehicle_types(self):
        """
        Requirement 3: If both filters are given, return capacity of given vehicle types in given floors.
        """
        capacity = self.service.get_parking_lot_capacity(
            1,
            parking_floors=[20],
            vehicle_types=[VehicleType.BIKE, VehicleType.TRUCK]
        )

        self.assertEqual(len(capacity), 1)
        self.assertIn(self.floor2, capacity)
        self.assertEqual(capacity[self.floor2], {"BIKE": 2, "TRUCK": 1})

    def test_get_capacity_empty_lists_treated_as_no_filter(self):
        """Empty lists for filters should be treated the same as None (all floors, all types)."""
        capacity = self.service.get_parking_lot_capacity(1, parking_floors=[], vehicle_types=[])
        self.assertEqual(len(capacity), 3)
        self.assertEqual(capacity[self.floor1], {"CAR": 1, "BIKE": 1, "TRUCK": 0})

    def test_get_capacity_only_available_spots_counted(self):
        """Spots that are OCCUPIED, UNDER_MAINTENANCE, or CLOSED must not be counted."""
        # Change all spots on floor 2 to CLOSED
        for s in self.floor2.spots:
            s.status = ParkingSpotStatus.CLOSED

        capacity = self.service.get_parking_lot_capacity(1, parking_floors=[20], vehicle_types=[VehicleType.CAR])
        self.assertEqual(capacity[self.floor2]["CAR"], 0)

    def test_get_capacity_raises_invalid_parking_lot_exception(self):
        """Looking up a non-existent parking lot ID must raise InvalidParkingLotException."""
        with self.assertRaises(InvalidParkingLotException):
            self.service.get_parking_lot_capacity(999, None, None)

    def test_get_capacity_non_existent_floor_filter_returns_empty_dict(self):
        """Filtering by a floor ID that does not belong to the lot returns an empty dict."""
        capacity = self.service.get_parking_lot_capacity(1, parking_floors=[999], vehicle_types=None)
        self.assertEqual(capacity, {})


# ===========================================================================
# Test Suite 3 — ParkingLotController
# ===========================================================================

class TestParkingLotController(unittest.TestCase):
    """Tests that the controller handles inputs, exceptions, and produces proper DTO responses."""

    def setUp(self):
        self.controller, self.repo, self.service = _make_controller()
        self.sample_lot = _build_sample_parking_lot(lot_id=1)
        self.repo.save(self.sample_lot)
        self.floor1 = self.sample_lot.parking_floors[0]
        self.floor2 = self.sample_lot.parking_floors[1]

    def test_get_capacity_success_all_filters(self):
        """Controller successfully returns capacity with string vehicle types."""
        req = GetParkingLotCapacityRequestDto(
            parking_lot_id=1,
            parking_floor_ids=[10, 20],
            vehicle_types=["CAR", "BIKE"]
        )
        response_dto = self.controller.get_parking_lot_capacity(req)

        self.assertIsNotNone(response_dto.response)
        self.assertEqual(response_dto.response.response_status, ResponseStatus.SUCCESS)
        self.assertEqual(response_dto.response.message, "Capacity calculated successfully")
        self.assertIsNotNone(response_dto.capacity_map)
        self.assertEqual(response_dto.capacity_map[self.floor1], {"CAR": 1, "BIKE": 1})
        self.assertEqual(response_dto.capacity_map[self.floor2], {"CAR": 1, "BIKE": 2})

    def test_get_capacity_success_no_filters(self):
        """Controller successfully returns capacity when no optional filters are provided."""
        req = GetParkingLotCapacityRequestDto(parking_lot_id=1)
        response_dto = self.controller.get_parking_lot_capacity(req)

        self.assertEqual(response_dto.response.response_status, ResponseStatus.SUCCESS)
        self.assertEqual(len(response_dto.capacity_map), 3)

    def test_get_capacity_invalid_parking_lot_returns_failure(self):
        """Controller returns FAILURE when parking lot ID does not exist."""
        req = GetParkingLotCapacityRequestDto(parking_lot_id=999)
        response_dto = self.controller.get_parking_lot_capacity(req)

        self.assertEqual(response_dto.response.response_status, ResponseStatus.FAILURE)
        self.assertIsNone(response_dto.capacity_map)

    def test_get_capacity_zero_parking_lot_id_returns_failure(self):
        """Controller returns FAILURE when parking lot ID is 0."""
        req = GetParkingLotCapacityRequestDto(parking_lot_id=0)
        response_dto = self.controller.get_parking_lot_capacity(req)

        self.assertEqual(response_dto.response.response_status, ResponseStatus.FAILURE)
        self.assertIsNone(response_dto.capacity_map)

    def test_get_capacity_negative_parking_lot_id_returns_failure(self):
        """Controller returns FAILURE when parking lot ID is negative."""
        req = GetParkingLotCapacityRequestDto(parking_lot_id=-5)
        response_dto = self.controller.get_parking_lot_capacity(req)

        self.assertEqual(response_dto.response.response_status, ResponseStatus.FAILURE)
        self.assertIsNone(response_dto.capacity_map)

    def test_get_capacity_none_request_returns_failure(self):
        """Controller returns FAILURE safely without crashing when request is None."""
        response_dto = self.controller.get_parking_lot_capacity(None)

        self.assertEqual(response_dto.response.response_status, ResponseStatus.FAILURE)
        self.assertIsNone(response_dto.capacity_map)

    def test_get_capacity_invalid_vehicle_type_string_returns_failure(self):
        """Passing an unrecognized vehicle type string in request returns FAILURE."""
        req = GetParkingLotCapacityRequestDto(
            parking_lot_id=1,
            vehicle_types=["AIRPLANE"]
        )
        response_dto = self.controller.get_parking_lot_capacity(req)

        self.assertEqual(response_dto.response.response_status, ResponseStatus.FAILURE)
        self.assertIsNone(response_dto.capacity_map)


# ===========================================================================
# Test Suite 4 — State Enforcement & Anti-Bypass
# ===========================================================================

class TestStateEnforcementAndAntiBypass(unittest.TestCase):
    """Verifies edge cases, state updates, and anti-bypass guarantees."""

    def setUp(self):
        self.controller, self.repo, self.service = _make_controller()
        self.sample_lot = _build_sample_parking_lot(lot_id=1)
        self.repo.save(self.sample_lot)
        self.floor1 = self.sample_lot.parking_floors[0]

    def test_spot_state_change_dynamically_updates_capacity(self):
        """Changing spot status from AVAILABLE to OCCUPIED dynamically reflects in capacity."""
        # Initially floor 1 has 1 available CAR spot
        req = GetParkingLotCapacityRequestDto(1, parking_floor_ids=[10], vehicle_types=["CAR"])
        res1 = self.controller.get_parking_lot_capacity(req)
        self.assertEqual(res1.capacity_map[self.floor1]["CAR"], 1)

        # Occupy the spot
        available_spot = [s for s in self.floor1.spots if s.supported_vehicle_type == VehicleType.CAR and s.status == ParkingSpotStatus.AVAILABLE][0]
        available_spot.status = ParkingSpotStatus.OCCUPIED

        # Now capacity should be 0
        res2 = self.controller.get_parking_lot_capacity(req)
        self.assertEqual(res2.capacity_map[self.floor1]["CAR"], 0)

        # Free the spot back
        available_spot.status = ParkingSpotStatus.AVAILABLE
        res3 = self.controller.get_parking_lot_capacity(req)
        self.assertEqual(res3.capacity_map[self.floor1]["CAR"], 1)

    def test_duplicate_vehicle_types_in_request_handled_cleanly(self):
        """Duplicate vehicle types in request do not produce duplicate keys or corrupt counting."""
        req = GetParkingLotCapacityRequestDto(
            parking_lot_id=1,
            parking_floor_ids=[10],
            vehicle_types=["CAR", "CAR", "BIKE"]
        )
        res = self.controller.get_parking_lot_capacity(req)
        self.assertEqual(res.response.response_status, ResponseStatus.SUCCESS)
        self.assertEqual(res.capacity_map[self.floor1], {"CAR": 1, "BIKE": 1})

    def test_case_insensitive_vehicle_type_strings(self):
        """Controller accepts lowercase or mixed-case vehicle type strings."""
        req = GetParkingLotCapacityRequestDto(
            parking_lot_id=1,
            parking_floor_ids=[10],
            vehicle_types=["car", "Bike", "TRUCK"]
        )
        res = self.controller.get_parking_lot_capacity(req)
        self.assertEqual(res.response.response_status, ResponseStatus.SUCCESS)
        self.assertEqual(res.capacity_map[self.floor1], {"CAR": 1, "BIKE": 1, "TRUCK": 0})


if __name__ == "__main__":
    unittest.main()
