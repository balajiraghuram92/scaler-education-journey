from abc import ABC, abstractmethod
from typing import Optional
from models.parking_lot import ParkingLot

class ParkingLotRepository(ABC):
    """
    Defines the contract for how parking lots are stored and retrieved.

    TODO (for student):
    -------------------
    Create a concrete class called ParkingLotRepositoryImpl that implements this ABC.
    - Use a Python dictionary as your in-memory database: self._parking_lots = {}

    Implement:
      1. get_parking_lot_by_gate_id(gate_id) -> return Optional[ParkingLot]
      2. get_parking_lot_by_id(id)           -> return Optional[ParkingLot]
      3. save(parking_lot)                   -> return ParkingLot
    """

    @abstractmethod
    def get_parking_lot_by_gate_id(self, gate_id: int) -> Optional[ParkingLot]:
        pass

    @abstractmethod
    def get_parking_lot_by_id(self, id: int) -> Optional[ParkingLot]:
        pass

    @abstractmethod
    def save(self, parking_lot: ParkingLot) -> ParkingLot:
        pass
