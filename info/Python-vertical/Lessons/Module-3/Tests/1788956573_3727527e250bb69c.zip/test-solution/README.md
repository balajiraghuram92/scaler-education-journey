# Display parking lot capacity

## Problem Statement
We want to create a functionality using which can display the capacity of the given parking lot. This functionality will be used by various displays installed across the parking lot to display the capacity of the parking lot.

## Assignment

Your task is to implement the functionality to display the parking lot capacity based on given filters.

#### Requirements
1. The functionality should give the overall capacity of the parking lot.
2. This functionality supports filters: parking floor ids and vehicle types.
3. If the request includes both, return capacity of given vehicle types in given floors.
4. If only parking floor ids, return capacity of all vehicle types in given floors.
5. If only vehicle types, return capacity of given vehicle types in all floors.
6. If neither, return capacity of all vehicle types in all floors.
7. The response should contain a dictionary mapping `ParkingFloor` objects to a dictionary where keys are string representations of vehicle types and values are the capacities.

#### Instructions

* Refer the `get_parking_lot_capacity` method inside `ParkingLotController` class.
* Refer the `GetParkingLotCapacityRequestDto` and `GetParkingLotCapacityResponseDto` for request and response details.
* Implement the relevant methods of `ParkingLotService`, `ParkingLotRepository` classes to achieve the above requirements.
* Refer the models package to understand the models to be used.
