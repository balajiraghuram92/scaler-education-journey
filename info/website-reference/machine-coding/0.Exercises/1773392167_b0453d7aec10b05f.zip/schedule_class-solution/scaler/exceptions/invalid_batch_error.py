class InvalidBatchError(Exception):
    pass
