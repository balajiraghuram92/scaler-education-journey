class InvalidLectureError(Exception):
    pass
