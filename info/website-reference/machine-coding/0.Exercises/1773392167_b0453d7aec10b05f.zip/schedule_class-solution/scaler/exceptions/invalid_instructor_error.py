class InvalidInstructorError(Exception):
    pass
