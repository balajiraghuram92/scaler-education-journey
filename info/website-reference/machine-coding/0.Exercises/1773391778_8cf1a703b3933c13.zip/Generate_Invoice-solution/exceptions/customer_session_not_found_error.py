class CustomerSessionNotFoundException(Exception):
    pass