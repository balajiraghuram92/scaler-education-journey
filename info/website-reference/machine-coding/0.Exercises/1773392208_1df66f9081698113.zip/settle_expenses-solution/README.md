# Implement functionality which will allow Splitwise users to manage groups

## Problem Statement
You are building web application similar to Splitwise. This functionality will be used by the users to settle up transactions.

## Requirements
We need to create functionality to support to settle a group


1. Settle a group
   * We will get group id as input.
   * For this group we need to consider all the transactions between all the members of the group and come up with the minimum number of transactions required to settle up all the balances.
   * We should use the min heap and max heap approach to solve this problem. But keep the implementation flexible so that we can change the approach later.
   * We need to return the list of transactions which will settle up all the balances.
   * Make sure to do basic checks like whether the group exists etc.

## Instructions
1. Carefully look at the dtos package. These classes represent the request and response of the functionality which we want to implement.
2. Carefully examine the models package to understand the database schema.
3. Implement the incomplete methods inside the `SettleUpController`.
4. Implement the `SettleUpService` interface and fix the repository interfaces.
5. You might also need to handle cardinality between the models.
6. We will be using an in-memory SQL database. You do not need to implement any database related code. You just need to use the repository interfaces to interact with the database.