from splitwise.services import SettleUpService
from splitwise.dtos import SettleGroupRequestDto, SettleGroupResponseDto, ResponseStatus


class SettleController:
    settle_up_service: SettleUpService

    def __init__(self, settle_up_service: SettleUpService):
        self.settle_up_service = settle_up_service

    def settle_group(self, request_dto: SettleGroupRequestDto):
        try:
            transactions = self.settle_up_service.settle_group(
                group_id=request_dto.group_id
            )
            return SettleGroupResponseDto(
                transactions=transactions,
                response_status=ResponseStatus.SUCCESS
            )
        except Exception as e:
            return SettleGroupResponseDto(
                response_status=ResponseStatus.FAILURE
            )
