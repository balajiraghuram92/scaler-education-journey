class NotFoundError(Exception):
    pass


class InvalidGroupError(Exception):
    pass


class InvalidUserError(Exception):
    pass

