from enum import Enum
from dataclasses import dataclass, field
from typing import Optional, List
from splitwise.models import Transaction


class ResponseStatus(Enum):
    FAILURE = "FAILURE"
    SUCCESS = "SUCCESS"


@dataclass
class SettleGroupRequestDto:
    group_id: int


@dataclass
class SettleGroupResponseDto:
    transactions: List[Transaction] = field(default=None)
    response_status: ResponseStatus = field(default=ResponseStatus.SUCCESS)
