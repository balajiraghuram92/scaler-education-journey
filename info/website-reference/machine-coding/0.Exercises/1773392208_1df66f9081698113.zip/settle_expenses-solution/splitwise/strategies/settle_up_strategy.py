from abc import ABC, abstractmethod
from typing import Dict
from splitwise.models import User


class SettleUpStrategy(ABC):
    @abstractmethod
    def settle_up(
            self,
            aggregate_expenses: Dict[User, float]
    ):
        pass
