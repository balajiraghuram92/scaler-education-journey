import heapq
from dataclasses import dataclass

from .settle_up_strategy import SettleUpStrategy
from typing import Dict, Tuple
from splitwise.models import User, Transaction


class TwoSetSettleUpStrategy(SettleUpStrategy):
    @dataclass
    class HeapNode:
        amount: float
        user: User

        def __lt__(self, other):
            return self.amount > other.amount

    def settle_up(
            self,
            aggregate_expenses: Dict[User, float]
    ):
        payers = []
        receivers = []

        transactions = []

        for user, amount in aggregate_expenses.items():
            if amount > 0:
                receivers.append(self.HeapNode(amount, user))
            elif amount < 0:
                payers.append(self.HeapNode(-amount, user))

        heapq.heapify(payers)
        heapq.heapify(receivers)

        while payers and receivers:

            payer = heapq.heappop(payers)
            receiver = heapq.heappop(receivers)

            if payer.amount == receiver.amount:
                transactions.append(Transaction(
                    paid_to=receiver.user,
                    paid_from=payer.user,
                    amount=payer.amount
                ))
            elif payer.amount < receiver.amount:
                transactions.append(
                    Transaction(
                        paid_to=receiver.user,
                        paid_from=payer.user,
                        amount=payer.amount
                    )
                )
                receiver.amount -= payer.amount
                heapq.heappush(receivers, receiver)
            else:
                transactions.append(
                    Transaction(
                        paid_to=receiver.user,
                        paid_from=payer.user,
                        amount=receiver.amount
                    )
                )
                payer.amount -= receiver.amount
                heapq.heappush(payers, payer)

        return transactions
