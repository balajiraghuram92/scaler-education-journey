from abc import ABC, abstractmethod
from typing import List
from splitwise.models import Transaction, Group, GroupExpense, User
from splitwise.services import SettleUpService
from splitwise.strategies import SettleUpStrategy
from splitwise.exceptions import InvalidGroupError, InvalidUserError
from splitwise.utils import aggregate_expenses


class SettleUpServiceImpl(SettleUpService):
    settle_up_strategy: SettleUpStrategy

    def __init__(
            self,
            settle_up_strategy: SettleUpStrategy
    ):
        self.settle_up_strategy = settle_up_strategy

    def settle_group(
            self,
            group_id: int
    ) -> List[Transaction]:
        group = Group.objects.filter(id=group_id).first()
        if group is None:
            raise InvalidGroupError("Group with id {} does not exist".format(group_id))

        group_expenses = GroupExpense.objects.filter(group=group)
        expenses = [group_expense.expense
                    for group_expense in group_expenses]
        aggregated_expenses = aggregate_expenses(expenses)

        return self.settle_up_strategy.settle_up(
            aggregated_expenses
        )
