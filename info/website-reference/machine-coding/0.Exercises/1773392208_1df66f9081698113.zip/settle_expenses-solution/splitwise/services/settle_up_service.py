from abc import ABC, abstractmethod
from typing import List
from splitwise.models import Transaction


class SettleUpService(ABC):

    @abstractmethod
    def settle_group(
            self,
            group_id: int
    ) -> List[Transaction]:
        pass
