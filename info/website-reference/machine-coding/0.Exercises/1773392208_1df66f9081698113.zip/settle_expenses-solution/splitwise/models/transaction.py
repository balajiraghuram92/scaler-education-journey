from dataclasses import dataclass
from .user import User

@dataclass
class Transaction:
    paid_from: User
    paid_to: User
    amount: float

