from django.db import models


class ExpenseType(models.Choices):
    PAID = "PAID"
    OWED = "OWED"


