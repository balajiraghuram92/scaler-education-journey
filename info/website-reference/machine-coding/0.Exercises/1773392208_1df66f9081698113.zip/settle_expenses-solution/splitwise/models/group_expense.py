from django.db import models
from .base_model import BaseModel
from .expense import Expense
from .group import Group


class GroupExpense(BaseModel):
    group = models.ForeignKey(Group, on_delete=models.CASCADE)
    expense = models.ForeignKey(Expense, on_delete=models.CASCADE)
