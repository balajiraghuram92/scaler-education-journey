from django.db import models
from .base_model import BaseModel


class Expense(BaseModel):
    amount = models.FloatField()
    date = models.DateField()
    description = models.TextField()


