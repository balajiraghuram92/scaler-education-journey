from django.db import models

from .user import User
from .base_model import BaseModel
from .expense import Expense
from .expense_type import ExpenseType


class ExpenseUser(BaseModel):
    expense = models.ForeignKey(Expense, on_delete=models.CASCADE)
    user = models.ForeignKey(
        User, on_delete=models.CASCADE
    )
    amount = models.DecimalField(max_digits=10, decimal_places=2)
    expense_type = models.CharField(
        max_length=10,
        choices=ExpenseType.choices
    )
