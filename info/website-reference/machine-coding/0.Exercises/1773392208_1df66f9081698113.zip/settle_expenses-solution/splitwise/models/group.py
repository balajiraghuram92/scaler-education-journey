from django.db import models
from .base_model import BaseModel
from .user import User


class Group(BaseModel):
    name = models.CharField(max_length=255)
    description = models.CharField(max_length=255)

    users = models.ManyToManyField(
        User, related_name='groups'
    )

    admins = models.ManyToManyField(
        User
    )
