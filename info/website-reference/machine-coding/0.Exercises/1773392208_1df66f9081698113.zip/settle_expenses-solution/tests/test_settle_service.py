from datetime import timedelta

from django.test import TestCase
from django.utils import timezone

from splitwise.models import User, Group, GroupExpense, Expense, ExpenseType, ExpenseUser, Transaction
from splitwise.services import SettleUpServiceImpl
from splitwise.strategies import TwoSetSettleUpStrategy


class TestSettleService(TestCase):

    def setUp(self):
        self.settle_up_strategy = TwoSetSettleUpStrategy()
        self.settle_service = SettleUpServiceImpl(
            settle_up_strategy=TwoSetSettleUpStrategy()
        )
        self.generate_data()

    def test_settle_group(self):
        group = self.data["group"]
        [user1, user2, user3, user4] = self.data["users"]
        expense = Expense.objects.create(
            amount=100,
            description="test",
            date=timezone.now() - timedelta(days=1)
        )

        ExpenseUser.objects.create(
            user=user1,
            expense=expense,
            amount=25,
            expense_type=ExpenseType.PAID
        )

        ExpenseUser.objects.create(
            user=user1,
            expense=expense,
            amount=50,
            expense_type=ExpenseType.OWED
        )

        ExpenseUser.objects.create(
            user=user2,
            expense=expense,
            amount=75,
            expense_type=ExpenseType.PAID
        )

        ExpenseUser.objects.create(
            user=user2,
            expense=expense,
            amount=50,
            expense_type=ExpenseType.PAID
        )

        GroupExpense.objects.create(
            group=group,
            expense=expense
        )
        transactions = self.settle_service.settle_group(
            group_id=group.id
        )
        print(transactions)
        self.assertEqual(len(transactions), 1)

    def test_settle__invalid_group(self):
        with self.assertRaises(Exception):
            transactions = self.settle_service.settle_group(
                group_id=100
            )

    def generate_data(self):
        user1 = User.objects.create(
            name="user1",
            phone="9111111111"
        )

        user2 = User.objects.create(
            name="user2",
            phone="9222222222"
        )

        user3 = User.objects.create(
            name="user3",
            phone="9333333333"
        )

        user4 = User.objects.create(
            name="user4",
            phone="9444444444"
        )

        group = Group.objects.create(
            name="group1"
        )

        group.users.add(user1, user2, user3, user4)
        group.save()

        self.data = {
            "users": [user1, user2, user3, user4],
            "group": group
        }
