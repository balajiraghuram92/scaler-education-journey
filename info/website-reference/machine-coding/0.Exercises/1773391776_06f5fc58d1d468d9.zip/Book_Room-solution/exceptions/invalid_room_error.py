class InvalidRoomError(Exception):
    pass
