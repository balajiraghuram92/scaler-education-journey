class UnAuthorizedAccessError(Exception):
    pass
