class NotFoundError(Exception):
    pass
