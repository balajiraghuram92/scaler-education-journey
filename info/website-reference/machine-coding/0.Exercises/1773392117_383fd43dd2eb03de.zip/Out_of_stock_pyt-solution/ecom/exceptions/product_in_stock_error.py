class ProductInStockError(Exception):
    pass
