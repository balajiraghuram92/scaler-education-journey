class NotificationNotFoundError(Exception):
    pass
