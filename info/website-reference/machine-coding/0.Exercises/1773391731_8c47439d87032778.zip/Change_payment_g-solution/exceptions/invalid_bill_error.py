class InvalidBillError(Exception):
    pass
