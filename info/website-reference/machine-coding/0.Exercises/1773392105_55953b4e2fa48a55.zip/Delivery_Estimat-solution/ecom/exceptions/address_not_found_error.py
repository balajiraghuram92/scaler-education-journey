class AddressNotFoundError(Exception):
    pass
