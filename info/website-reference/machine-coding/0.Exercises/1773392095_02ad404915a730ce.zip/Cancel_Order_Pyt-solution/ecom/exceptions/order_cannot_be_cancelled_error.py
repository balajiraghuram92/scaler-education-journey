class OrderCannotBeCancelledError(Exception):
    pass
