class OrderNotFoundError(Exception):
    pass