class UnAuthorizedAccessError(Exception):
    pass