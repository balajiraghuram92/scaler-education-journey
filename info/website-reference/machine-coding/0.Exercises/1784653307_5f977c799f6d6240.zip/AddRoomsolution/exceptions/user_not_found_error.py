class UserNotFoundError(Exception):
    pass